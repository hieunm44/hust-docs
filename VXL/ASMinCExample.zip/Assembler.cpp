// Assembler.cpp : Defines the entry point for the console application.


//#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <iostream>
	
using namespace std;

void TestLEA()
{
	unsigned short A[10] = {256, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	printf("Mang ban dau: ");
	for (int i = 0; i < 10; i++)
		printf(" %d ", A[i]);

/*	__asm {
		lea		esi, A
		
		mov		cl, 10
nhan1:	shl		WORD PTR[esi],1
		add		si, 2
		dec		cl
		jnz		nhan1
		
	} */
__asm {
		xor     esi,esi
		mov		cx, 10
 nhan1:	shl		A[esi],1
	    add    esi, 2
	    dec cx
		jnz nhan1
		
		
	} 

	printf("\nMang sau khi nhan doi: ");
	for (int i = 0; i < 10; i++)
		printf(" %d ", A[i]);
}


void TestLDS()
{
	unsigned short _ds, _bx;
	unsigned short B[10] = {1, 0xff, 0x3a, 4, 5, 6, 7, 8, 9, 10};
	__asm {
		push	ds
		lds		bx, B[2]
		mov		_ds, ds
		mov		_bx, bx
		pop		ds
	}

	printf("\n\nMang Arr gom 10 phan tu 2 byte:");
	for (int i = 0; i < 10; i++)
		printf(" %x ", B[i]);
	printf("\nLDS\tBX, Arr[2] -> DS = %x, BX = %x", _ds, _bx);
}

void TestXLAT()
{
	unsigned char _al;
	unsigned char C[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	__asm {
		lea		ebx, C
		mov		al, 3
		xlat	C
		mov		_al, al
	}

	printf("\n\nMang C gom 10 phan tu 1 byte:");
	for (int i = 0; i < 10; i++)
		printf(" %x ", C[i]);
	printf("\nLEA\tBX, C");
	printf("\nMOV\tAL, 3");
	printf("\nXLAT\t\t-> AL = %x", _al);

}

short Tong2So(short a, short b)
{
	short res;

	__asm {
		push	ax
		push	bx
		mov		ax, a
		mov		bx, b
		add		ax, bx
		mov		res, ax

		pop		bx
		pop		ax
	}
	return res;
}

void BaiTap(short *A, short N, char *Res)
{
	__asm {
		mov		ebx, ss:A
		xor		ax, ax
		mov		cx, ss:N
cont_add:
		add		ax, ds:[ebx]
		inc		bx
		inc		bx
		dec		cl
		jnz		cont_add

		mov		ecx, 4
cont_push:
		push	ax
		ror		ax, 4
		loop	cont_push

		mov		ecx, 4
		mov		edi, ss:Res
cont_conv:
		pop		bx
		and		bx, 15
		or		bl, 48
		cmp		bl, 39H
		jbe		no_add
		add		bl, 7
no_add:
		mov		ds:[edi], bl
		inc		di
		loop	cont_conv
		mov		ds:[edi], 0
	}
}

void NgayThang()
{
	short m, y;
	char d;
	cout << "Nhap thang va nam: ";
	cin >> m >> y;

	/*///////// Cach 1 //////////////////////////////
	_asm {
		mov		ax, y
		mov		bx, m
		cmp		bx, 2
		jne		break_case_2
		test	ax, 3
		mov		al, 29
		jz		het_switch
		dec		al
		jmp		het_switch
break_case_2:

		cmp		bx, 4
		je		case_30
		cmp		bx, 6
		je		case_30
		cmp		bx, 9
		je		case_30
		cmp		bx, 11
		jne		break_case_30
case_30:
		mov		al, 30
		jmp		het_switch
break_case_30:

		mov		al, 31
het_switch:

		mov		d, al
	}

	/*///////// Cach 2 //////////////////////////////
	_asm {
		mov		ax, y
		mov		bx, m
		cmp		bx, 2
		je		case_2

		cmp		bx, 4
		je		case_30
		cmp		bx, 6
		je		case_30
		cmp		bx, 9
		je		case_30
		cmp		bx, 11
		je		case_30
		jmp		_default

case_2:
		test	ax, 3
		mov		al, 29
		jz		het_switch
		dec		al
		jmp		het_switch

case_30:
		mov		al, 30
		jmp		het_switch

_default:
		mov		al, 31

het_switch:
		mov		d, al
	}

	cout << "Thang "  << m  << " Nam "  << y  << " co "  << (int)d  << " ngay!";
}

short USCLN(short a, short b)
{
	short	res;

	__asm {
		xor		eax, eax
		mov		ax, ss:a
		mov		bx, ss:b

While:
		or		bx, bx
		jz		finish
		xor		edx, edx
		div		bx
		mov		ax, bx
		mov		bx, dx
		jmp		While
finish:
		mov		res, ax
	}

	return res;
}

void swap(short *a, short *b)
{
	__asm {
		mov		esi, ss:a
		mov		edi, ss:b
		mov		ax, [esi]
		xchg	ax, [edi]
		mov		[esi], ax
	}
}

void Char2Bin(char x, char *M)
{
	__asm {
		mov		al, ss:x
		mov		edi, ss:M
		mov		[edi + 8], 0
		mov		cl, 8
		mov		bl, 2
LABEL:	xor		ah, ah
		div		bl
		or		ah, 30h
		mov		[edi + 7], ah
		dec		edi
		dec		cl
		jnz		LABEL
	}
}

int Pow(int x, int N)
{
	return (x * Pow(x, N-1));
}

void SapXep(short *M, short N)
{
	__asm {
		mov		ebx, ss:M
		xor		esi, esi
		xor		ecx, ecx
		mov		cx, ss:N
		dec		cx
		mov		edx, ecx
fori:
		mov		edi, edx
		shl		edi, 1
forj:
		cmp		edi, esi
		jbe		endforj
		mov		ax, ds:[ebx + edi]
		cmp		ax, ds:[ebx + edi - 2]
		jbe		notswap
		xchg	ax, ds:[ebx + edi - 2]
		mov		ds:[ebx + edi], ax
notswap:
		dec		edi
		dec		edi
		jmp		forj
endforj:
		inc		esi
		inc		esi
		loop	fori
	}
}

//int _tmain(int argc, _TCHAR* argv[])
int main()
{
	short x = 35, y = 21, uscln;
	char res[10];
	int count = 0;

/*	__asm {
		mov		ax, x
		mov		bx, 16
lap:
		inc		count
		xor		edx, edx
		div		bx
		push	dx
		or		ax, ax
		jnz		lap

		xor		edi, edi
fori:	cmp		edi, count
		je		end_for
		pop		dx
		or		dl, 30h
		cmp		dl, 39h
		jbe		duoi9
		add		dl, 7
duoi9:
		mov		res[edi],dl
		inc		di
		jmp		fori
end_for:
		mov		res[edi], BYTE PTR 0
	}

	printf("%s", res);


	__asm {
		mov		ax, x
		mov		bx, y

begin_while:
		test	bx, bx
		jz		end_while
		xor		dx, dx
		div		bx
		mov		ax, bx
		mov		bx, dx
		jmp		begin_while
end_while:
		mov		uscln, ax
	}
	printf("USCLN cua %d va %d la %d", x, y, uscln);


	short arr[] = {3, 1, 2, 4, 9, 5, 12, 16, 20, 7};
	short N = 10;

	printf("Original: ");
	for (int i = 0; i < N; i++)
		printf("%d ", arr[i]);

	__asm {
		mov		cx, N
		shl		cx, 1
		xor		ebx, ebx
		
for_i:	sub		cx, 2
		cmp		bx, cx
		jae		end_for_i
		mov		ax, arr[ebx]
		mov		edi, ebx
		add		di, 2
		add		cx, 2
for_j:
		cmp		di, cx
		jae		end_for_j
		cmp		ax, arr[edi]
		jbe		noswap
		xchg	ax, arr[edi]
		mov		arr[ebx], ax
noswap:
		add		di, 2
		jmp		for_j
end_for_j:
		add		bx, 2
		jmp		for_i
end_for_i:
	}

	printf("\nSorted: ");
	for (int i = 0; i < N; i++)
		printf("%d ", arr[i]);

	char A[9];
	Char2Bin(10, A);
	printf("\n10 -> %s", A);
*/

	short A[] = {0x10a, 0x270};
	short res1 = 0;
	short *p = A;

	__asm {
		mov		esi, p
		push	WORD PTR [esi + 1]
		pop		WORD PTR res1
	}

//	printf("%X", res1);

	//TestLEA();
	x=Tong2So(x,y);
	printf(" x= %d ", x);
	_getch();
	return 0;
}