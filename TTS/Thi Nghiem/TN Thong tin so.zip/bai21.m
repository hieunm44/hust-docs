xs = rand(1,5)*2-1;
[xi xq] = lquan(xs,-1,1,3)