﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public abstract class AppView : VST.IView
    {
        public VST.Schema.Gui Gui { get; set; }
    
        public object DataSource { get; set; }
        public Json.View JsonTemplate { get; set; }

        public AppView()
        {
        }

        public virtual void LoadTempalte(string name)
        {
            this.Gui = VST.Schema.Template.Guis[name];
        }

        protected abstract IEnumerable GetFieldList();
        public abstract string GetClassName();

        protected virtual object GetEntityValue(IEntity e, VST.Schema.Field field)
        {
            return field.ToString(e.GetAttribute(field.Name));
        }

        public virtual void DataBind()
        {
            this.JsonTemplate.Add("type", this.GetClassName());

            if (DataSource == null)
                return;

            var fields = this.GetFieldList();

            var keys = this.JsonTemplate.Keys;
            var entities = this.DataSource as IEnumerable;
            if (entities == null)
                entities = new object[] { this.DataSource };

            foreach (IEntity e in entities)
            {
                if (!e.HasData) continue;
                keys.Add(e.ID);
            }
        }

        protected virtual TextTemplate GetActions(params string[] keys)
        {
            var model = new TextTemplate();
            foreach (var k in keys)
                model.Add(model[k]);
            return model;
        }
    }
}