﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.View
{
    public class FormView : AppView
    {
        public FormView()
        {
            this.JsonTemplate = new Json.Form();
        }

        protected override System.Collections.IEnumerable GetFieldList()
        {
            return this.Gui.EntityFields;
        }

        public override string GetClassName()
        {
            return "FormView";
        }

        public override void DataBind()
        {
            base.DataBind();

            var form = (Json.Form)this.JsonTemplate;
            var controls = form.Controls;

            var entity = this.DataSource as IEntity;
            foreach (VST.Schema.Field field in this.GetFieldList())
            {
                var input = new Json.Collection();
                input.Caption = field.Caption;
                
                var name = field.Name;
                input.Name = name;

                string type = field.GetString("input");
                if (type != string.Empty)
                    input.Add("type", type);

                int dot = name.IndexOf('.');
                if (dot >= 0)
                    name = name.Remove(dot, 1);

                var req = field.GetString("req");
                if (req != string.Empty)
                    input.Add("required", req);

                var width = field.GetString("width");
                if (width != string.Empty)
                    input.Add("width", width);

                string dataSource = field.GetString("data-source");
                if (dataSource != string.Empty)
                {
                    var v = field.GetString("value-member");
                    var d = field.GetString("display-member");

                    var items = (Json.Array)input.Add("items", new Json.Array());
                    foreach (var e in new DefaultCollection(dataSource).Select())
                    {
                        var item = new Json.Array();
                        item.Add(e.GetAttribute(v));
                        item.Add(e.GetAttribute(d));

                        items.Add(item);
                    }
                }

                if (entity != null && entity.HasData)
                {
                    var value = this.GetEntityValue(entity, field);
                    if (!value.Equals(string.Empty))
                        input.Add("value", value);
                }
                controls.Add(name, input);
            }

            var actions = form.Actions;
            foreach (var e in this.GetActions("update", "cancel"))
            {
                actions.Add(e.Key, e.ToLink());
            }
        }
    }
}