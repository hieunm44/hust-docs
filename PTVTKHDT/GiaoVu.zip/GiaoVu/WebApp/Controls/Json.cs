﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace App.Json
{
    public class Array : VST.JSON.Array
    {
        new public Array CreateArray()
        {
            return (Array)base.Add(new Array());
        }
        new public Collection CreateCollection()
        {
            return (Collection)base.Add(new Collection());
        }
    }

    public class Collection : VST.JSON.Collection
    {
        public object Caption
        {
            get { return this["caption"]; }
            set { this["caption"] = value; }
        }

        public object Text
        {
            get { return this["text"]; }
            set { this["text"] = value; }
        }

        public object Name
        {
            get { return this["name"]; }
            set { this["name"] = value; }
        }

        new public Array CreateArray(string name)
        {
            return (Array)base.Add(name, new Array());
        }
        new public Collection CreateCollection(string name)
        {
            return (Collection)base.Add(name, new Collection());
        }
    }
    public class Link : Collection
    {
        public string Url
        {
            get { return (string)this["url"]; }
            set { this["url"] = value; }
        }
        public string OnClick
        {
            get { return (string)this["onclick"]; }
            set { this["onclick"] = value; }
        }
    }
    public class PageInfo : Collection
    {
        public PageInfo()
        {
            this.Add("mainContent", new Array());
            this.Add("sideMenu", new Array());
            this.Add("home", new Link());
        }

        public Link Home
        {
            get { return (Link)this[2]; }
        }
        public Array FHD
        {
            get { return (Array)this[1]; }
        }

        public Array MainContent
        {
            get { return (Array)this.First.Value; }
        }

        public Paragraph CreateParagraph(string name, string caption, string subcaption)
        {
            var p = new Paragraph { Caption = caption };
            if (subcaption != null)
                p.SubCaption = subcaption;

            this.Add(name, p);
            return p;
        }
    }

    public class Paragraph : Collection
    {
        public Paragraph()
        {
            this.Add("header", new Json.Collection());
            this.Header.Add("actions", new Collection());
        }

        public Collection Header
        {
            get { return (Collection)this.First.Value; }
        }

        public object SubCaption
        {
            get { return this.Header["subCaption"]; }
            set { this.Header["subCaption"] = value; }
        }

        new public object Caption
        {
            get { return this.Header.Caption; }
            set { this.Header.Caption = value; }
        }
        public Collection HeaderActions
        {
            get { return (Collection)this.Header[0]; }
        }
    }

    public class View : Paragraph
    {
        public View()
        {
            this.Add("keys", new Array());
        }

        public Array Keys
        {
            get
            {
                return (Array)this[1];
            }
        }

    }

    public class Table : View
    {
        public Table()
        {
            this.Add("columns", new Array());
            this.Add("data", new Array());
        }

        public Array Columns
        {
            get { return (Array)this[2]; }
        }

        public Array Data
        {
            get { return (Array)this[3]; }
        }
    }

    public class Form : View
    {
        public Form()
        {
            this.Add("controls", new Collection());
            this.Add("actions", new Collection());
        }

        public Collection Controls
        {
            get { return (Collection)this[2]; }
        }

        public Collection Actions
        {
            get { return (Collection)this[3]; }
        }

    }

    public class PageSplitInfo : Collection
    {
        public PageSplitInfo()
        {
        }

        public int Total
        {
            get { return (int)this["total"]; }
            set { this["total"] = value; }
        }

        public int PageSize
        {
            get { return (int)this["rows"]; }
            set { this["rows"] = value; }
        }

        public int Index
        {
            get { return (int)this["index"]; }
            set { this["index"] = value; }
        }
    }
}