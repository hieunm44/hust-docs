﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.View
{
    public class TableView : AppView
    {
        public TableView()
        {
            this.JsonTemplate = new Json.Table();
        }

        public override string GetClassName()
        {
            return "Table";
        }

        protected override System.Collections.IEnumerable GetFieldList()
        {
            return this.Gui.CollectionFields;
        }
        public override void DataBind()
        {
            base.DataBind();

            var table = (Json.Table)this.JsonTemplate;
            var columns = table.Columns;

            var fields = this.GetFieldList();
            foreach (VST.Schema.Field field in fields)
            {
                columns.Add(new Json.Collection { Caption = field.Caption, Name = field.Name });
            }

            var data = table.Data;
            foreach (IEntity e in (IEnumerable<IEntity>)this.DataSource)
            {
                if (!e.HasData)
                    continue;

                var row = data.CreateArray();
                foreach (VST.Schema.Field field in fields)
                {
                    row.Add(this.GetEntityValue(e, field));
                }
            }

            var actions = table.HeaderActions;
            foreach (var e in this.GetActions())
                actions.Add(e.Key, e.ToLink());


            string s = Engine.FunctionalContext.Search;
            if (s != string.Empty)
                table.Header.Add("search", s);
        }

        protected override object GetEntityValue(IEntity e, VST.Schema.Field field)
        {
            return field.ToString(e.GetAttribute(field.DisplayName));
        }

    }
    public class DataView : TableView
    {
        public override string GetClassName()
        {
            return "DataTable";
        }

        protected override TextTemplate GetActions(params string[] keys)
        {
            if (keys.Length == 0)
                keys = new string[] { "add", "del" };
            return base.GetActions(keys);
        }

        public override void DataBind()
        {
            base.DataBind();

            var table = (Json.Table)this.JsonTemplate;
            var sel = table.CreateCollection("selectMenu");
            var items = sel.CreateCollection("items");
            var keys = sel.CreateArray("keys");

            var temp = new TextTemplate();

            items.Add("all", temp["select-all"].Text);

            var actions = table.HeaderActions;
            var import = Engine.FunctionalContext.GetString("import");
            if (import != string.Empty)
            {
                actions.Add("import", temp["import"].ToLink());

                var gui = VST.Schema.Template.Guis[import];
                var fields = new List<VST.Schema.Field>();
                foreach (var field in gui)
                {
                    if (field.GetString("visible") != "0")
                        fields.Add(field);
                }

                var info = (Json.Array)table.Add("importInfo", new Json.Array());
                foreach (VST.Schema.Field field in fields)
                {
                    var col = info.CreateCollection();
                    col.Name = field.Name;
                    col.Caption = field.Caption;

                    var src = field.GetString("import-name");
                    if (src != string.Empty)
                        col.Add("src", src);
                }
            }
        }
    }
}