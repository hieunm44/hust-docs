using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.nckh.kiem_duyet.loi
{
    public partial class Entity : kiem_duyet.Entity
    {
    }
    public partial class DataCollection : BaseCollection<Entity>
    {
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}