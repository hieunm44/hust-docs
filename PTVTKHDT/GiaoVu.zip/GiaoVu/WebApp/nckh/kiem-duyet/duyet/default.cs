using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.NCKH.Export
{
    using App.Export;

    public partial class Entity : App.Export.Entity
    {
        public override object GetAttribute(string name)
        {
            switch (name)
            {
                case "SoNgay":
                    if (this.Name[5] == 'T')
                        return string.Format("{0}, {1:dd.MM.yyyy}", this.GetAttributes("SoXB", "NgayBD"));
                    return string.Format("{0:dd.MM.yyyy} - {1:dd.MM.yyyy}", this.GetAttributes("NgayBD", "NgayKT"));

                case "link":
                    var v = base.GetAttribute("NCKH_HoSo.MinhChung").ToString();
                    if (v.Length > 0 && v[0] == '/')
                        v = "http://nckh.vst.edu.vn" + v;
                    return v;

                case "Extend": return Extend;
                case "KLTG": return KhoiLuong;
            }
            return base.GetAttribute(name);
        }

        public override Type GetDataType(string name)
        {
            switch (name)
            {
                case "Extend": return typeof(string);
                case "KLTG": return typeof(double);
            }
            return base.GetDataType(name);
        }

        public object PhanCapId
        {
            get
            {
                var id = this.GetInt("HoSoId");
                return ((DataEntity)DataCollection.HoSo.Find(id)).GetInt("PhanCapId");
            }
        }

        public object Extend { get; set; }
        public double KhoiLuong { get; set; }
    }
    class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection() { }
        public DataCollection(string name) : base("NCKH_" + name) { }

        static DataCollection _hoSo;
        public static DataCollection HoSo
        {
            get
            {
                if (_hoSo == null)
                    _hoSo = new DataCollection("HoSo");
                return _hoSo;
            }
        }
        public static DataCollection GetItems(string sort, params string[] names)
        {
            var data = new DataCollection();
            foreach (var name in names)
                data.AddRange(new DataCollection(name).Select(null, sort));

            return data;
        }
    }


    class BaoCao : List<App.Export.Entity>
    {
        public Dictionary<object, Entity> Map = new Dictionary<object, Entity>();

        public BaoCao() { }

        public string[] CacBangNguon { get; set; }

        public BaoCao(string mau)
        {
            var model = new DataCollection("BaoCao");

            foreach (var e in model.Select("Mau='" + mau + "'"))
            {
                Map.Add(e.GetInt("PhanCapId"), e);
            }

            CacBangNguon = new NguonBC().GetTableNames(mau);
        }

        public void Reset()
        {
            foreach (var e in Map.Values)
                e.STT = 0;
        }
        public bool ContainsKey(Entity e)
        {
            if (this.Map.Count == 0)
                return true;

            Entity mau = null;
            if (this.Map.TryGetValue(e.PhanCapId, out mau) == false)
                return false;

            e.Extend = mau.GetString("Ten");
            e.STT = ++mau.STT;
            return true;
        }

        public Array GetBaoCaoKhoiLuong(int nam)
        {
            var table = DataCollection.HoSo.Table;
            var col = table.Columns["Extend"];
            if (col != null)
                table.Columns.Remove(col);

            col = table.Columns.Add("Extend", typeof(int));
            col.Expression = "count(child(NCKH_HoSo_NCKH_TacGia).HoSoId)";

            var baoCao = new BaoCao("01");
            var duyet = new Duyet(nam);

            duyet.PhanHocKy(DataCollection.GetItems(null, "TapChi", "HoiNghi"), null);

            int i = 1;
            foreach (HocKy hk in duyet.Data)
            {
                var lst = hk.GetItemArray();
                foreach (Entity e in lst)
                    e.Extend = i;
                hk.Content = lst;
                i++;
            }
            duyet.PhanHocKy(DataCollection.GetItems(null, "DeTai", "PMSC"), null);

            var map = new Dictionary<object, Entity>();
            foreach (HocKy hk in duyet.Data)
            {
                var lst = hk.GetItemArray();
                foreach (Entity e in lst)
                {
                    if (map.ContainsKey(e.ID)) continue;

                    e.KhoiLuong = (int)e.GetAttribute("NCKH_PhanCap.KhoiLuong");
                    map.Add(e.ID, e);
                }

                hk.Content = lst;
            }

            var values = new EntityList();
            foreach (Entity e in new DataCollection("TacGia").Select())
            {
                if (e.GetInt("GiangVienId") == 0)
                    continue;

                Entity src = null;
                if (map.TryGetValue(e.GetAttribute("HoSoId"), out src))
                {
                    var khoiLuong = src.KhoiLuong;
                    if (khoiLuong == 0.0)
                        continue;

                    var kieuTinh = (int)e.GetAttribute("NCKH_PhanCap.KieuTinh");
                    var heSo = e.GetInt("HeSo");

                    switch (kieuTinh)
                    {
                        case 0:
                            e.KhoiLuong = khoiLuong / 100 * heSo;
                            break;

                        case 1:
                            e.KhoiLuong = src.KhoiLuong;
                            src.KhoiLuong = 0.0;
                            break;

                        case 2:
                            e.KhoiLuong = (double)khoiLuong / (int)e.GetAttribute("NCKH_HoSo.Extend");
                            break;
                    }

                    e.Extend = src.Extend;
                    values.Add(e);
                }
            }

            table.Columns.Remove(col);
            return new Entity[] { new Entity { Content = values.ToArray() } };
        }

    }

    class HocKy : App.Export.Entity
    {
        public DateTime Start, End;
        
        EntityList _lst = new EntityList();
        public Array GetItemArray()
        {
            return _lst.ToArray();
        }

        public override object Content
        {
            get
            {
                return this.GetItemArray();
            }
            set
            {
                base.Content = value;
            }
        }

        public override object GetAttribute(string name)
        {
            if (name == "NamHoc")
            {
                int nam = Start.Year;
                if (End.Month == 6)
                    --nam;

                return string.Format("{0} - {1}", nam, nam + 1);
            }
            return base.GetAttribute(name);
        }

        public override Type GetDataType(string name)
        {
            return typeof(string);
        }

        public HocKy(DateTime start, DateTime end)
        {
            Start = start;
            End = end;
        }

        public bool CheckTime(App.Export.Entity e)
        {
            var bd = (DateTime)e.GetAttribute("NgayBD");
            var kt = (DateTime)e.GetAttribute("NgayKT");

            return !(bd > End || kt < Start);
        }
        public void AddEntities(IEnumerable items, BaoCao baoCao)
        {
            if (baoCao != null)
                baoCao.Reset();
            foreach (Entity e in items)
            {
                if (CheckTime(e) && (baoCao == null || baoCao.ContainsKey(e)))
                    _lst.Add(e);
            }
        }
    }
    class NguonBC : DataCollection
    {
        public NguonBC() : base("NguonBC") { }
        public string[] GetTableNames(object key)
        {
            var e = (DataEntity)this.Find(key);
            if (e == null) return new string[0];

            var lst = new List<string>();
            foreach (string name in e.GetString("CacBang").Split(','))
                lst.Add(name.Trim());
            return lst.ToArray();
        }
    }
    class Duyet : App.DefaultCollection
    {
        public Duyet() : this(0) { }

        public Duyet(int nam)
            : base("NCKH_Duyet")
        {
            if (nam == 0)
                nam = DateTime.Today.Year - 1;


            this.HocKy1 = new HocKy(new DateTime(nam, 7, 1), new DateTime(nam, 12, 31));
            this.HocKy2 = new HocKy(new DateTime(nam + 1, 1, 1), new DateTime(nam + 1, 6, 30));
        }
        public HocKy HocKy1 { get; private set; }
        public HocKy HocKy2 { get; private set; }

        bool IsDaDuyet(DataEntity e)
        {
            return (this.Table.Rows.Find(e.GetAttribute("HoSoId")) != null);
        }

        public void PhanHocKy(IEnumerable items, BaoCao baoCao)
        {
            var lst = new List<Entity>();
            foreach (Entity e in items)
            {
                if (IsDaDuyet(e))
                    lst.Add(e);
            }
            HocKy1.AddEntities(lst, baoCao);
            HocKy2.AddEntities(lst, baoCao);
        }

        public Array Data { get { return new HocKy[] { HocKy1, HocKy2 }; } }
    }
}

namespace App.nckh.kiem_duyet.duyet
{
    public partial class Entity : kiem_duyet.Entity
    {
        public override void Delete()
        {
            var hoso = new DefaultCollection("NCKH_HoSo").Find(this.ID) as DataEntity;
            hoso.Delete();
        }
    }

    public class Duplicate : BaseCollection<Entity>
    {
        public override ICollection GetPageItems(Json.PageSplitInfo info)
        {
            var map = new Dictionary<string, List<Entity>>();
            foreach (var e in this.Select())
            {
                var ten = VST.Viet.Text.GetLatinhCharacterOnly((string)e.GetAttribute("NCKH_HoSo.Ten"));
                List<Entity> lst;
                if (map.TryGetValue(ten, out lst) == false)
                    map.Add(ten, lst = new List<Entity>());
                lst.Add(e);
            }

            this.Clear();
            foreach (var lst in map.Values)
            {
                if (lst.Count > 1)
                    this.AddRange(lst);
            }

            info.Total = this.Count;
            info.PageSize = this.Count;
            return this;
        }
    }

    public partial class DataCollection : BaseCollection<Entity>
    {
        public override void UpdateView(AppView view)
        {
            base.UpdateView(view);
        }
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            var check = command.GetString("check");
            if (check != null)
            {
                this.Model = this.Collection = new Duplicate();
                return;
            }

            var report = command.GetString("report");
            if (report != null)
            {
                report = "0" + report;

                var baoCao = new App.NCKH.Export.BaoCao(report);
                Array data = null;
                if (report[1] == '1')
                {
                    data = baoCao.GetBaoCaoKhoiLuong(0);
                }
                else
                {
                    var duyet = new App.NCKH.Export.Duyet();

                    duyet.PhanHocKy(NCKH.Export.DataCollection.GetItems("NgayBD", baoCao.CacBangNguon), baoCao);
                    data = duyet.Data;
                }

                var engine = new Export.Engine(command)
                {
                    AttachName = report,
                    TemplateFileName = "nckh/" + report,
                    ServerFileName = "nckh",
                    Builder = new VST.Office.Excel.ListExport()
                };
                engine.Run(data);
                engine.StartDownload();

                App.Engine.Finish(null);
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}