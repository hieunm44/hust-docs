﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.nckh.kiem_duyet
{
    public class Entity : DataEntity
    {
        public override object GetAttribute(string name)
        {
            return base.GetAttribute(name);
        }
    }
    public class BaseCollection<T> : DataCollection<T>
        where T: Entity, new()
    {
        public BaseCollection() : base("NCKH_" + Engine.FunctionalContext.Name.Replace("-", ""))
        {
        }
    }
}