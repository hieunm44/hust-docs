using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.common.info
{
    public partial class Entity : App.DataEntity
    {
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
    }
    public partial class Controller : App.Controller
    {
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}