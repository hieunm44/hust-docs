using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.ho_tro.xin_giay
{
    public partial class Entity : cap_giay.kiem_tra.Entity
    {
        public object MaPC { get; set; }
        public object PhanCap { get; set; }

        public override object GetAttribute(string name)
        {
            if (name == "Ten")
                return PhanCap;

            if (name == "Action")
            {
                if (this.IsNew)
                    return 1;

                return ((int)this.GetAttribute("XinGiay_QuyTrinh.Level") > Engine.User.Level) ? 0 : -1;
            }

            if (this.IsNew)
                return null;

            if (name == "XinGiay_DangKy.ThoiDiem")
            {
                if (this.GetString("MaXL") == "Sai")
                {
                    return new cap_giay.kiem_tra.DataCollection("Sai").Find(this.ID).GetAttribute("NoiDung");
                }
            }

            return base.GetAttribute(name);
        }

        public override object ID
        {
            get
            {
                if (IsNew)
                    return MaPC;

                return base.ID;
            }
        }

        public override bool HasData
        {
            get
            {
                return true;
            }
        }

        public override void Execute(PostBackCommand command)
        {
            this.SetAttribute("MaPC", MaPC);
            this.SetAttribute("SinhVienId", Engine.User.ProfileId);

            this.SetAttribute("ThoiDiem", DateTime.Now);
            this.EndExecute(command);
        }

        protected override void EndExecute(PostBackCommand command)
        {
            base.EndExecute(command);
            var model = new cap_giay.kiem_tra.DataCollection(this.MaPC.ToString());
            var e = model.Insert(command.OutputValue);

            e.Execute(command);
            new cap_giay.kiem_tra.DataCollection("Cho").AddEntity(e);
        }
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection() : base("XinGiay_DangKy") { }
        public override void UpdateView(AppView view)
        {
            var pc = new cap_giay.kiem_tra.DataCollection("PhanCap");
            var lst = this.Select("SinhVienId='" + Engine.User.ProfileId + "'");

            var map = new Dictionary<object, Entity>();
            foreach (var e in pc.Select())
                map.Add(e.ID, new Entity { PhanCap = e.GetAttribute("Ten") });

            foreach (var e in lst)
            {
                var key = e.GetAttribute("MaPC");
                map[key].Row = e.Row;
            }

            foreach (var p in map)
                p.Value.MaPC = p.Key;

            view.DataSource = map.Values;
            view.DataBind();
        }
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        protected override void AddEntity()
        {
            this.Model = Engine.User;
            Engine.Session["xin-giay"] = this.Command.CommandValue;
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            var model = new DataCollection();
            if (command.ActionIndex == ActionIndex.Delete)
            {
                ((Entity)model.Find(command.CommandValue)).Delete();
                this.UpdateDataBase();
            }

            if (command.ActionIndex == ActionIndex.Update)
            {
                var e = (Entity)model.NewEntity();
                e.MaPC = Engine.Session["xin-giay"];
                e.Execute(command);

                this.UpdateDataBase();
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        protected override AppView CreateView(string name)
        {
            if (this.Controller.Model is IEntity)
            {
                name = "XinGiay_" + this.Controller.Command.CommandValue;
            }
            return base.CreateView(name);
        }

        protected override AppView CreateViewCore()
        {
            if (this.Controller.Model is IDataCollection)
                return new View.TableView();
            return new View.FormView();
        }

        protected override void CreateHeader(Json.Paragraph paragraph, string caption, string subCaption)
        {
            if (this.Controller.Model is IEntity)
            {
                var pc = new DefaultCollection("XinGiay_PhanCap");
                caption = (string)pc.Find(this.Controller.Command.CommandValue).GetAttribute("Ten");
            }
            base.CreateHeader(paragraph, caption, subCaption);
        }
    }
}