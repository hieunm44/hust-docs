using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.ho_tro.hoi_dap
{
    public partial class Entity : App.DataEntity
    {
        public override object GetAttribute(string name)
        {
            if (name == "TraLoi")
            {
                if (this.IsNew) return string.Empty;
                return new DefaultCollection("TuVanDap").Find(this.ID).GetAttribute("NoiDung");
            }
            return base.GetAttribute(name);
        }
        public override void UpdateView(AppView view)
        {
            base.UpdateView(view);
        }

        protected override void EndExecute(PostBackCommand command)
        {
            var id = Engine.User.ProfileId;
            
            this.Row[0] = id;
            this.SetAttribute("Ngay", DateTime.Now);

            base.EndExecute(command);
            new DefaultCollection("TuVanDap").Insert(id);
        }
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }

        protected override void AddEntity()
        {
            this.Model = ((DataCollection)this.Collection).GetEntityById(Engine.User.ProfileId);
        }

        public override void ProcessDelete(PostBackCommand command)
        {
            ((Entity)this.Collection.Find(Engine.User.ProfileId)).Delete();
            this.UpdateDataBase();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.None)
                command.ActionIndex = ActionIndex.Add;

            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}