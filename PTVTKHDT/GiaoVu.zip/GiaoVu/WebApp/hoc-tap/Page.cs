﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.hoc_tap
{
    public class Page : App.Page
    {
        protected override AppView CreateViewCore()
        {
            return new View.TableView();
        }
    }
}