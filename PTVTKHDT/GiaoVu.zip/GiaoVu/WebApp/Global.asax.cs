﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace App
{
    public class Global : System.Web.HttpApplication
    {
        #region Static Members
        public static VST.Data.Provider DataProvider { get; private set; }

        public static void ResetData()
        {
            var prov = new VST.Data.Provider(FileController.DataPath);
            prov.LoadSchema(VST.Schema.Template.Models);

            Global.DataProvider = prov;
        }
        public static void LoadTemplate()
        {
            var path = FileController.DataPath;
            VST.Schema.Template.Load(path);

            ResetData();
        }

        #endregion

        protected void Application_Start(object sender, EventArgs e)
        {
            FileController.ServerPath = this.Server.MapPath("").Replace('\\', '/');
            Global.LoadTemplate();

            App.Project.Convert.Run();
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            try
            {
                var cookie = new Project.CookieReader(this.Request);
                var account = cookie.GetUser();
                if (account.LoginState == Service.AccountInfo.LoginSuccess)
                {
                    var user = new App.User.Entity(account);
                    this.Session[NameManager.User] = user;

                    this.Response.Redirect(user.HomeUrl);
                }
            }
            catch
            {
                Engine.User = new User.Entity();
            }

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            string ext = this.Request.CurrentExecutionFilePathExtension;
            if (ext == "ashx")
                return;

            string path = this.Request.FilePath;
            VST.Schema.FHD.Entity context = null;
            var map = VST.Schema.Template.Diagam;

            if (ext == string.Empty)
            {
                context = map[path];
                if (context.IsDirectory)
                {
                    string q = this.Request.Url.Query;
                    this.Response.Redirect(context.Href + q);
                }
                return;
            }

            context = map[path.Substring(0, path.LastIndexOf('/') + 1)];

            Engine.FunctionalContext = context;
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {
        }

        protected void Application_End(object sender, EventArgs e)
        {
        }
    }
}