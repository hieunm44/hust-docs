﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace App
{
    using System.IO;
    public class PostFileInfo
    {
        public HttpPostedFile File { get; internal set; }
        public string Extension { get; internal set; }
        public string ServerFilePath { get; internal set; }

        public string ServerFileName
        {
            get
            {
                string name = this.ServerFilePath;
                for (int i = 0; i >= 0; i--)
                {
                    if (name[i] == '/')
                        return name.Substring(i + 1);
                }
                return name;
            }
        }
        public PostFileInfo() { }
        public PostFileInfo(HttpPostedFile file)
        {
            this.File = file;

            int i = file.FileName.IndexOf('.');
            if (i > 0)
            {
                this.Extension = file.FileName.Substring(i);
            }
        }
        public void SaveTo(string path)
        {
            this.File.SaveAs(this.ServerFilePath = path);
        }
    }

    public class FileController : Controller
    {
        public static string ServerPath { get; set; }
        public static string MapPath(string path)
        {
            if (path[0] != '/')
                path = '/' + path;
            return ServerPath + path;
        }
        public static string DataPath
        {
            get
            {
                return ServerPath + "/app_data";
            }
        }

        public string ReadText(PostFileInfo fi)
        {
            using (var fs = new StreamReader(fi.ServerFileName, System.Text.Encoding.UTF8))
            {
                string v = fs.ReadToEnd();
                fs.Close();

                return v;
            }
        }
        public string ReadText(string path)
        {
            return this.ReadText(new PostFileInfo { ServerFilePath = MapPath(path) });
        }

        public DirectoryInfo CreateFolder(string path)
        {
            var dir = new DirectoryInfo(MapPath(path));
            if (dir.Exists == false)
            {
                dir.Create();
            }
            return dir;
        }
        public void DeleteFolder(string path)
        {
            var dir = new DirectoryInfo(MapPath(path));
            if (dir.Exists == false)
                return;

            var s = new Stack<DirectoryInfo>();
            s.Push(dir);

            while (s.Count > 0)
            {
                dir = s.Peek();
                var subs = s.Peek().GetDirectories();
                if (subs.Length == 0)
                {
                    dir = s.Pop();
                    foreach (var fi in dir.GetFiles())
                        fi.Delete();
                    dir.Delete();
                    continue;
                }
                foreach (var sub in subs)
                    s.Push(sub);
            }
        }

        public DirectoryInfo GetFolder(string path)
        {
            return new DirectoryInfo(MapPath(path));
        }

        public bool CopyFolder(string dir, string sub)
        {
            var dst = this.GetFolder(dir + "/" + sub);
            if (dst.Exists)
                return false;

            dst.Create();
            this.CopyTemplate(dst, this.GetFolder(dir + "/folder"));
            return true;
        }
        public void CopyTemplate(DirectoryInfo dst, DirectoryInfo src)
        {
            foreach (var di in src.GetDirectories())
            {
                var sub = dst.CreateSubdirectory(di.Name);
                this.CopyTemplate(sub, di);
            }

            foreach (var fi in src.GetFiles())
            {
                if (fi.Extension == ".aspx")
                    fi.CopyTo(dst.FullName + "/default.aspx");
            }
        }

        public PostFileInfo UploadFile(HttpPostedFile file, string folder, string serverFileName)
        {
            this.CreateFolder(folder);
            var fi = new PostFileInfo(file);

            if (folder[folder.Length - 1] != '/') folder += '/';
            string name = folder + (serverFileName != null ? serverFileName + fi.Extension : file.FileName);

            fi.SaveTo(MapPath(name));
            return fi;
        }

        public virtual void Download(PostBackCommand command, string attach, string fileName)
        {
            var req = new System.Net.WebClient();
            var response = HttpContext.Current.Response;
            try
            {
                if (attach == null)
                    attach = command.GetString("attach");
                if (fileName == null)
                    fileName = command.GetString("filename");

                response.Clear();
                response.ClearContent();
                response.ClearHeaders();

                response.Buffer = true;
                response.AddHeader("Content-Disposition", "attachment;filename=\"" + attach + "\"");
                byte[] data = req.DownloadData(fileName);
                response.BinaryWrite(data);
                response.End();
            }
            catch
            {
            }
            finally
            {
                req.Dispose();
            }
        }
    }
}