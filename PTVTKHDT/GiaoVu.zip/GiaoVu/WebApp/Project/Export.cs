﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

using VST.Office;
using VST.Office.Excel;

namespace App.Export
{
    public class FileController : App.FileController
    {
        public string GetTemplate(string name)
        {
            return MapPath("/app_data/template/" + name + ".zip");
        }
        public string GetExport(string name)
        {
            return MapPath("/app_data/export/" + name + ".xlsx");
        }
    }
    public class Entity : DataEntity, IData
    {
        public virtual object Content { get; set; }
        public virtual Type GetDataType(string name)
        {
            DataColumn c;
            DataRow r;
            if (this.GetCell(name, out r, out c))
                return c.DataType;

            return typeof(string);
        }

        public object this[string name]
        {
            get
            {
                return this.GetAttribute(name);
            }
        }

        public int STT { get; set; }
        public override object GetAttribute(string name)
        {
            if (name == "STT")
                return STT;
            return base.GetAttribute(name);
        }
    }
    public class EntityList : List<Entity>
    {
        public static explicit operator Array(EntityList src)
        {
            return src.ToArray();
        }
    }

    public class Ngay
    {
        DateTime value;
        public Ngay(object v)
        {
            value = (DateTime)v;
        }
        public object GetFiledValue(string name)
        {
            switch (name)
            {
                case "Y": return value.Year;
                case "M": return value.Month;
                case "D": return value.Day;
            }
            return null;
        }
        public override string ToString()
        {
            return this.value.ToString("dd/MM/yyyy");
        }
        public string ToString(string format)
        {
            return this.value.ToString(format);
        }
    }

    public class Engine
    {
        public Engine(PostBackCommand command)
        {
            if (command == null)
                command = new PostBackCommand();
            this.Controller.Command = command;
        }

        FileController _controller;
        public FileController Controller
        {
            get
            {
                if (_controller == null)
                    _controller = new FileController();
                return _controller;
            }
            set
            {
                _controller = value;
            }
        }

        string _templateFileName;
        public string TemplateFileName
        {
            get { return _templateFileName; }
            set { _templateFileName = this.Controller.GetTemplate(value); }
        }

        public string ServerFileName
        {
            get { return this.Controller.Command.GetString("filename"); }
            set { this.Controller.Command["filename"] = this.Controller.GetExport(value); }
        }

        public string AttachName
        {
            get
            {
                return this.Controller.Command.GetString("attach");
            }
            set
            {
                this.Controller.Command["attach"] = string.Format("{0} ({1:dd.MM.yyyy HH.mm}).xlsx", value, DateTime.Now);
            }
        }

        public ExportBuilder Builder { get; set; }

        public virtual void Run(Array values)
        {
            this.Builder.Load(this.TemplateFileName, this.ServerFileName);

            this.Builder.Export(values);
            this.Builder.Save();
        }

        public void Run(EntityList lst)
        {
            this.Run(lst.ToArray());
        }

        public virtual void StartDownload()
        {
            this.Controller.Download(this.Controller.Command, this.AttachName, this.ServerFileName);
        }
    }
    public class TableEngine : Engine
    {
        public TableEngine(PostBackCommand command)
            : base(command)
        {
            this.Builder = new VST.Office.Excel.ListExport();
        }
    }

    public abstract class MultiListContentEntity : Entity
    {
        public abstract object ParentKey { get; }
    }

    public class MultiListContentEntityList : List<MultiListContentEntity>
    {
        new public void Add(MultiListContentEntity item)
        {
            base.Add(item);
            item.STT = this.Count;
        }
    }

    public class MultiListHeaderEntity : Entity
    {
        public MultiListHeaderEntity() { }
        public MultiListHeaderEntity(MultiListContentEntityList list)
        {
            this.Row = list[0].Row;
            this.Content = list.ToArray();
        }
    }

    public class MultiListEngine<TContent, THeader> : Engine
        where TContent : MultiListContentEntity, new()
        where THeader : MultiListHeaderEntity, new()
    {
        public MultiListEngine(PostBackCommand command)
            : base(command)
        {
            this.Builder = new VST.Office.Excel.ListExport();
        }

        protected virtual EntityList CreateEntityList(System.Collections.IList data)
        {
            var map = new Dictionary<object, MultiListContentEntityList>();
            foreach (MultiListContentEntity e in data)
            {
                var key = e.ParentKey;
                MultiListContentEntityList list;
                if (map.TryGetValue(key, out list) == false)
                    map.Add(key, list = new MultiListContentEntityList());
                list.Add(e);
            }

            var res = new Export.EntityList();
            foreach (var p in map)
            {
                res.Add(new THeader { Row = p.Value[0].Row, Content = p.Value.ToArray() });
            }
            return res;
        }
    }
}