﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.Project
{
    public class Cookie : XmlEntity
    {
        string _prefix;
        public string Prefix
        {
            get
            {
                if (_prefix == null)
                    _prefix = Engine.Page.Request.Url.Host;
                return _prefix;
            }
            set
            {
                _prefix = value;
            }
        }
        public HttpCookieCollection Map { get; set; }

        //public Cookie(App.Page page)
        //{
        //    this.Prefix = page.Request.Url.Host;
        //    this.Map = page.Response.Cookies;
        //}

        public void Write(string key, string value, int days)
        {
            var cookie = this.Map[Prefix + key];
            cookie.Value = value;
            cookie.Expires = DateTime.Now.AddDays(days);
        }
        public void WriteXml(int days)
        {
            string s = "";
            foreach (System.Xml.XmlAttribute a in this.Node.Attributes)
            {
                s += string.Format("{0}='{1}' ", a.Name, a.Value);
            }
            this.Write(this.Node.Name, s, days);
        }
        public void Remove(string key)
        {
            this.Write(key, string.Empty, -1);
        }

        public string Read(string key)
        {
            var cookie = this.Map[this.Prefix + key];
            if (cookie == null)
                return string.Empty;
            return cookie.Value;
        }
        public void LoadXml(string key)
        {
            var s = this.Read(key);

            var doc = new System.Xml.XmlDocument();
            doc.LoadXml("<" + key + " " + s + "/>");
            this.Node = doc.DocumentElement;
        }
    }

    public class CookieReader : Cookie
    {
        public CookieReader()
            : this(Engine.Page.Request)
        {
        }
        public CookieReader(HttpRequest request)
        {
            this.Map = request.Cookies;
            this.Prefix = request.Url.Host;
        }

        public Service.AccountInfo GetUser()
        {
            this.LoadXml("user");
            return new Service.AccountInfo(GetString("name"), GetString("pass"));
        }
    }
    public class CookieWriter : Cookie
    {
        public CookieWriter()
        {
            this.Map = Engine.Page.Response.Cookies;
            this.Prefix = Engine.Page.Request.Url.Host;
        }
    }
}