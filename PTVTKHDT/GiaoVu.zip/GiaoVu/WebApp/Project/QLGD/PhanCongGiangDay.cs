﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.PhanCongGiangDay
{
    public class GiangVien
    {
        public object Id { get; set; }
        public int SoLop { get; set; }
    }
    public class GiaoKet : Dictionary<string, Queue<GiangVien>>
    {
        public static string GetKey(DataEntity e)
        {
            return string.Format("{0}{1}{2}{3}", e.GetAttributes("MaHP", "MaCT", "LoaiLop", "{HocKy}"));
        }

        public GiaoKet()
        {
            var data = new DefaultCollection("GiangVienGiaoKet");
            foreach (var e in data.Select())
            {
                var key = GiaoKet.GetKey(e);
                Queue<GiangVien> lst = null;
                if (this.TryGetValue(key, out lst) == false)
                    this.Add(key, lst = new Queue<GiangVien>());

                lst.Enqueue(new GiangVien { Id = e.GetInt("GiangVienId"), SoLop = e.GetInt("SoLop") });
            }
        }
    }
    public class Engine
    {
        public static int GetGiangVienLevel()
        {
            var chucDanh = new DefaultCollection("ChucDanh");
            return (int)chucDanh.Find("GV").GetAttribute("PhanCapGD");
        }

        public static void ResetCBGD()
        {
            foreach (var e in new DefaultCollection("Lop").Select())
                e.SetAttribute("GiangVienId", null);
            foreach (var e in new DefaultCollection("TKB").Select())
                e.SetAttribute("GiangVienId", null);
        }

        public void PhanCong()
        {
            var cacLop = new DefaultCollection("Lop");
            var giaoKet = new GiaoKet();
            foreach (var lop in cacLop.Select())
            {
                var key = GiaoKet.GetKey(lop);
                Queue<GiangVien> lst;

                if (giaoKet.TryGetValue(key, out lst) && lst.Count > 0)
                {
                    var g = lst.Peek();
                    lop.SetAttribute("GiangVienId", g.Id);

                    if (--g.SoLop == 0)
                        lst.Dequeue();
                }
            }

            var tkb = new DefaultCollection("TKB");
            var colGV = tkb.CreateAttribute("GV", typeof(int), "parent(Lop).GiangVienId");

            foreach (var e in tkb.Select())
            {
                e.SetAttribute("GiangVienId", e.GetAttribute("GV"));
            }

            tkb.Table.Columns.Remove(colGV);
        }

        //public static void InitPhanCapCBGD()
        //{
        //    var canBo = new DefaultCollection("CanBo");
        //    var phanCapCB = new DefaultCollection("PhanCapCBGD");
        //    var gvLevel = GetGiangVienLevel();

        //    phanCapCB.Table.Clear();
        //    foreach (var cb in canBo.Select())
        //    {
        //        object pccd = cb.GetAttribute("ChucDanh.PhanCapGD");
        //        if (pccd.Equals(string.Empty) || pccd.Equals(0))
        //            continue;

        //        int max = (int)pccd;
        //        int min = max;
        //        if (min > gvLevel)
        //            min = gvLevel;
        //        phanCapCB.Insert(cb.ID, min, max);
        //    }

        //    phanCapCB.UpdateDataBase();
        //}

        //public static Single TinhGioGiangDayTB()
        //{
        //    var gvLevel = GetGiangVienLevel();

        //    var klgd = new KLGD.DataCollection();
        //    klgd.Calculate(null);

        //    Single qd = 0;
        //    foreach (var e in klgd.Select())
        //    {
        //        var level = (int)e.GetAttribute("PhanCapGD.Level");
        //        if (level >= gvLevel)
        //            qd += (Single)e.GetAttribute("QuyDoi");
        //    }

        //    var giangVien = new DataCollection<TKB.GiangVien>("PhanCapCBGD");
        //    giangVien.DataEngine.And("Min >= " + gvLevel);
        //    soGV = giangVien.DataEngine.Count;

        //    var n = qd / soGV;

        //    foreach (var g in giangVien.Select())
        //    {
        //        g.SoGio = n;
        //    }

        //    return SoGioTB = n;
        //}

        //static void PhanCong(TKB.DataCollection tkb, int min, int max)
        //{
        //    var map = tkb.LoadGiangDay(min, max);

        //    List<object> done = new List<object>();
        //    foreach (var p in map)
        //    {
        //        if (p.Key.Equals("ET7030"))
        //        {
        //        }

        //        var giangVien = p.Value.GiangVien;
        //        if (giangVien.Count == 0)
        //        {
        //            done.Add(p.Key);
        //            continue;
        //        }

        //        if (giangVien.Count == 1)
        //        {
        //            var gv = giangVien[0];
        //            foreach (var t in p.Value.TKB)
        //            {
        //                t.SetGiangVien(gv);
        //            }
        //            done.Add(p.Key);
        //            continue;
        //        }

        //        if (p.Value.Nhom.Count == giangVien.Count)
        //        {
        //            int i = 0;
        //            foreach (var n in p.Value.Nhom.Values)
        //            {
        //                var g = giangVien[i++];
        //                foreach (var t in n)
        //                    t.SetGiangVien(g);
        //            }
        //        }
        //    }
        //}

        //public static void Run()
        //{
        //    var nTB = TinhGioGiangDayTB();
        //    var tkb = new TKB.DataCollection();
        //    var lop = new KLGD.LopCollection("Lop");

        //    PhanCong(tkb, 10, 10);
        //    PhanCong(tkb, gvLevel, 100);
        //}
    }

    //public interface IPriorityElement
    //{
    //    bool IsHigher(IPriorityElement e);
    //}

    //public class PriorityQueue<T> : Queue<T>
    //    where T : IPriorityElement
    //{
    //    T[] _values;

    //    void BuildHeap(int i, int n)
    //    {
    //        int j = (i << 1) + 1;
    //        T e = _values[i];

    //        while (j < n)
    //        {
    //            int k = j + 1;
    //            if (k < n && _values[k].IsHigher(_values[j]))
    //                j = k;

    //            if (e.IsHigher(_values[j]))
    //                break;

    //            _values[i] = _values[j];
    //            i = j;
    //            j = (i << 1) + 1;
    //        }
    //        _values[i] = e;
    //    }
    //    void BuildAll()
    //    {
    //        _values = this.ToArray();
    //        int n = this.Count;
    //        for (int i = n / 2 - 1; i >= 0; i--)
    //            BuildHeap(i, n);
    //    }

    //    public IEnumerable<T> Sort()
    //    {
    //        BuildAll();
    //        int n = this.Count - 1;

    //        while (n > 0)
    //        {
    //            var e = _values[0]; _values[0] = _values[n]; _values[n] = e;
    //            BuildHeap(0, n--);
    //        }

    //        return _values;
    //    }

    //    public void Rebuild()
    //    {
    //        BuildHeap(0, this.Count);
    //    }

    //    new public T Peek
    //    {
    //        get
    //        {
    //            if (_values == null)
    //                this.BuildAll();
    //            return _values[0];
    //        }
    //    }
    //}

    //public class Lop : DataEntity, IPriorityElement
    //{
    //    List<TKB.Entity> _tkb;
    //    public List<TKB.Entity> TKB
    //    {
    //        get
    //        {
    //            if (_tkb == null)
    //                _tkb = new List<TKB.Entity>();

    //            return _tkb;
    //        }
    //    }

    //    public Level PhanCap = new Level();
    //    public Single QuyDoi;
    //    public object MaHP;
    //    public int MucUT;

    //    public bool IsHigher(IPriorityElement e)
    //    {
    //        return MucUT < ((Lop)e).MucUT;
    //    }
    //}
    //public class LopCollection : DataCollection<Lop>
    //{
    //    public LopCollection()
    //        : base("Lop")
    //    {
    //        new KLGD.DataCollection().Calculate(null);

    //        var map = this.CreateDataMap("Ma");
    //        foreach (var e in map.Values)
    //        {
    //            object v = e.GetAttribute("QuyDoi");
    //            if (v.Equals(string.Empty) == false)
    //                e.QuyDoi = (Single)v;

    //            e.MaHP = e.GetString("MaHP");

    //            var a = (int)e.GetAttribute("LoaiLop.PhanCapGD");
    //            var b = (int)e.GetAttribute("CTDT.PhanCapGD");

    //            a = Math.Max(a, b);
    //            e.PhanCap.Min = e.PhanCap.Max = a;
    //            e.MucUT = (int)e.GetAttribute("CTDT.UuTienPC");

    //            this.Add(e);
    //        }
    //        foreach (var t in new TKB.DataCollection())
    //        {
    //            var malop = t.GetAttribute("MaLop");
    //            var lop = map[malop];
    //            lop.TKB.Add(t);
    //            t.SetAttribute("PhanCapGD", lop.PhanCap.Max);
    //        }
    //    }
    //}

    //public class Level
    //{
    //    public int Min;
    //    public int Max;

    //    public Level(int a, int b) { Min = a; Max = b; }
    //    public Level(int a) : this(a, a) { }
    //    public Level() : this(0, 100) { }

    //    public bool Contains(int value) { return Min <= value && Max >= value; }
    //    public bool Contains(Level level) { return Min <= level.Min && Max >= level.Max; }

    //    public override string ToString()
    //    {
    //        return string.Format("Min = {0}, Max = {1}", Min, Max);
    //    }
    //}
    //public partial class GiangVien : DataEntity, IPriorityElement
    //{
    //    public Level PhanCap = new Level();
    //    public Single SoGio;

    //    public Dictionary<object, int> HocPhan = new Dictionary<object, int>();
    //    public void SetLop(Lop e)
    //    {
    //        SoGio += e.QuyDoi;
    //        if (HocPhan.ContainsKey(e.MaHP))
    //            HocPhan[e.MaHP]++;
    //        else
    //            HocPhan.Add(e.MaHP, 1);
    //    }

    //    public bool IsHigher(IPriorityElement e)
    //    {
    //        return ((GiangVien)e).SoGio >= SoGio;
    //    }

    //    //List<TKB.Entity> _tkb;
    //    public bool SetTKB(Lop lop)
    //    {
    //        //if (_tkb == null)
    //        //    _tkb = new List<TKB.Entity>();

    //        //if (this.PhanCap.Min >= 30)
    //        //{
    //        //    foreach (var a in lop.TKB)
    //        //    {
    //        //        foreach (var t in _tkb)
    //        //            t.CheckTrung(a);
    //        //    }
    //        //}

    //        foreach (var t in lop.TKB)
    //        {
    //            t.Reset();
    //            t.SetAttribute("GiangVienId", this.ID);
    //            //_tkb.Add(t);
    //        }
    //        return true;
    //    }
    //}
    //public partial class GiangVienCollection : DataCollection<GiangVien>
    //{
    //    Dictionary<object, GiangVien> _map;
    //    public GiangVienCollection()
    //        : base("PhanCapCBGD")
    //    {
    //        _map = this.CreateDataMap("GiangVienId");
    //        foreach (var g in _map.Values)
    //        {
    //            g.PhanCap.Min = g.GetInt("Min");
    //            g.PhanCap.Max = g.GetInt("Max");
    //        }
    //    }
    //    new public GiangVien Find(object id)
    //    {
    //        GiangVien g = null;
    //        _map.TryGetValue(id, out g);
    //        return g;
    //    }

    //    public void UpdateHocPhan()
    //    {
    //        var cbgd = new DefaultCollection("CBGD").CreateDataMap("GiangVienId+MaHP");
    //        foreach (var e in cbgd.Values)
    //            e.SetAttribute("SoLop", null);

    //        foreach (var gv in _map.Values)
    //        {
    //            var hp = new StringList(", ");
    //            var soLop = 0;
    //            foreach (var p in gv.HocPhan)
    //            {
    //                var key = string.Format("{0}{1}", gv.ID, p.Key);
    //                cbgd[key].SetAttribute("SoLop", p.Value);

    //                hp.Add(p.Key.ToString());
    //                soLop += p.Value;
    //            }

    //            gv.SetAttribute("HP", hp);
    //            gv.SetAttribute("SoLop", soLop);
    //            gv.SetAttribute("SoGio", gv.SoGio);
    //        }
    //        base.UpdateDataBase();
    //    }
    //}
    //public class GiangVienQueue : PriorityQueue<GiangVien>
    //{
    //}

    //public class HocPhan
    //{
    //    public Level PhanCap = new Level();
    //    public PriorityQueue<Lop> CacLop = new PriorityQueue<Lop>();
    //    public GiangVienQueue GiangVien = new GiangVienQueue();

    //    public bool Calculate()
    //    {
    //        GiangVien.Peek.SetLop(CacLop.Dequeue());
    //        if (CacLop.Count > 0)
    //        {
    //            GiangVien.Rebuild();
    //            return true;
    //        }
    //        return false;
    //    }
    //}
    //public class HocPhanMap : Dictionary<object, HocPhan>
    //{
    //    public HocPhanMap(GiangVienCollection giangVien, bool phanCong = false)
    //    {
    //        foreach (var e in new LopCollection())
    //        {
    //            this[e.MaHP].CacLop.Enqueue(e);
    //        }
    //        foreach (var e in new DefaultCollection("CBGD").Select())
    //        {
    //            var key = e.GetString("MaHP");
    //            if (this.ContainsKey(key))
    //            {
    //                var cb = e.GetAttribute("GiangVienId");
    //                var g = giangVien.Find(cb);
    //                if (g != null)
    //                {
    //                    if (phanCong)
    //                    {
    //                        var soLop = e.GetInt("SoLop");
    //                        if (soLop == 0) continue;

    //                        g.HocPhan.Add(key, soLop);
    //                    }

    //                    this[key].GiangVien.Enqueue(g);
    //                }
    //            }
    //        }
    //    }

    //    public HocPhanMap(HocPhanMap src, Level level)
    //    {
    //        foreach (var p in src)
    //        {
    //            if (!p.Value.PhanCap.Contains(level))
    //                continue;

    //            var hp = new HocPhan();
    //            foreach (var lop in p.Value.CacLop)
    //                if (level.Contains(lop.PhanCap))
    //                    hp.CacLop.Enqueue(lop);

    //            if (hp.CacLop.Count > 0)
    //            {
    //                foreach (var g in p.Value.GiangVien)
    //                {
    //                    if (g.PhanCap.Contains(level))
    //                        hp.GiangVien.Enqueue(g);
    //                }
    //                if (hp.GiangVien.Count > 0)
    //                    this.Add(p.Key, hp);
    //            }
    //        }
    //    }

    //    public void Calculate()
    //    {
    //        while (this.Count > 0)
    //        {
    //            var done = new List<object>();
    //            foreach (var p in this)
    //            {
    //                if (p.Value.Calculate() == false)
    //                    done.Add(p.Key);
    //            }

    //            foreach (var key in done)
    //                this.Remove(key);
    //        }
    //    }

    //    public void PhanCong()
    //    {
    //        foreach (var p in this)
    //        {
    //            var hp = p.Value;
    //            foreach (var lop in hp.CacLop)
    //                foreach (var t in lop.TKB)
    //                    t.SetAttribute("GiangVienId", null);

    //            foreach (var gv in hp.GiangVien)
    //            {
    //                int count = 0;
    //                gv.HocPhan.TryGetValue(p.Key, out count);

    //                var trung = new List<Lop>();
    //                while (count > 0)
    //                {
    //                    if (hp.CacLop.Count == 0)
    //                        break;

    //                    var lop = hp.CacLop.Dequeue();
    //                    //if (!gv.PhanCap.Contains(lop.PhanCap))
    //                    //{
    //                    //    hp.CacLop.Enqueue(lop);
    //                    //    continue;
    //                    //}

    //                    ////if (gv.SetTKB(lop) == false)
    //                    ////    trung.Add(lop);
    //                    gv.SetTKB(lop);
    //                    count--;
    //                }

    //                //foreach (var e in trung)
    //                //    hp.CacLop.Enqueue(e);

    //                if (hp.CacLop.Count == 0)
    //                    break;
    //            }
    //        }
    //    }

    //    new public HocPhan this[object key]
    //    {
    //        get
    //        {
    //            HocPhan e = null;
    //            if (this.TryGetValue(key, out e) == false)
    //                this.Add(key, e = new HocPhan());
    //            return e;
    //        }
    //    }
    //}

    public partial class TKBEntity : App.DataEntity
    {
        public override void Execute(PostBackCommand command)
        {
            this.SetAttribute("Trung", null);
            this.SetAttribute("GiangVienId", command["GiangVien"]);
        }
        public override void UpdateView(AppView view)
        {
            base.UpdateView(view);

            var frm = (Json.Paragraph)view.JsonTemplate;

            frm.SubCaption = string.Format("{0}, {1}, {2}, {3}", this.GetAttributes("MaLop", "Lop.MaHP", "HocPhan.Ten", "Lop.LoaiLop"));
            var controls = (Json.Collection)frm["controls"];
            var gc = (Json.Collection)controls["GiangVien"];
            var items = gc.CreateArray("items");

            gc["value"] = this.GetAttribute("GiangVienId");

            var hp = this.GetAttribute("Lop.MaHP");
            var pcgd = new DefaultCollection("CBGD");
            var temp = new DefaultCollection("PhanCapCBGD");

            const string thuc = "Thuc";
            temp.CreateAttribute(thuc, typeof(Single), "sum(child(Lop).QuyDoi)");

            var thucName = "PhanCapCBGD." + thuc;
            foreach (var e in pcgd.Select("MaHP='" + hp + "'"))
            {
                var item = items.CreateCollection();

                var cb = e.GetAttribute("GiangVienId");
                item.Add("value", cb);
                item.Add("caption", string.Format("{0} ({1:N0})", e.GetAttributes("CanBo.HoTen", thucName)));
            }

            temp.RemoveAttribute(thuc);
        }
    }
    public class TKBController : App.Controller
    {
        protected override void OpenEntity(IEntity e)
        {
            if (!(e is TKBEntity))
                e = new TKBEntity { Row = ((DataEntity)e).Row };

            base.OpenEntity(e);
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Update)
            {
                var t = (DataEntity)(new DefaultCollection("TKB").Find(command.CommandValue));
                var lop = (DataEntity)(new DefaultCollection("Lop").Find(t.GetAttribute("MaLop")));
                lop.SetAttribute("GiangVienId", command["GiangVien"]);

                this.UpdateDataBase(null);
            }
            base.ProcessRequest(command);
        }
    }

    public class TKBPage : App.Page
    {
        protected override AppView CreateView(string name)
        {
            if (this.Controller.Model is IEntity)
                name = "PCGDChiTiet";
            return base.CreateView(name);
        }
    }
}

namespace App.KLGD
{
    interface IBangHeSo : System.Collections.IEnumerable
    {
        void Calculate(Entity e);
    }
    public class HeSoEntity : DataEntity
    {
        public void SetHeSo(DataEntity e)
        {
            e.SetAttribute(this.Name, this.GetAttribute("HeSo"));
        }
    }
    public class Range : HeSoEntity
    {
        public int Min, Max;
        public bool Contains(int value)
        {
            return value >= Min && value <= Max;
        }
    }
    public class BangHSLop : DataCollection<Range>, IBangHeSo
    {
        public override List<Range> Select(string filter, string sort)
        {
            foreach (var e in base.Select(null, "Min"))
            {
                e.Min = e.GetInt("Min");
                e.Max = e.GetInt("Max");
            }
            return this;
        }
        public BangHSLop()
            : base("HSLop")
        {
            this.Select();
        }
        public void Calculate(Entity e)
        {
            var sl = e.GetInt("SoLuong");
            foreach (var v in this)
            {
                if (v.Contains(sl))
                {
                    v.SetHeSo(e);
                    return;
                }
            }
        }
    }

    public class BangHS : DataCollection<HeSoEntity>, IBangHeSo
    {
        public string[] KeyNames { get; set; }
        public BangHS(string name)
            : base(name)
        {
            KeyNames = TextTemplate.GetValue(this.GetType().Name).Split(',');
            this.Select();
        }

        Dictionary<string, HeSoEntity> _map;
        protected virtual string GetKeyValue(Entity e)
        {
            return e.MaLoaiLop;
        }
        public override List<HeSoEntity> Select(string filter, string sort)
        {
            _map = new Dictionary<string, HeSoEntity>();
            var names = this.KeyNames;
            foreach (var e in base.Select(filter, sort))
            {
                string s = "";
                foreach (var name in names)
                    s += e.GetAttribute(name);
                _map.Add(s, e);
            }
            return this;
        }

        public virtual void Calculate(Entity e)
        {
            HeSoEntity v = null;
            if (_map.TryGetValue(this.GetKeyValue(e), out v))
                v.SetHeSo(e);
        }
    }

    class BangHSHK : BangHS
    {
        public BangHSHK() : base("HSHK") { }
        protected override string GetKeyValue(Entity e)
        {
            var v = base.GetKeyValue(e) + (e.GetInt("HocKy") % 10);
            return v;
        }
    }

    public class Lop : App.DataEntity
    {
        public object SoTC { get; set; }
        public object MaLop { get; set; }
        public object SoLuong { get; set; }
        public string LoaiLop { get; set; }
        public object HocKy { get; set; }
        public string MaCT { get; set; }

        string[] CTKL;

        public Lop() { }

        public virtual void Calculate()
        {
            CTKL = ((string)this.GetAttribute("HocPhan.CTKL")).Split('-');
            if (CTKL.Length < 4)
                CTKL = new string[] { "0", "0", "0", "0" };
            this.MaLop = this.ID;
            this.HocKy = this.GetAttribute("HocKy");
            this.SoLuong = this.GetInt("SoSV");
            this.LoaiLop = (string)this.GetAttribute("LoaiLop");
            this.MaCT = this.GetString("MaCT");
            this.SoTC = CTKL[(int)this.GetAttribute("LoaiLop.CTKL")];
        }

        public Lop LopChinh
        {
            get
            {
                if (MaLop == null)
                    this.Calculate();

                if (LoaiLop == "LT" && CTKL[1] != "0")
                    LoaiLop = "LT+BT";

                return this;
            }
        }

        bool IsLTBT
        {
            get { return LoaiLop == "LT+BT"; }
        }

        public Lop LopBT
        {
            get
            {
                if (!IsLTBT)
                    return null;

                this.LoaiLop = "BT";
                this.SoTC = CTKL[1];
                return this;
            }
        }

        public object[] KLGD
        {

            get
            {
                if (this.SoTC.Equals("0"))
                    return null;

                var loai = this.LoaiLop;
                if (IsLTBT) loai = "LT";

                return new object[] { null, HocKy, MaLop, loai, SoTC, SoLuong, MaCT };
            }
        }
    }
    public class LopCollection : App.DataCollection<Lop>
    {
        public LopCollection(string name)
            : base(name)
        {
            Global.DataProvider.Select("KLGD");
        }
    }

    public partial class Entity : App.DataEntity
    {
        string _maLoaiLop;
        public string MaLoaiLop
        {
            get
            {
                if (_maLoaiLop == null)
                {
                    var names = TextTemplate.GetValue("BangHS").Split(',');
                    _maLoaiLop = string.Format("{0}{1}", this.GetAttributes(names));
                }
                return _maLoaiLop;
            }
        }
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection()
            : base("KLGD")
        {
        }

        IBangHeSo[] cacHeSo = new IBangHeSo[] {
                new BangHSLop(),
                new BangHSHK(),
                new BangHS("HSGD"),
                new BangHS("HSDA"),
                new BangHS("HSTN"),
            };

        public Entity InsertLop(Lop lop)
        {
            if (lop != null)
            {
                var v = lop.KLGD;
                if (v != null)
                {
                    var e = this.Insert(v);
                    foreach (var model in cacHeSo)
                        model.Calculate(e);
                    return e;
                }
            }
            return null;
        }

        public void Calculate(string name)
        {
            if (name == null)
                name = "Lop";

            this.Table.Clear();
            foreach (var src in new LopCollection(name).Select())
            {
                this.InsertLop(src.LopChinh);
                this.InsertLop(src.LopBT);
            }
        }
    }
}