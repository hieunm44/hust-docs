﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace App.TKB
{
    public class Entity : DataEntity
    {
        public int BD { get; set; }
        public int KT { get; set; }
        public string Ngay { get; set; }
        public string Tuan { get; set; }
        public string Phong { get; set; }

        string _nha;
        public string ToaNha
        {
            get
            {
                if (_nha == null)
                {
                    _nha = this.Phong;
                    var v = _nha.ToCharArray();
                    for (int i = 0; i < v.Length; i++)
                    {
                        if (v[i] < '0')
                        {
                            _nha = new string(v, 0, i);
                            break;
                        }
                    }
                }
                return _nha;
            }
        }

        public Entity() { }
        public Entity(DataRow row)
        {
            this.Row = row;
            this.Calculate();
        }
        public Entity(DataEntity e) : this(e.Row)
        {
        }

        public void Calculate()
        {
            //var a = (int)GetAttribute("LoaiLop.PhanCapGD");
            //var b = (int)GetAttribute("CTDT.PhanCapGD");

            //PhanCapGD = Math.Max(a, b);

            this.Ngay = string.Format("{0}{1}{2}{3}", this.GetAttributes("Thu", "Buoi", "Tuan", "Kip"));
            if (this.Ngay != string.Empty)
            {
                this.BD = this.GetInt("TietBD");
                this.KT = this.GetInt("TietKT");

                this.Phong = this.GetString("Phong");
                var kip = this.GetString("Kip");

                if (kip != string.Empty && char.ToUpper(this.GetString("Kip")[0]) == 'C')
                {
                    BD += 6;
                    KT += 6;
                }
            }
        }

        public bool IsTrung(Entity e)
        {
            if (Ngay == string.Empty || Ngay != e.Ngay)
                return false;

            return !(BD > e.KT || KT < e.BD);
        }
        public void CheckTrung(Entity e)
        {
            if (IsTrung(e))
            {
                e.SetAttribute("Trung", 1);
                this.SetAttribute("Trung", 1);
            }
        }
        public bool IsLienKe(Entity e)
        {
            if (Ngay == string.Empty || Ngay != e.Ngay)
                return false;

            return KT == e.BD - 1;
        }

        public void Reset()
        {
            this.SetAttribute("GiangVienId", null);
            this.SetAttribute("Trung", null);
        }
    }

    public class NhomTKB : Dictionary<Entity, List<Entity>>
    {
        public void Add(Entity e)
        {
            foreach (var p in this)
            {
                if (p.Key.IsLienKe(e) || e.IsLienKe(p.Key))
                {
                    p.Value.Add(e);
                    if (e.KT > p.Key.KT)
                        p.Key.KT = e.KT;
                    else
                        p.Key.BD = e.BD;
                    return;
                }
            }

            var lst = new List<Entity>();
            lst.Add(e);
            base.Add(new Entity(e), lst);
        }
    }

    public class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection()
            : base("TKB")
        {
            foreach (var e in this.Select())
            {
                e.Calculate();
            }
        }

        //public override List<Entity> Select(string filter, string sort)
        //{
        //    var col = this.Table.Columns.Add("MaHP");
        //    col.Expression = "parent(Lop_TKB).MaHP";

        //    if (sort == null)
        //        sort = "MaHP, Thu, TietBD";

        //    this.DataEngine.Sort = sort;
        //    foreach (DataRowView e in this.DataEngine)
        //    {
        //        var t = new Entity(e.Row);
        //        if (t.Thu > 0)
        //            this.Add(t);
        //    }
        //    this.Table.Columns.Remove(col);
        //    return this;
        //}

        //public HocPhanMap LoadGiangDay(int minLevel, int maxLevel)
        //{
        //    var map = new HocPhanMap { PhanCap = new VungPhanCap(minLevel, maxLevel) };
        //    foreach (var e in this)
        //    {
        //        if (e.PhanCapGD < minLevel || e.PhanCapGD > maxLevel)
        //            continue;

        //        object key = e.GetAttribute("Lop.MaHP");
        //        map[key].TKB.Add(e);
        //    }

        //    map.LoadGiangVien();
        //    return map;
        //}

        //public HocPhanMap LoadHocPhan()
        //{
        //    var map = new HocPhanMap();
        //    foreach (var e in this)
        //    {
        //        object key = e.GetAttribute("Lop.MaHP");
        //        map[key].TKB.Add(e);
        //    }

        //    map.LoadGiangVien();
        //    return map;
        //}
    }

    //public class GiangVien : DataEntity
    //{
    //    public VungPhanCap PhanCap { get; set; }

    //    public Single SoGio
    //    {
    //        get { return (Single)this.GetAttribute("SoGio"); }
    //        set { this.SetAttribute("SoGio", value); }
    //    }
    //}

    //public class HocPhanEntity : DataEntity
    //{
    //    List<Entity> _tkb;
    //    List<GiangVien> _gv;

    //    NhomTKB _nhom;
    //    public NhomTKB Nhom
    //    {
    //        get
    //        {
    //            if (_nhom == null)
    //            {
    //                _nhom = new NhomTKB();
    //                foreach (var t in _tkb)
    //                    _nhom.Add(t);

    //            }
    //            return _nhom;
    //        }
    //    }

    //    public List<Entity> TKB
    //    {
    //        get
    //        {
    //            if (_tkb == null)
    //                _tkb = new List<Entity>();
    //            return _tkb;
    //        }
    //    }
    //    public List<GiangVien> GiangVien
    //    {
    //        get
    //        {
    //            if (_gv == null)
    //                _gv = new List<GiangVien>();
    //            return _gv;
    //        }
    //    }

    //    Single LT;
    //    Single BT;
    //    Single Khac;

    //    public void TinhKhoiLuong(DataEntity e)
    //    {
    //        var loai = e.GetString("LoaiLop");
    //        var q = (Single)e.GetAttribute("QuyDoi");
    //        if (loai == "LT") LT += q;
    //        else if (loai == "BT") BT += q;
    //        else Khac += q;
    //    }
    //    public override object GetAttribute(string name)
    //    {
    //        switch (name)
    //        {
    //            case "SoBuoi": return this.TKB.Count;
    //            case "SoGV": return this.GiangVien.Count;
    //            case "LT": return LT;
    //            case "BT": return BT;
    //            case "Khac": return Khac;
    //            case "QuyDoi": return LT + BT + Khac;
    //        }
    //        return base.GetAttribute(name);
    //    }
    //}

    //public class VungPhanCap
    //{
    //    public int Min { get; set; }
    //    public int Max { get; set; }

    //    public VungPhanCap()
    //    {
    //        this.Min = 0;
    //        this.Max = 100;
    //    }
    //    public VungPhanCap(int min, int max)
    //    {
    //        Min = min;
    //        Max = max;
    //    }

    //    public bool Contains(VungPhanCap v)
    //    {
    //        return Min <= v.Min && Max >= v.Max;
    //    }
    //}
    //public class HocPhanMap : Dictionary<object, HocPhanEntity>
    //{

    //    public VungPhanCap PhanCap { get; set; }
    //    DataCollection<HocPhanEntity> _data = new DataCollection<HocPhanEntity>("HocPhan");
    //    public void LoadGiangVien()
    //    {
    //        var phancap = new DataCollection<GiangVien>("PhanCapCBGD");
    //        var map = new Dictionary<object, GiangVien>();
    //        foreach (var e in phancap.Select())
    //        {
    //            e.PhanCap = new VungPhanCap(e.GetInt("Min"), e.GetInt("Max"));
    //            map.Add(e.ID, e);
    //        }

    //        var gv = new DefaultCollection("CBGD");
    //        foreach (var e in gv.Select())
    //        {
    //            HocPhanEntity a = null;
    //            var hp = e.GetString("MaHP");
    //            if (this.TryGetValue(hp, out a))
    //            {
    //                var cb = e.GetInt("GiangVienId");
    //                if (map.ContainsKey(cb))
    //                {
    //                    var g = map[cb];
    //                    if (this.PhanCap.Contains(g.PhanCap))
    //                        a.GiangVien.Add(map[cb]);
    //                }
    //            }
    //        }
    //    }

    //    public void TinhKhoiLuong()
    //    {
    //        var kl = new DefaultCollection("KLGD");
    //        foreach (var e in kl.Select())
    //        {
    //            var a = this[e.GetAttribute("Lop.MaHP")];
    //            a.TinhKhoiLuong(e);
    //        }
    //    }

    //    new public HocPhanEntity this[object key]
    //    {
    //        get
    //        {
    //            HocPhanEntity e = null;
    //            if (this.TryGetValue(key, out e) == false)
    //                this.Add(key, e = (HocPhanEntity)_data.Find(key));
    //            return e;
    //        }
    //    }
    //}
}

