﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    partial class DataEntity
    {
        public Single GetSingleValue(string name)
        {
            var v = this.GetAttribute(name);
            if (v.Equals(string.Empty))
                return 0;
            return (Single)v;
        }
    }
}

namespace App.Project.GiaoKet
{
    public interface IPriorityElement
    {
        bool IsHigher(IPriorityElement e);
    }

    public class PriorityQueue<T> : Queue<T>
        where T : IPriorityElement
    {
        T[] _values;

        void BuildHeap(int i, int n)
        {
            int j = (i << 1) + 1;
            T e = _values[i];

            while (j < n)
            {
                int k = j + 1;
                if (k < n && _values[k].IsHigher(_values[j]))
                    j = k;

                if (e.IsHigher(_values[j]))
                    break;

                _values[i] = _values[j];
                i = j;
                j = (i << 1) + 1;
            }
            _values[i] = e;
        }
        void BuildAll()
        {
            _values = this.ToArray();
            int n = this.Count;
            for (int i = n / 2 - 1; i >= 0; i--)
                BuildHeap(i, n);
        }

        public IEnumerable<T> Sort()
        {
            BuildAll();
            int n = this.Count - 1;

            while (n > 0)
            {
                var e = _values[0]; _values[0] = _values[n]; _values[n] = e;
                BuildHeap(0, n--);
            }

            return _values;
        }

        public void Rebuild()
        {
            BuildHeap(0, this.Count);
        }

        public T Top
        {
            get
            {
                if (_values == null)
                    this.BuildAll();
                return _values[0];
            }
        }
    }

    //public class HocKy : List<Lop>
    //{
    //    int _index;
    //    public HocKy(int index)
    //    {
    //        _index = index;
    //    }

    //    public bool TryInsert(Lop lop)
    //    {
    //        var i = ((int)lop.HocKy & 3);
    //        if (i == _index)
    //        {
    //            this.Add(lop);
    //            return true;
    //        }
    //        return false;
    //    }
    //}

    //public class HocKyCollection : List<HocKy>
    //{
    //    public HocKyCollection()
    //    {
    //        int i = 0;
    //        while (i < 3) this.Add(new HocKy(++i));
    //    }

    //    public void Insert(Lop lop)
    //    {
    //        foreach (var h in this)
    //            if (h.TryInsert(lop))
    //                return;
    //    }
    //}

    public class Lop : KLGD.Lop, IPriorityElement
    {
        public Level PhanCap = new Level();
        public Single QuyDoi;
        public object MaHP;
        public int MucUT;
        public int SoLop;

        public bool IsHigher(IPriorityElement e)
        {
            return MucUT < ((Lop)e).MucUT;
        }

        public override void Calculate()
        {
            base.Calculate();
            MaHP = base.GetAttribute("MaHP");
            MucUT = (int)base.GetAttribute("CTDT.UuTienPC");

            var qd = base.GetAttribute("QuyDoi");
            if (qd.Equals(string.Empty))
                qd = (Single)0;

            QuyDoi = (Single)qd;

            if (MaHP.Equals("ET2020"))
            {
            }
            var a = (int)base.GetAttribute("LoaiLop.PhanCapGD");
            var b = (int)base.GetAttribute("CTDT.PhanCapGD");

            a = Math.Max(a, b);
            PhanCap.Min = PhanCap.Max = a;

            var sl = base.GetAttribute("SoLop");
            if (sl.Equals(string.Empty))
                sl = 1;
            SoLop = (int)sl;
        }

        public object[] GetGiaoKet()
        {
            return new object[] { null, null, HocKy, MaHP, MaCT, LoaiLop, SoLop, QuyDoi };
        }
    }
    public class LopCollection : DataCollection<Lop>
    {
        public LopCollection(string name)
            : base(name)
        {
            this.Select();
        }

        //HocKyCollection _hocKy;
        //public HocKyCollection HocKy
        //{
        //    get
        //    {
        //        if (_hocKy == null)
        //        {
        //            _hocKy = new HocKyCollection();
        //            foreach (var lop in this.Select())
        //                _hocKy.Insert(lop);
        //        }
        //        return _hocKy;
        //    }
        //}

        public override List<Lop> Select(string filter, string sort)
        {
            base.Select(filter, sort);
            foreach (var lop in this)
                lop.Calculate();

            return this;
        }

        public void CalculateKLGD()
        {
            var klgd = new KLGD.DataCollection();

            var caclop = new KLGD.LopCollection(this.Name);
            foreach (var lop in caclop.Select())
            {
                var chinh = klgd.InsertLop(lop.LopChinh);
                if (chinh != null)
                {
                    var qd = (Single)chinh.GetAttribute("QuyDoi");
                    var phu = klgd.InsertLop(lop.LopBT);

                    if (phu != null)
                        qd += (Single)phu.GetAttribute("QuyDoi");

                    lop.SetAttribute("QuyDoi", qd);
                }
            }

            klgd.Table.Clear();
            caclop.UpdateDataBase();
        }
    }

    public class Level
    {
        public int Min;
        public int Max;

        public Level(int a, int b) { Min = a; Max = b; }
        public Level(int a) : this(a, a) { }
        public Level() : this(0, 100) { }

        public bool Contains(int value) { return Min <= value && Max >= value; }
        public bool Contains(Level level) { return Min <= level.Min && Max >= level.Max; }

        public override string ToString()
        {
            return string.Format("Min = {0}, Max = {1}", Min, Max);
        }
    }
    public partial class GiangVien : DataEntity, IPriorityElement
    {
        public Level PhanCap = new Level();
        public Single SoGio;

        Single GioKhoiTao;

        //HocKyCollection _hocKy;
        //public HocKyCollection HocKy
        //{
        //    get
        //    {
        //        if (_hocKy == null)
        //            _hocKy = new HocKyCollection();
        //        return _hocKy;
        //    }
        //}

        Dictionary<Lop, int> _cacLop;
        public Dictionary<Lop, int> CacLop
        {
            get
            {
                if (_cacLop == null)
                    _cacLop = new Dictionary<Lop, int>();
                return _cacLop;
            }
        }

        public void AddLop(Lop e)
        {
            SoGio += e.QuyDoi;
            int v = 0;
            if (this.CacLop.TryGetValue(e, out v) == false)
                _cacLop.Add(e, 1);
            else
                _cacLop[e] = ++v;
        }

        public bool IsHigher(IPriorityElement e)
        {
            var g = (GiangVien)e;
            return g.TongGio > TongGio;
        }

        public void ChuanBiGiaoKet()
        {
            PhanCap.Min = GetInt("Min");
            PhanCap.Max = GetInt("Max");

            var pv = this.GetSingleValue("CanBo.GioQL");
            this.SetAttribute("GioPV", pv);

            GioKhoiTao = pv + this.GetSingleValue("PhanCapCBGD.TichLuy") + this.GetSingleValue("LATS");
        }

        public object HoTen { get { return this.GetAttribute("CanBo.HoTen"); } }
        public Single TongGio { get { return GioKhoiTao + SoGio; } }

        public override string ToString()
        {
            return string.Format("{0}: {1}", HoTen, TongGio);
        }
    }
    public partial class GiangVienCollection : DataCollection<GiangVien>
    {
        Dictionary<object, GiangVien> _map;
        public Dictionary<object, GiangVien> Map
        {
            get { return _map; }
        }

        public GiangVienCollection()
            : base("PhanCapCBGD")
        {
            _map = this.CreateDataMap("CanBoId");
        }

        public void ChuanBiGiaoKet()
        {
            var colGioQL = new DefaultCollection("ChucVuCB").CreateAttribute("GioQL", typeof(Single), "parent(HSCV).SoGio");
            var colChucVu = new DefaultCollection("CanBo").CreateAttribute("GioQL", typeof(Single), "max(child(ChucVuCB).GioQL)");

            new DefaultCollection("LATS");

            this.CreateAttribute("GioPV", typeof(Single), null);
            this.CreateAttribute("LATS", typeof(Single), "sum(child(LATS).QuyDoi)");
            foreach (var g in _map.Values)
            {
                g.ChuanBiGiaoKet();
            }

            colChucVu.Table.Columns.Remove(colChucVu);
            colGioQL.Table.Columns.Remove(colGioQL);
        }

        new public GiangVien Find(object id)
        {
            GiangVien g = null;
            _map.TryGetValue(id, out g);
            return g;
        }

        //public void UpdateHocPhan()
        //{
        //    var cbgd = new DefaultCollection("CBGD").CreateDataMap("GiangVienId+MaHP");
        //    foreach (var e in cbgd.Values)
        //        e.SetAttribute("SoLop", null);

        //    foreach (var gv in _map.Values)
        //    {
        //        var hp = new StringList(", ");
        //        var soLop = 0;
        //        foreach (var p in gv.HocPhan)
        //        {
        //            var key = string.Format("{0}{1}", gv.ID, p.Key);
        //            cbgd[key].SetAttribute("SoLop", p.Value);

        //            hp.Add(p.Key.ToString());
        //            soLop += p.Value;
        //        }

        //        gv.SetAttribute("HP", hp);
        //        gv.SetAttribute("SoLop", soLop);
        //        gv.SetAttribute("SoGio", gv.SoGio);
        //    }
        //    base.UpdateDataBase();
        //}
    }
    public class GiangVienQueue : PriorityQueue<GiangVien>
    {
    }

    public class HocPhan : IPriorityElement
    {
        public Level PhanCap = new Level();
        public PriorityQueue<Lop> CacLop = new PriorityQueue<Lop>();
        public GiangVienQueue GiangVien = new GiangVienQueue();

        public bool IsHigher(IPriorityElement e)
        {
            return ((HocPhan)e).GiangVien.Count > GiangVien.Count;
        }

        public bool Calculate()
        {
            if (CacLop.Count == 0)
                return false;

            var lop = CacLop.Peek();
            GiangVien.Top.AddLop(lop);

            if (--lop.SoLop == 0)
                CacLop.Dequeue();

            if (CacLop.Count > 0)
            {
                GiangVien.Rebuild();
                return true;
            }
            return false;
        }
    }
    public class HocPhanMap : Dictionary<object, HocPhan>
    {
        public HocPhanMap(GiangVienCollection giangVien, string lopDataName)
        {
            var cacLop = new LopCollection(lopDataName);
            cacLop.CalculateKLGD();

            foreach (var e in cacLop)
            {
                this[e.MaHP].CacLop.Enqueue(e);
            }
            foreach (var e in new DefaultCollection("CBGD").Select())
            {
                var key = e.GetString("MaHP");
                if (this.ContainsKey(key))
                {
                    var cb = e.GetAttribute("GiangVienId");
                    var g = giangVien.Find(cb);
                    if (g != null)
                    {
                        this[key].GiangVien.Enqueue(g);
                    }
                }
            }
        }

        public HocPhanMap(HocPhanMap src, Level level)
        {
            foreach (var p in src)
            {
                if (!p.Value.PhanCap.Contains(level))
                    continue;

                var hp = new HocPhan();
                foreach (var lop in p.Value.CacLop)
                    if (level.Contains(lop.PhanCap))
                        hp.CacLop.Enqueue(lop);

                if (hp.CacLop.Count > 0)
                {
                    foreach (var g in p.Value.GiangVien)
                    {
                        if (g.PhanCap.Contains(level))
                            hp.GiangVien.Enqueue(g);
                    }
                    if (hp.GiangVien.Count > 0)
                        this.Add(p.Key, hp);
                }
            }
        }

        public void Calculate()
        {
            var q = new PriorityQueue<HocPhan>();
            foreach (var hp in this.Values)
                q.Enqueue(hp);
            var lst = new LinkedList<HocPhan>();
            foreach (var hp in q.Sort())
                lst.AddFirst(hp);

            while (lst.Count > 0)
            {
                var node = lst.First;
                if (node.Value.Calculate() == false)
                    lst.RemoveFirst();
            }

            foreach (var p in this)
            {
                if (p.Key.Equals("ET2060"))
                {
                }

                var gv = p.Value.GiangVien.ToArray();
                while (true)
                {
                    GiangVien min = null, max = null;
                    
                    Lop lop = null;
                    foreach (var g in p.Value.GiangVien)
                    {
                        if (min == null || min.TongGio > g.TongGio)
                            min = g;

                        if (max == null || max.TongGio > g.TongGio)
                        {
                            Lop found = null;
                            foreach (var pl in g.CacLop)
                            {
                                if (pl.Key.MaHP.Equals(p.Key))
                                {
                                    lop = found = pl.Key;
                                    break;
                                }
                            }
                            if (found != null) max = g;
                        }
                    }

                    if (min == null || min.TongGio == max.TongGio) break;
                    if (min.TongGio + lop.QuyDoi >= max.TongGio - lop.QuyDoi)
                        break;

                    if (--max.CacLop[lop] == 0)
                    {
                        max.CacLop.Remove(lop);
                        max.SoGio -= lop.QuyDoi;
                    }
                    min.AddLop(lop);
                }
            }
        }

        new public HocPhan this[object key]
        {
            get
            {
                HocPhan e = null;
                if (this.TryGetValue(key, out e) == false)
                    this.Add(key, e = new HocPhan());
                return e;
            }
        }
    }

    public class PhanCap : List<Level>
    {
        public PhanCap()
        {
            var model = new DefaultCollection("PhanCapGD");
            foreach (var e in model.Select(null, "Level desc"))
            {
                var level = new Level((int)e.ID);
                this.Add(level);
            }
        }
    }

    public class Entity : DataEntity
    {
    }
    public class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection() : base("GiangVienGiaoKet") { }

        public virtual void Calculate(string lopDataName)
        {
            var gv = new GiangVienCollection();
            gv.ChuanBiGiaoKet();

            var map = new HocPhanMap(gv, lopDataName);
            foreach (var level in new PhanCap())
                new HocPhanMap(map, level).Calculate();

            this.Table.Clear();
            foreach (var g in gv.Map.Values)
            {
                //var lst = new Dictionary<object, Lop>();
                //foreach (var h in g.HocKy)
                //{
                //    foreach (var lop in h)
                //    {
                //        if (lst.ContainsKey(lop.MaLop) == false)
                //        {
                //            lop.SoLop = 1;
                //            lst.Add(lop.MaLop, lop);
                //        }
                //        else
                //        {
                //            lst[lop.MaLop].SoLop++;
                //        }
                //    }
                //}
                foreach (var p in g.CacLop)
                {
                    var lop = p.Key;
                    lop.SoLop = p.Value;
                    this.Insert(lop.GetGiaoKet()).SetAttribute("GiangVienId", g.ID);
                }
            }
        }
    }

    public class TongHopBoMon : DataEntity
    {
        Single _tong;
        int _soLuong;

        Single _tb = 0;
        public Single TrungBinh
        {
            get
            {
                if (_tb == 0) _tb = _tong / _soLuong;
                return _tb;
            }
        }

        public void Add(TongHopEntity e)
        {
            _tong += e.SoGio;
            _soLuong++;
        }
    }

    public class TongHopEntity : GiangVien
    {
        public object MaBM { get; set; }
        public TongHopEntity(GiangVien g, int hk)
        {
            this.MaBM = g.GetAttribute("CanBo.MaBM");
            this.Row = g.Row;

            foreach (var lop in g.CacLop.Keys)
            {
                if (hk == 0 || ((int)lop.HocKy & 3) == hk)
                {
                    _hp.AddKey(lop.MaHP);
                    _soLop += lop.SoLop;
                    SoGio += lop.QuyDoi * lop.SoLop;
                }
            }
        }

        StringList _hp = new StringList(", ");
        int _soLop;

        public string ChartInfo { get; set; }
        public override object GetAttribute(string name)
        {
            switch (name)
            {
                case "SoLop": return _soLop;
                case "SoGio": return this.SoGio;
                case "HocPhan": return _hp.ToString();
                case "Chart": return ChartInfo;
            }
            return base.GetAttribute(name);
        }
    }

    public class TongHopCollection : GiangVienCollection
    {
        public static int HocKy
        {
            get
            {
                var v = Engine.Session["view-giao-ket-hoc-ky"];
                if (v == null)
                    return 0;
                return (int)v;
            }
            set { Engine.Session["view-giao-ket-hoc-ky"] = value; }
        }

        public static string BoMon
        {
            get { return (string)Engine.Session["view-giao-ket-bo-mon"]; }
            set { Engine.Session["view-giao-ket-bo-mon"] = value; }
        }

        public override void UpdateView(AppView view)
        {
            var map = this.Map;
            var lop = new LopCollection("GiangVienGiaoKet");

            foreach (var e in lop)
            {
                var gv = map[e.GetAttribute("GiangVienId")];
                gv.AddLop(e);
            }

            var mapBM = new App.DataCollection<TongHopBoMon>("BoMon").CreateDataMap("Ma");
            var vien = mapBM[NameManager.DTVT];
            var hk = TongHopCollection.HocKy;

            this.Clear();

            var locBM = TongHopCollection.BoMon;
            foreach (var g in map.Values)
            {
                var e = new TongHopEntity(g, hk);

                if (locBM == null || locBM.Equals(e.MaBM))
                {
                    this.Add(e);
                    mapBM[e.MaBM].Add(e);
                }

                vien.Add(e);
            }

            foreach (TongHopEntity e in this)
            {
                e.ChartInfo = string.Format("[{0},{1},{2}]", e.SoGio, mapBM[e.MaBM].TrungBinh, vien.TrungBinh);
            }

            var data = (Json.Collection)view.JsonTemplate;
            var bm = data.CreateArray("bm");

            if (locBM == null)
                locBM = NameManager.DTVT;

            foreach (var p in mapBM)
            {
                if (p.Value.TrungBinh == 0)
                    continue;

                var item = bm.CreateArray();
                var ten = p.Value.GetString("Ten");
                item.Add(ten);
                item.Add("?BM=" + p.Key);

                if (p.Key.Equals(locBM))
                    data.Add("locBM", ten);
            }

            if (HocKy != 0)
                data.Add("locHK", hk);

            view.DataSource = this;
            view.DataBind();
        }
    }
}