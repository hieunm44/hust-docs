﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    //public class DefaultDataModel : VST.Base.DataCollection<DataEntity>
    //{
    //    public DefaultDataModel()
    //    {
    //        this.Load(Engine.DataProvider.Read(this.GetType().Name));
    //    }
    //    public DefaultDataModel(string name)
    //        : this(name, null, null)
    //    {
    //    }
    //    public DefaultDataModel(string name, string filter, string sort)
    //        : base(name)
    //    {
    //        this.Table.DefaultView.Sort = sort;
    //        this.Table.DefaultView.RowFilter = filter;
    //    }

    //    public object GetValue(object key, string field)
    //    {
    //        var r = this.Table.Rows.Find(key);
    //        if (r == null)
    //            return DBNull.Value;
    //        return r[field];
    //    }

    //    new public DataEntity Find(object key)
    //    {
    //        var r = this.Table.Rows.Find(key);
    //        if (r == null) return null;
    //        return new DataEntity { Row = r }; 
    //    }

    //    public void Remove(object key)
    //    {
    //        var r = this.Table.Rows.Find(key);
    //        if (r != null)
    //            r.Delete();
    //    }
    //    public DataEntity Insert(params object[] values)
    //    {
    //        var r = this.Table.Rows.Add(values);
    //        return new DataEntity { Row = r };
    //    }
    //}
}