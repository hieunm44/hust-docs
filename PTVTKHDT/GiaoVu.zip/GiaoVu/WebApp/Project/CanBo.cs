﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public class CanBo
    {
        public static string GetUserName(string value)
        {
            var v = VST.Viet.Text.GetLatinhCharacterOnly(value).ToCharArray();
            int i = 0;

            foreach (var c in v)
            {
                if (char.IsLetter(c))
                    v[i++] = c;
            }
            return new string(v, 0, i);
        }
    }
}