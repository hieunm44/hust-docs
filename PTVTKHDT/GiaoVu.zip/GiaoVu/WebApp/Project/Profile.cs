﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public class ProfileView : App.View.FormView
    {
        public ProfileView()
        {
        }
    }

    public class MatKhauForm : ProfileView
    {
        public MatKhauForm() { }
        public override void DataBind()
        {
            base.DataBind();
        }
    }
}