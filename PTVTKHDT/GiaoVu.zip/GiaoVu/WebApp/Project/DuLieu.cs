﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace App.DuLieu
{
    public class Entity : DataEntity
    {
        public override object GetAttribute(string name)
        {
            return base.GetAttribute(name);
        }
    }

    public enum ImportState { OK, Stop, DoNotWrite };

    public class ImportEngine : Dictionary<string, int>
    {
        public ImportEngine() { }
        public void AddRange(string[] names)
        {
            foreach (var name in names)
                this.Add(name, this.Count);
        }

        protected string[] _values;
        public string GetValue(string name)
        {
            return _values[this[name]];
        }

        protected Entity _entity;

        public ImportState State { get; protected set; }

        protected void CheckParent(DefaultCollection model, string name)
        {
            var id = _values[this[name]];
            if (model.Find(id) == null)
                _entity.Parents.Add(model.Name, model.InsertEntity(id).Row);
        }

        protected virtual void CheckAllParent() { }
        public virtual void WriteTo(Entity e, string[] values)
        {
            this.State = ImportState.OK;
            _values = values;
            _entity = e;

            this.CheckAllParent();
            if (this.State != ImportState.OK)
                return;

            var r = e.Row;
            foreach (var p in this)
            {
                this.WriteCore(p.Key, values[p.Value].Trim());
                if (this.State != ImportState.OK)
                    return;
            }

            if (e.IsNew) r.Table.Rows.Add(r);
        }

        protected virtual void WriteCore(string name, string value)
        {
            _entity.SetAttribute(name, value);
        }
    }

    public class Collection : DataCollection<Entity>
    {
        public Collection(string name)
            : base(name)
        {
        }


        public void Import(string data, ImportEngine engine)
        {
            var lines = data.Split('\n');
            var srcNames = lines[1].Split('\t');

            var gui = VST.Schema.Template.Guis[Engine.FunctionalContext.GetString("import")];
            var pk = new StringList("+");
            var keyIndex = new List<int>();

            engine.AddRange(lines[0].Split('\t'));
            foreach (var p in engine)
            {
                var field = gui[p.Key];
                if (field.IsPrimaryKey)
                {
                    pk.Add(p.Key);
                    keyIndex.Add(p.Value);
                }
            }


            if (keyIndex.Count == 0)
            {
                for (int i = 2; i < lines.Length; i++)
                {
                    var e = (Entity)this.NewEntity();
                    engine.WriteTo(e, lines[i].Split('\t'));
                }
                this.UpdateDataBase();
                return;
            }


            var col = this.Table.Columns.Add("importKey");
            col.Expression = pk.ToString();

            try
            {
                var map = new Dictionary<string, Entity>();
                foreach (Entity e in this.Select())
                    map.Add((string)e.Row[col], e);

                var newMap = new Dictionary<string, Entity>();

                for (int i = 2; i < lines.Length; i++)
                {
                    var line = lines[i].Split('\t');
                    var key = "";

                    foreach (var k in keyIndex)
                        key += line[k];

                    Entity e = null;
                    if (newMap.ContainsKey(key))
                        continue;

                    if (map.TryGetValue(key, out e) == false)
                        e = (Entity)this.NewEntity();

                    newMap.Add(key, e);
                    engine.WriteTo(e, line);
                }
            }
            catch
            {
            }
            finally
            {
                this.Table.Columns.Remove(col);
            }
            this.UpdateDataBase();
        }

        protected override void SetContextParam(VST.Schema.FHD.Entity context)
        {
            string import = (string)context.GetAttribute("import");
            if (import == "/") import = string.Empty;
            if (import == string.Empty)
                context.SetAttribute("import", context.GuiName);
            base.SetContextParam(context);
        }
    }
    public class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            if (name == null)
            {
                var context = Engine.FunctionalContext;
                name = context.ModelName;

                if (name == string.Empty)
                    context.SetAttribute("model", name = context.Name.Replace("-", ""));
            }
            return new Collection(name);
        }

        protected virtual void BeginImport(string data, ImportEngine engine)
        {
            if (engine == null)
                engine = new ImportEngine();
            ((Collection)this.Collection).Import(data, engine);
        }
        protected override PostBackCommand LoadFormData()
        {
            var cmd = base.LoadFormData();
            if (!cmd.ContainsKey("import"))
                return cmd;

            this.BeginImport(Project.Convert.Descape(cmd.GetString("import")), null);
            return null;
        }

        public override void ProcessDelete(PostBackCommand command)
        {
            if (string.IsNullOrEmpty(command.CommandValue))
            {
                ((Collection)this.Collection).Delete(null);
                Engine.Finish(null);
            }
            base.ProcessDelete(command);
        }
    }

    public class CollectionView : App.View.DataView
    {
        protected override TextTemplate GetActions(params string[] keys)
        {
            return base.GetActions("add", "del", "clear");
        }
    }

    public class Page : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        protected override AppView CreateViewCore()
        {
            var model = this.Controller.Model;
            VST.Schema.Template.Guis.CreateGui(model.Name.ToLower());
            if (model is IDataCollection)
                return new CollectionView();
            return new App.View.FormView();
        }
    }
}