﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public partial class NameManager
    {
        public const string MainContent = "main-content";
        public const string ThietBi = "thiet-bi";
        public const string KhachHang = "khach-hang";
        public const string User = "user";
        public const string FAIL = "FAIL";
        public const string OK = "OK";

        public const string DTVT = "KDTVT";
    }

}