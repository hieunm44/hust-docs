﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public partial class Controller
    {
        public string Encode(string value)
        {
            var v = value.ToCharArray();
            int a = (((new Random().Next(4)) + 4) << 4);
            for (int i = 0; i < v.Length; i++)
            {
                char c = v[i];

                if (c == '0')
                {
                    v[i] = 'O';
                    continue;
                }
                byte nib = (byte)(c & 15);

                if (nib >= 4 && 7 >= nib)
                {
                    v[i] = (char)((nib << 4) | nib);
                }
                else
                {
                    v[i] = (char)(a + nib);
                }
            }
            return (char)(a) + (new string(v));
        }
        public string Decode(string value)
        {
            var v = value.ToCharArray();
            var f = v[0];
            for (int i = 1; i < v.Length; i++)
            {
                char c = v[i];
                if (c == 'O')
                {
                    v[i] = '0';
                    continue;
                }
                int a = c >> 4;
                int b = c & 15;

                if (a != b)
                    b = c - f;
                v[i] = (char)(b | 0x30);
            }
            return new string(v, 1, v.Length - 1);
        }

        public object GetDate(object value)
        {
            return VST.Viet.Date.Convert((string)value);
        }
        public object GetBoolean(object value)
        {
            return System.Convert.ChangeType(value, typeof(bool));
        }
    }
}