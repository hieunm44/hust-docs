﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Xml;

namespace App.Project
{
    class ConstraintChecker : System.Xml.XmlDocument
    {
        string fileName;
        public ConstraintChecker(string name)
        {
            var table = Global.DataProvider.Tables[name] as VST.Data.XmlTable;
            this.Load(fileName = table.Url);
        }

        public void CheckParent(string name, string nodeName)
        {
            var model = new DefaultCollection(name);
            var invalid = new List<System.Xml.XmlNode>();
            foreach (System.Xml.XmlNode node in this.DocumentElement)
            {
                System.Xml.XmlNode key = node.FirstChild;
                if (nodeName != null)
                    key = node[nodeName];

                if (key == null || key.InnerText == string.Empty)
                    continue;

                if (model.Find(key.InnerText) == null)
                {
                    invalid.Add(node);
                }
            }

            if (invalid.Count > 0)
            {
                foreach (var node in invalid)
                    this.DocumentElement.RemoveChild(node);
                this.Save(fileName);
            }
        }

        public void CheckPrimaryKey()
        {
            var map = new Dictionary<string, System.Xml.XmlElement>();
            var lst = new List<System.Xml.XmlNode>();
            foreach (System.Xml.XmlElement node in this.DocumentElement)
            {
                var key = node.FirstChild.InnerText;
                if (map.ContainsKey(key) == false)
                {
                    map.Add(key, node);
                }
                else
                {
                    lst.Add(node);
                }
            }

            if (lst.Count > 0)
            {
                foreach (var node in lst)
                    this.DocumentElement.RemoveChild(node);

                this.Save(fileName);
            }
        }

        public void CheckParent(string name) { this.CheckParent(name, null); }
    }

    //class NCKH
    //{
    //    static string GetFileName(string name)
    //    {
    //        return VST.Data.Provider.GetDataSourceName("NCKH_" + name);
    //    }

    //    static void CheckHoSo(params string[] names)
    //    {
    //        foreach (var name in names)
    //            new ConstraintChecker("NCKH_" + name).CheckParent("NCKH_HoSo");
    //    }
    //    static void CheckDeTai(params string[] names)
    //    {
    //        foreach (var name in names)
    //            new ConstraintChecker("NCKH_" + name).CheckParent("NCKH_DeTai", "DeTaiId");
    //    }

    //    static void CheckTacGia()
    //    {

    //    }

    //    public static void Run()
    //    {
    //        CheckHoSo("ChoDuyet", "Duyet", "DeTai", "TapChi", "HoiNghi", "PMSC", "TacGia", "XuLy");
    //        CheckDeTai("TapChi", "HoiNghi");

    //        new ConstraintChecker("NCKH_TacGia").CheckParent("CanBo", "CanBoId");

    //        foreach (var e in new DefaultCollection("NCKH_HoSo").Select())
    //        {
    //            var s = e.GetString("TacGia").Split(',');
    //            e.SetAttribute("SoTG", s.Length);

    //            var ten = e.GetString("Ten").ToCharArray();
    //            int i = 0;
    //            foreach (var c in ten)
    //                if (c != '\r' && c != '\n')
    //                    ten[i++] = c;
    //            e.SetAttribute("Ten", new string(ten, 0, i));
    //        }
    //        Global.DataProvider.UpdateDataBase();
    //    }

    //    public static void Luu()
    //    {
    //        string[] names = new string[] { "TapChi", "HoiNghi", "DeTai", "PMSC" };
    //        var duyet = new DefaultCollection("NCKH_Duyet");
    //        var luu = new DefaultCollection("NCKH_Luu");
    //        var moc = new DateTime(DateTime.Today.Year - 1, 7, 1);

    //        luu.Table.Clear();
    //        foreach (string name in names)
    //        {
    //            var model = new DefaultCollection("NCKH_" + name);
    //            foreach (var e in model.Select())
    //            {
    //                var d = (DateTime)e.GetAttribute("NgayKT");
    //                if (d < moc)
    //                {
    //                    luu.Insert(e.ID, d.Year);
    //                    var a = (DataEntity)duyet.Find(e.ID);
    //                    if (a != null)
    //                        a.Delete();
    //                }

    //            }
    //        }
    //        Global.DataProvider.UpdateDataBase();
    //    }
    //}

    class HanhChinh
    {
        public static void CreateChucVu()
        {
            var chucVu = new DefaultCollection("ChucVu");
            var hscv = new DefaultCollection("HSCV");

            foreach (var e in hscv.Select())
            {
                var values = e.GetString("GiaiNghia").Split(',');
                foreach (string v in values)
                    chucVu.Insert(null, v, e.ID);
            }
            chucVu.UpdateDataBase();
        }
    }

    class HocPhan
    {
        public static void QuyChuanSoTC()
        {
            var hocphan = new DefaultCollection("HocPhan");
            foreach (var e in hocphan.Select())
            {
                var ctkl = e.GetString("CTKL");
                int i = ctkl.IndexOf('-');
                if (i < 1) continue;

                int lt = 0;
                if (int.TryParse(ctkl.Substring(0, i), out lt) == false)
                    continue;

                if (lt >= 30)
                {
                    lt /= 15;
                    e.SetAttribute("CTKL", lt.ToString() + ctkl.Substring(i));
                }
            }
            hocphan.UpdateDataBase();
        }
    }

    class User
    {
        public static void CreateCanBo()
        {
            var canBo = new DefaultCollection("CanBo");
            var map = new Dictionary<string, int>();
            var account = new DefaultCollection("Account");
            foreach (var e in account.Select())
                map.Add((string)e.ID, e.GetInt("UserId"));

            foreach (var e in canBo.Select())
            {
                var name = e.GetAttribute("User.FullName") as string;
                var un = VST.Viet.Text.GetLatinhCharacterOnly(name).ToCharArray();
                int i = 0;
                foreach (var c in un)
                {
                    if (c == ' ') continue;
                    un[i++] = c;
                }
                name = new string(un, 0, i);

                if (map.ContainsKey(name) == false)
                {
                    map.Add(name, (int)e.ID);
                    account.Insert(name, VST.Security.Generate(name + name), 50, e.ID);
                    continue;
                }

                if (e.ID.Equals(map[name]))
                    continue;

                i = 0;
                while (true)
                {
                    var key = string.Format("{0}{1}", name, ++i);
                    name = key;
                    if (map.ContainsKey(key) == false)
                    {
                        map.Add(name, (int)e.ID);
                        account.Insert(name, VST.Security.Generate(name + name), 50, e.ID);
                        break;
                    }
                }
            }
        }
        public static void CreateSinhVien()
        {
            var model = new DefaultCollection("SinhVien");
            var account = new DefaultCollection("Account");
            foreach (var e in model.Select())
            {
                string name = e.GetString("SHSV");
                var old = account.Find(name);
                if (old != null)
                {
                    old.SetAttribute("UserId", e.ID);
                    continue;
                }
                account.Insert(name, VST.Security.Generate(name + name), 10, e.ID);
            }
        }

        public static void CheckAccount()
        {
            var checker = new ConstraintChecker("Account");
            checker.CheckPrimaryKey();
        }

        public static void CheckAllUser()
        {
            var canBo = new DefaultCollection("CanBo");
            var sinhVien = new DefaultCollection("SinhVien");
            var acc = new DefaultCollection("Account");
            foreach (var e in acc.Select())
            {
                var lev = 10;
                var id = e.GetInt("UserId");
                if (canBo.Find(id) != null)
                    lev = Author.GiangVien;
                

                    e.SetAttribute("AuthorId", lev);
            }
            acc.UpdateDataBase();
            //var lstSV = new List<DataEntity>();
            //var lstCB = new List<DataEntity>();

            //foreach (var sv in sinhVien.Select())
            //{
            //    if (canBo.Find(sv.ID) != null)
            //        lstSV.Add(sv);
            //}
            //foreach (var cb in canBo.Select())
            //{
            //    if (sinhVien.Find(cb.ID) != null)
            //        lstCB.Add(cb);
            //}
        }

        public static void Spam()
        {
            var spam = new DefaultCollection("Spam");
            var account = Service.Account.AccountCollection;

            foreach (var a in account.Select())
            {
                if (a.GetInt("AuthorId") < 0)
                {
                    a.SetAttribute("AuthorId", Author.SinhVien);
                    var id = a.GetInt("UserId");
                    if (spam.Find(id) == null)
                        spam.Insert(id);
                }
            }
            spam.UpdateDataBase();
        }
    }

    public class Convert
    {

        public static void Run()
        {
            //User.CheckAllUser();
            //App.PhanCongGiangDay.Engine.InitPhanCapCBGD();
            //User.CreateSinhVien();

            //User.Spam();

            //var xong = new cap_giay.kiem_tra.DataCollection("Xong");
            //var qua = new cap_giay.kiem_tra.DataCollection("Qua");
            //foreach (var e in qua.Select())
            //    xong.AddEntity(e);
            //xong.UpdateDataBase();

            //NCKH.Run();
        }

        static int Decode(char[] s, int i, int n)
        {
            var v = 0;
            for (int k = 0; k < n; k++)
            {
                int a = s[k + i] - 48; if (a > 9) a -= 7;
                v = (v << 4) | a;
            }
            return v;
        }
        public static string Descape(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return null;

            var arr = input.ToCharArray();
            int j = 0;

            int code = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                char c = arr[i];
                if (c == '%')
                {
                    if (arr[++i] == 'u')
                    {
                        code = Decode(arr, i + 1, 4);
                        i += 4;
                    }
                    else
                    {
                        code = Decode(arr, i, 2);
                        i++;
                    }

                    c = (char)code;
                }

                arr[j++] = c;
            }

            return new string(arr, 0, j);
        }

        public static object GetHtmlCharacter(char c)
        {
            switch (c)
            {
                case '&': return "&amp;";
                case '<': return "&lt;";
                case '>': return "&gt;";
            }
            return c;
        }
        public static string HtmlEncode(string input)
        {
            string s = string.Empty;
            if (!string.IsNullOrWhiteSpace(input))
            {
                foreach (char c in input)
                    s += GetHtmlCharacter(c);
            }
            return s;
        }
    }
}