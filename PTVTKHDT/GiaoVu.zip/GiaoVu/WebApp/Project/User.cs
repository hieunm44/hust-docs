﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public class Author
    {
        public const int Spam = -1;
        public const int SupperAdmin = 99;
        public const int Admin = 90;
        public const int VanThu = 70;
        public const int GiangVien = 50;
        public const int SinhVien = 10;
    }
}

namespace App.User
{
    public partial class Entity
    {
        public int MinLevel { get { return Level; } }
        public int MaxLevel { get { return Level; } }
        public string AuthorText { get; set; }
        public string RequestUrl { get; set; }
    }

    public class Collecion : DefaultCollection
    {
        public Collecion(string name) : base(name) { }
        //public bool Check(Entity e)
        //{
        //    var api = new Service.Account(); //VSTAccount.AccountSoapClient();
        //    var res = new VST.Base.XmlEntity(api.Login(e.UserName, e.Password));

        //    if (res.GetString("error") != string.Empty)
        //    {
        //        e.State = res.GetString("type") == "Name" ? LoginState.UserNotFound : LoginState.PasswordInvalid;
        //        return false;
        //    }

        //    e.Level = int.Parse(res.GetString("authorid"));


        //    var us = Service.Account.UserCollection.Find(res.GetAttribute("id")) as DataEntity;
        //    if (us == null)
        //        return false;

        //    e.Row = us.Row;
        //    e.Token = res.GetString("token");
        //    e.Start();
        //    return true;
        //}
    }

    //public partial class Collection
    //{
    //    protected Entity CreateUserEntity(DataEntity e)
    //    {
    //        return new Entity { Row = e.Row };
    //    }

    //    public Entity TryCreateUser(PostBackCommand command, Entity user)
    //    {
    //        var userName = command.GetString("User.Name");
    //        var key = userName.ToLower();

    //        if (this.Exists(key))
    //        {
    //            command.Exception = true;
    //            return null;
    //        }

    //        var e = this.Data.Insert(null, userName);
    //        command.Remove("User.Name");
    //        command.Add("UserId", e.ID);

    //        user.Row = e.Row;
    //        this.Add(key, user);

    //        return user;
    //    }
    //}
}


