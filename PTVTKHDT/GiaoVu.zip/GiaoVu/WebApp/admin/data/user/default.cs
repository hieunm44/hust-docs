using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.admin.user
{
    public partial class Entity : DataEntity
    {
        public override void Delete()
        {
            var id = this.GetAttribute("UserId");
            if (!id.Equals(string.Empty))
            {
                var user = (DataEntity)Service.Account.UserCollection.Find(id);
                user.Delete();
            }
            else
            {
                base.Delete();
            }
        }

        public override void Execute(PostBackCommand command)
        {
            if (!this.IsNew && command.GetString("pass") == "reset")
            {
                this.SetAttribute("Pass", VST.Security.Generate("{0}{0}", this.ID));
                return;
            }
            base.Execute(command);
        }
    }
    public partial class DataCollection : DataCollection<Entity>
    {
        public DataCollection() { }
    }
    public partial class Controller : App.Controller
    {
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}