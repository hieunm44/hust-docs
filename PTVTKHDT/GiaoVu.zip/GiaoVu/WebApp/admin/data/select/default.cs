using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.admin.data.select
{
    public partial class Entity : App.DataEntity
    {
        public override object GetAttribute(string name)
        {
            var v = base.GetAttribute(name);
            if (v is DateTime)
                return v.ToString();

            return v;
        }
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection(string name) : base(name) { }
        public override void UpdateView(AppView view)
        {
            view.DataSource = this;
            view.DataBind();
        }
    }
    public partial class Controller : App.Controller
    {
        public static DataCollection Data
        {
            set { Engine.Session["data-select"] = value; }
            get { return (DataCollection)Engine.Session["data-select"]; }
        }
        public override void ProcessRequest(PostBackCommand command)
        {
            var e = new Entity();
            this.Model = e;
            
            if (command.ActionIndex == ActionIndex.Update)
            {
                var model = new DataCollection(command.GetString("From"));
                model.Select(command.GetString("Where"), command.GetString("OrderBy"));
                Controller.Data = model;

                this.Model = model;
            }
        }

        public override void ProcessView(string name, AppView container)
        {
            if (this.Model is Entity == false)
            {
                var view = (DataCollectionView)container;
                view.SetColumns(this.Command.GetString("Select"));
            }
            base.ProcessView(name, container);
        }
    }

    class SelectFormView : App.View.FormView
    {
        public override void LoadTempalte(string name)
        {
            base.LoadTempalte("DataSelect");
        }
    }

    class DataCollectionView : App.View.DataView
    {
        public override void LoadTempalte(string name)
        {
            var model = Controller.Data;
            name = model.Name;
            base.LoadTempalte(name);
        }

        List<string> _columns;
        public void SetColumns(string values)
        {
            var v = values.Split(',');
            _columns = new List<string>();

            foreach (var s in v)
                _columns.Add(s.Trim());
        }

        public override void DataBind()
        {
            var info = (App.Json.Table)this.JsonTemplate;
            info.Add("type", this.GetClassName());

            var cols = info.Columns;
            foreach (var name in _columns)
            {
                var col = cols.CreateCollection();
                col.Name = name;
                col.Caption = name;
            }

            var data = info.Data;
            foreach (IEntity e in (IEnumerable)this.DataSource)
            {
                var r = data.CreateArray();
                foreach (var name in _columns)
                    r.Add(e.GetAttribute(name));
            }

            var actions = info.HeaderActions;
            foreach (var e in this.GetActions("copy", "del", "clear"))
                actions.Add(e.Key, e.ToLink());
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        protected override AppView CreateViewCore()
        {
            if (this.Controller.Command.ActionIndex == ActionIndex.None)
                return new SelectFormView();

            return new DataCollectionView();
        }
    }
}