﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.admin.temp.reload
{
    public class Controller : App.Controller
    {
        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Update)
            {
                if (command.Request.Files.Count > 0) {
                    var file = command.Request.Files[0];

                    var fc = new FileController();
                    fc.UploadFile(file, "/app_data", command.CommandValue);
                }

                VST.Schema.Template.Reload(command.CommandValue);

                if (command.CommandValue[0] == 'm')
                {
                    Global.ResetData();
                }

                Engine.Finish(null);
            }
            //base.ProcessRequest(command);
        }
    }

    public partial class _default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        protected override AppView CreateView(string name)
        {
            return null;
        }
    }
}