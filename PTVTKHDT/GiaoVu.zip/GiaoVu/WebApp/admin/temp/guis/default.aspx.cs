﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.admin.temp.guis
{
    public class Template : BaseTemplate
    {

    }

    public class Controller : BaseController
    {
        protected override IModel LoadCollection(string name)
        {
            return new Template();
        }
    }
    public partial class _default : BasePage
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}