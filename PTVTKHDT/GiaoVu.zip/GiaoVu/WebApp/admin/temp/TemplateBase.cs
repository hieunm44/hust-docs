﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.admin.temp
{
    public class BaseTemplate : DefaultCollection
    {
        public override void UpdateView(AppView view)
        {
            var xml = new System.Xml.XmlDocument();
            xml.Load(FileController.DataPath + "/" + Engine.FunctionalContext.Name + ".xml");
            ((TreeView)view).Root = xml.DocumentElement;

            base.UpdateView(view);
        }
    }

    public class TreeView : App.View.FormView
    {
        public System.Xml.XmlElement Root { get; set; }
        public TreeView(string name)
        {
            base.LoadTempalte(name);
        }

        public override void DataBind()
        {
            base.DataBind();

            var arr = new Json.Array();
            arr.Add(this.DataBindCore(this.Root));
            this.JsonTemplate.Add("tree", arr);
        }

        protected Json.Collection DataBindCore(System.Xml.XmlElement node)
        {
            var data = new Json.Link();
            data.Caption = node.Name;
            foreach (System.Xml.XmlAttribute a in node.Attributes)
            {
                if (a.Name == "caption")
                {
                    data.Text = a.Value;
                    continue;
                }
                data.Add(a.Name.Replace('-', '_'), a.Value);
            }

            if (!node.IsEmpty)
            {
                var childs = data.CreateArray("childs");
                foreach (System.Xml.XmlElement child in node)
                    childs.Add(DataBindCore(child));
            }
            else
            {
                data.Url = "#";
            }
            return data;
        }
    }

    public class BaseController : App.Controller
    {

    }
    public partial class BasePage : App.Page
    {
        protected override AppView CreateView(string name)
        {
            return new TreeView("template" + Engine.FunctionalContext.Name.ToLower());
        }
    }
}