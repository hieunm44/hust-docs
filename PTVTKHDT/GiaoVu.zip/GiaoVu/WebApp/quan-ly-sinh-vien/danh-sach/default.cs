using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.quan_ly_sinh_vien.danh_sach
{

    class ImportEngine : DuLieu.ImportEngine
    {
        Dictionary<object, DataEntity> _map;
        protected override void CheckAllParent()
        {
            if (_map == null)
            {
                var model = new DefaultCollection("SinhVien");
                _map = model.CreateDataMap("SHSV");
            }
            var shsv = this.GetValue("SHSV");
            if (_map.ContainsKey(shsv))
            {
                this.State = DuLieu.ImportState.DoNotWrite;
                return;
            }

            var id = Service.Account.Core.Create(shsv, '#' + shsv, 
                this.GetValue("User.FullName"), null, null, Author.SinhVien, null);

            if (id == null)
                this.State = DuLieu.ImportState.DoNotWrite;
            else
                _entity.SetAttribute("UserId", id);
        }
    }

    public partial class Entity : App.DataEntity
    {
        public override void Delete()
        {
            var model = Service.Account.UserCollection;
            ((DataEntity)model.Find(this.ID)).Delete();
        }
        public override void Execute(PostBackCommand command)
        {
            if (this.IsNew)
            {
                var name = command.GetString("SHSV");
                var account = Service.Account.AccountCollection;

                if (account.Find(name) != null)
                {
                    return;
                }

                var api = new Service.Account();
                var doc = new System.Xml.XmlDocument
                {
                    InnerXml = api.CreateAccount(name, '#' + name,
                        command.GetString("User.FullName"), null, null, Author.SinhVien, null)
                };

                command.Remove("User.FullName");
                this.Row[0] = doc.DocumentElement.GetAttribute("id");
            }
            base.Execute(command);
        }
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
    }
    public partial class Controller : App.DuLieu.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }

        protected override void BeginImport(string data, DuLieu.ImportEngine engine)
        {
            var model = new DuLieu.Collection("SinhVien");
            model.Import(data, new ImportEngine());
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}