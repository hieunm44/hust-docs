using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.Content.css
{
    public partial class DataCollection : js.DataCollection
    {
        public static string Theme
        {
            get
            {
                return (string)Engine.Session["Theme"];
            }
            set
            {
                Engine.Session["Theme"] = value;
            }
        }

        public override List<js.Entity> Select(string filter, string sort)
        {
            string theme = Theme;
            if (theme == null)
                Engine.Finish("../themes");

            foreach (var fi in new Service.CssDirectory(theme).GetFiles())
            {
                this.Add(new js.Entity { FileName = fi.Name });
            }
            return this;
        }
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        protected override void ProcessPostData()
        {
            Service.Content.Upload(this.Command.Request.Files[0], DataCollection.Theme);
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Refresh)
            {
                Service.Content.Refresh();
                Engine.Finish(null);
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        protected override void CreateHeader(Json.Paragraph paragraph, string caption, string subCaption)
        {
            subCaption = DataCollection.Theme;
            base.CreateHeader(paragraph, caption, subCaption);
        }
    }
}