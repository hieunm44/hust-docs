﻿function TableCell(content) {
    HtmlElement.apply(this, ["div", "table-cell"]);

    if (content != null)
        this.node.innerHTML = content;
}

function TableColumn(name) {
    StyleSheetItem.apply(this, [name]);
    this.width = 0;

    var cells = [];
    this.append = function (cell) {
        cell.node.className += " " + name;
        cells[cells.length] = cell;
    }

    this.adjust = function () {
        var m = 0;
        for (var i in cells) {
            if (cells[i].node.offsetWidth > m)
                m = cells[i].node.offsetWidth;
        }

        this.width = m + 5;
        this.setAttribute("width", this.width + "px");

        return this.width;
    }

    this.setAction = function (name, rowFunc) {
        for (var i = 1; i < cells.length; i++) {
            cells[i].node.setAttribute(name, rowFunc + '(' + (i - 1) + ')');
        }
    }
}

function TableRow(table) {
    HtmlElement.apply(this, ["div", "table-row"]);

    this.content = this.append(new HtmlElement("div", "row-content"));


    this.newCell = function (content) {
        var cell = new TableCell(content);

        table.columns.items[this.content.node.childElementCount].append(cell);
        return this.content.append(cell);
    }
}

function Table(info) {
    Paragraph.apply(this, [info]);
    this.node.className += " table-view";

    var rows = [];

    var header = this.append(new TableRow(this));
    header.node.className += " table-header";

    this.columns = this.append(new function () {
        StyleSheet.apply(this);

        this.dataBind = function (cols) {
            for (var i in cols) {
                var name = cols[i].name;
                var caption = cols[i].caption;
                if (!name)
                    name = caption;

                this.items[i] = new TableColumn(name.replace('.', '-'));
                header.newCell(cols[i].caption)
            }
        }
    });

    this.body = this.append(new HtmlElement("div", "table-body"));

    this.createRowCore = function (index) {
        return new TableRow(this);
    }
    this.newRow = function () {
        var r = this.createRowCore(rows.length);
        rows[rows.length] = r;

        return this.body.append(r);
    }

    this.newColumn = function (name, caption) {

        if (caption == null || caption.length == 0) {
            caption = name;
        }

        this.columns.addItem(new TableColumn(name));
        var cell = this.header.newCell(caption);

        return cell;
    }

    this.bestFit = function () {
        var cols = this.columns.items;
        var w = 0;
        for (var i = 0; i < cols.length - 1; i++)
            w += cols[i].adjust();

        var last = cols[cols.length - 1];
        last.setAttribute("width", (this.node.offsetWidth - w) + "px");
        this.columns.refresh();
    }

    this.adjust = function () {
        var w = 100 / this.columns.items.length + "%";
        var cols = this.columns.items;
        for (var i in cols)
            cols[i].setAttribute("width", w);
        this.columns.refresh();
    }

    /* Tạo các cột */
    this.createColumns = function (cols) {
        for (var i in cols) {
            var name = cols[i].name;
            this.newColumn(name.replace('.', '-'), cols[i].caption);
        }
        this.adjust();
    }

    /* Tạo các hàng dữ liệu từ mảng data */
    this.createRows = function (data) {
        for (var i in data) {
            var r = this.newRow();
            for (var j in data[i]) {
                var cell = r.newCell(data[i][j]);
                this.onCellCreated(cell, i, j, data);
            }
        }

        this.rows = rows;
    }

    this.onCellCreated = function (cell, i, j, data) { }

    /* Chon trang */
    this.onPageRequest = function (index) {
        queryManager.content.page = index;
        queryManager.openURL();
    }
    this.selectPage = function (pageSplit) {
        if (pageSplit.rows >= rows.length)
            return;

        for (var i in rows)
            rows[i].hide();

        var k = (pageSplit.index - 1) * pageSplit.rows;
        for (var i = 0; i < pageSplit.rows; i++) {
            rows[k + i].show();
        }
    }

    this.createEntity = function (key, value) {
        switch (key) {
            case "data":
                this.createRows(value, info.keys);
                this.adjust();
                return null;

            case "pageSplit":
                return this.append(new PageSelector(value, this));
        }
        return null;
    }
}
function DataTable(info) {
    Table.apply(this, [info]);

    //this.indicator = this.append(new Indicator());
    var cks = [];

    function Indicator() {
        HtmlElement.apply(this, ["div", "row-indicator"]);
        var frame = this.appendNode("div", "frame");
        var check = frame.appendChild(new HtmlElement("div", "").node);
        this.appendNode("div", "self");

        this.showCheck = function (b) {
            if (b == null) b = true;
            if (b == false) frame.parentNode.removeChild(frame);
        }

        this.isChecked = function () { return check.className.length != 0; }
        this.setCheck = function (b) { check.className = b ? "check" : ""; this.onChanged(b); }

        var self = this;
        frame.addEventListener("click", function () { self.setCheck(!self.isChecked()); });

        this.onChanged = function (b) { }
    }

    function SelectMenu(table) {
        DropDownMenu.apply(this);

        this.node.className += " select-content";
        var baseNewItem = this.newItem;
        this.newItem = function (name, text) {
            var a = baseNewItem.call(this, text, '#');
            a.addEvent("click", function () {
                table.selectRows(true, name);
            });
        }

        this.keys = null;

        this.dataBind = function (data) {
            this.keys = data.keys;
            for (var key in data.items) {
                var v = data.items[key];
                this.newItem(key, v);
            }
        }
    }

    this.selectRows = function (b, selectName) {
        if (selectName == null || selectName == 'all') {
            checkAll.setCheck(b);
            return;
        }
        for (var i in cks) {
            if (info.selectMenu.keys[i] == selectName)
                cks[i].setCheck(b);
        }
    }

    this.createRowCore = function (index) {
        var r = new TableRow(this);
        var idc = r.prepend(new Indicator());

        cks[cks.length] = idc;
        return r;
    }

    this.getSelectedRows = function (keys) {
        var ids = [];
        for (var i in cks) {
            if (cks[i].isChecked())
                ids[ids.length] = i;
        }

        if (keys != null) {
            for (var i in ids) {
                var j = ids[i];
                ids[i] = keys[j];
            }
        }

        return ids;
    }

    var checkAll = this.header.actions.append(new Indicator());
    checkAll.onChanged = function (b) {
        for (var i in cks) {
            cks[i].setCheck(b);
        }
    };

    this.createAction = function (name, action, table) {
        var a = this.actions.append(new HtmlElement("a", "pa pa-" + name, action.caption));
        if (action.url)
            a.node.href = action.url;

        if (action.onclick)
            a.setAttribute("onclick", action.onclick);
        return a;
    }
    this.selectMenu = this.header.actions.append(new SelectMenu(this));

    this.onCellCreated = function (cell, i, j, data) {
        cell.addEvent("click", function () {
            openEntity(info.keys[i]);
        });
    }
}
function PageSelector(info, element) {
    Panel.apply(this, ["page-select"]);

    function PageButton(cls, txt) {
        HtmlElement.apply(this, ["span", cls, txt]);

        this.setValue = function (v, d) {
            if (v != d) {
                this.addEvent("click", function () {
                    info.index = v;
                    element.onPageRequest(v);
                });
            }
        }
    }

    this.dataBind = function (info) {
        this.node.innerHTML = null;
        var bs = {
            first: '&#xf100;',
            prev: '&#xf104',

            next: '&#xf105',
            last: '&#xf101'
        };
        for (var name in bs) {
            var b = new PageButton(name, bs[name]);
            bs[name] = this.append(b);
        }


        var count = info.total / info.rows;
        var iCount = Math.floor(count);

        if (count > iCount) count = iCount + 1;

        var cur = info.index;

        var firstIndex = (cur - 1) * info.rows;
        var lastIndex = info.rows + firstIndex;

        if (info.total > 0)
            firstIndex++;

        if (lastIndex > info.total)
            lastIndex = info.total;

        var label = this.prependElement("label", "record-index");
        label.node.innerText = firstIndex + " - " + lastIndex + " trong " + info.total;


        bs.first.setValue(1, cur);
        bs.next.setValue(cur + 1, count + 1);
        bs.prev.setValue(cur - 1, 0);
        bs.last.setValue(count, cur);

        var end = Math.min(cur + 2, count);
        var start = Math.max(end - 4, 1);
        end = Math.min(count, start + 4);
        for (var i = start; i <= end; i++) {
            var span = new PageButton(null, i);
            this.node.insertBefore(span.node, bs.next.node);

            span.setValue(i, cur);
            if (i == cur)
                span.node.setAttribute("data-role", "active");
        }

        element.selectPage(info);
    }
}


function openEntity(key) {
    queryManager.openURL("?open=" + encodeURIComponent(key));
}

function doClear() {
    if (confirm("Tất cả các bản ghi sẽ bị xóa. Tiếp tục thực hiện?"))
        queryManager.openURL("?delete=");
}

function doDelete() {
    var ids = layout.mainContent.first.getSelectedRows(page.mainContent[0].keys);
    if (ids.length == 0) {
        alert("Hãy chọn các bản ghi cần xóa.");
        return;
    }

    var msg = getDeleteConfirmMessage(ids);
    if (msg && confirm(msg) == false)
        return;

    queryManager.openURL("?delete={" + ids.join('|') + "}");
}

function getDeleteConfirmMessage(ids) {
    return "Xóa " + ids.length + " bản ghi?";
}

function copyToClipboard(info) {
    var div = new Panel();
    div.node.contentEditable = true;

    if (!info)
        info = page.mainContent[0];

    var table = div.appendElement("table");
    var tr = table.appendElement("tr");
    for (var i in info.columns) {
        tr.appendNode("th").innerText = info.columns[i].caption;
    }

    for (var i in info.data) {
        tr = table.appendElement("tr");
        for (var j in info.data[i])
            tr.appendNode("td").innerText = info.data[i][j];
    }

    document.body.appendChild(div.node);
    div.node.focus();
    document.execCommand("selectall");
    document.execCommand("copy");

    document.body.removeChild(div.node);

    alert("Dữ liệu đã được copy vào clipboard");
}