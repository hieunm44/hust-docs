﻿function Label(className, text) {
    HtmlElement.apply(this, ["label", className, text]);
}
function Field(tag) {

    HtmlElement.apply(this, ["div", "field"]);
    this.attributes = {};
    this.isAttributeUpdated = function (key, v) {
        switch (key) {
            case 'caption':
                if (v) this.label.node.innerText = v;
                return true;

            case 'value':
                if (v) {
                    this.setValue(v);
                    this.attributes.value = null;
                }
                return true;

            case 'placeholder':
                this.input.setAttribute(key, v);
                return true;

            case 'name':
                if (v) {
                    this.input.setAttribute(key, v);
                    this.input.setAttribute("id", v);
                    this.label.setAttribute("for", v);
                }
                return true;
        }
        return false;
    }
    this.setValue = function (v) {
        this.input.node.value = v;
    }

    function Content() {
        HtmlElement.apply(this, ["div", "field-content"]);
    }

    this.content = this.append(new Content());

    if (tag) {
        this.input = this.content.append(new HtmlElement(tag, "field-input"));
        this.label = this.content.append(new Label());

        var self = this;
        this.input.addEvent("focus", function () {
            self.attributes.dataCaption = "show";
            self.attributes.dataContent = null;
            self.attributes.placeholder = null;
            self.updateAttributes();
        });

        this.input.addEvent("focusout", function () {
            if (self.isInputEmpty() && !self.isError()) {
                self.attributes.placeholder = self.attributes.caption;
                self.attributes.dataCaption = null;
                self.updateAttributes();
            }
        });
    }

    this.isInputEmpty = function () {
        return this.valueOf() == "";
    }
    this.valueOf = function () { return this.input.node.value; }

    this.show = function (b) { this.node.style.display = b ? "block" : "none"; }


    this.setHalf = function (next) {
        this.node.className += " half";
        var p = next == true ? this.node.nextElementSibling : this.node.previousElementSibling;
        p.className += " half";
    }

    this.isError = function () {
        return false;
    }
    this.setErrorText = function (text) {
        if (text == null) text = this.attributes.caption + " không được để trống";
        this.attributes.dataContent = "empty";
        this.updateAttributes();
        this.label.node.innerText = text;
    }

    this.setRequired = function (b) {
        if (b == '0') return;

        var input = this.input.node;

        input.required = true;
        input.addEventListener("focusout", function () {
            if (self.isError()) {
                self.attributes.dataContent = "empty";
                self.updateAttributes();
                self.setErrorText();
            }
        });
    }

    this.dataBind = function (data) {
        var type = data.type;
        if (!type) type = "TextBox";

        this.attributes.name = data.name;
        this.attributes.caption = data.caption;
        this.attributes.placeholder = data.caption;
        this.attributes.dataSize = data.width;

        this.setRequired(data.required);

        if (data.dataSize) {
            control.attributes.dataSize = data.dataSize;
        }

        /* Cập nhật dữ liệu */
        if (data.value) {
            this.setValue(data.value);
            this.attributes.dataCaption = "show";
        }

        /* Cập nhật các thuộc tính */
        this.updateAttributes();
    }

    this.beforeSubmit = function () {
    }

    this.needFormData = function () { return false; }
}
function Input(type) {

    Field.apply(this, ["input"]);
    this.input.node.type = type;

}
function TextBox() {

    Input.apply(this, ["text"]);
    this.valueOf = function () {
        return this.input.node.value.trim();
    }


    this.isError = function () {
        return (this.input.node.required && this.valueOf() == "");
    }
}
function FileBox() {

    TextBox.apply(this);

    this.input.node.disabled = true;
    var btn = new Button('file', 'Chọn');
    btn.addEvent("click", function () {
        this.disabled = true;

        var timer = setInterval(function () { clearInterval(timer); btn.node.disabled = false; }, 100);
        file.click();
    });

    var file = this.content.appendNode("input");
    file.type = "file";
    file.style.display = "none";
    if (ext != null) { file.accept = ext; }

    var box = this;
    file.addEventListener("change", function () {
        if (this.files.length == 0)
            return;

        var msg = box.isFileValid(this.files[0]);
        if (msg != null) {
            box.showError(msg);
            return;
        }

        box.hideError();
        box.attributes.value = this.files[0].name;
        box.attributes.dataCaption = "show";

    });

    this.isFileValid = function (f) {
        if (maxSize != null) {
            if (f.size > maxSize) {
                return this.getFileInvalidMessage(f);
            }
        }
        return null;
    }
    this.getFileInvalidMessage = function (f) {
        return "Kích thước file quá lớn";
    }

    this.valueOf() = function () {
        if (file.files.length != 0)
            return file.files[0];
        return null;
    }
    this.needFormData = function () { return true; }
    this.content.appendChild(btn.node);

}
function CheckBox() {

    Input.apply(this, ["checkbox"]);
    this.isOwnAttribute = function (key, value) {
        if (key == 'caption') {
            text.innerText = value;
            return false;
        }

        return key != 'placeholder';
    }

    var text = this.label.appendNode("span");
    this.label.node.className = this.input.node.className;
    this.input.hide();
    this.content.appendNode("div", "check-indicator");

    var temp = this.content.appendNode("input");
    temp.hidden = true;


    this.valueOf = function () {
        return this.input.node.checked ? 1 : 0;
    }
    this.setValue = function (value) {
        this.input.node.checked = value == 1 || value == true ? true : false;
    }

    this.attributes.dataRole = "check-control";
    this.setRequired = function () { }
    this.beforeSubmit = function () {
        var name = this.attributes.name;
        if (name) {
            temp.name = name;
            this.attributes.name = null;
            this.input.node.name = '';
        }

        temp.value = this.valueOf();
    }
}
function RadioBox(info) {
    Field.apply(this);
    this.content.node.style.height = "auto";

    this.dataBind = function (data) {
        for (var i in data.items) {
            var item = this.content.appendElement("label", "radio-item");
            item.node.innerText = data.items[i].caption;

            item.appendNode("span", "radio-frame");
            item.appendNode("span", "indicator");
            var input = item.appendNode("input");
            input.name = data.name;
            input.value = data.items[i].value;
            input.id = input.name + i;
            input.type = "radio";

            if (data.value && input.value == data.value) {
                input.checked = true;
                item.setAttribute("data-role", "checked");
            }

            item.setAttribute("for", input.id);
            input.addEventListener("change", function (e) {
                var r = e.srcElement;
                var p = r.parentElement.parentElement.firstElementChild;

                while (p) {
                    p.setAttribute("data-role", "");
                    p = p.nextElementSibling;
                }

                r.parentElement.setAttribute("data-role", r.checked ? "checked" : "");
            });
        }
    }

    if (info) this.dataBind(info);
}
function ComboBox() {

    Field.apply(this, ["select"]);

    this.setAttribute("data-caption", "show");

    this.content.className += " field-select show-label";
    this.content.appendElement("div", "combo-indicator").appendNode("div");

    var baseDataBind = this.dataBind;
    this.dataBind = function (data) {
        this.attributes.dataCaption = "show";

        baseDataBind.call(this, data);

        if (data.items) {
            for (var j in data.items) {
                var item = data.items[j];
                this.addItem(item[0], item[1]);
            }
        }

        if (data.value)
            this.setValue(data.value);
    }

    this.addItem = function (value, text) {
        var op = document.createElement("option");
        op.setAttribute("value", value);
        op.innerText = text == null ? value : text;

        var nod = null;
        text = op.innerText;
        nod = this.input.node.firstElementChild;
        while (nod != null) {
            if (nod.innerText > text) {
                nod.parentNode.insertBefore(op, nod);
                return;
            }
            nod = nod.nextElementSibling;
        }

        if (nod == null)
            this.input.node.appendChild(op);
    }

    this.isInputEmpty = function () { return false; }
}
function MultiLineBox() {

    Field.apply(this, ["textarea"]);
    this.input.setAttribute("rows", "5");
}
function DateBox() {

    TextBox.apply(this);

    var self = this;
    this.input.addEvent("change", function (e) {
        correctDate(e.srcElement);
        self.input.node.placeholder = self.attributes.caption;
    });

    this.input.addEvent("focus", function () {
        self.input.node.placeholder = "ngày tháng năm";
    });


    var vContent = this.appendNode("input");
    vContent.hidden = true;

    this.isOwnAttribute = function (name, value) {
        if (name == 'name') {
            vContent.name = value;
            return false;
        }
        return true;
    }

    this.valueOf = function () {
        var s = this.input.node.value.trim();
        if (s.length == 0)
            return null;

        var v = s.split('/');
        var t = v[0]; v[0] = v[2]; v[2] = t;
        return v.join('-');
    }

    this.beforeSubmit = function () {
        vContent.value = this.valueOf();
    }
}
function correctDate(c) {
    function pad(d) { return d < 10 ? '0' + d : d; }
    var v = c.value;
    if (v.length == 0)
        return;
    v += '/';

    var t = [0, 0, 0];
    var a = 0;
    var count = 0;
    for (var i = 0; i < v.length; i++) {
        var d = v[i];
        if (d < '0' || d > '9') {
            t[count++] = a;
            if (count == 3) break;

            a = 0;
            continue;
        }
        a = a * 10 + (d & 15);
    }

    var today = new Date();
    var s = [today.getDay(), today.getMonth() + 1, today.getFullYear()];

    for (var i = 0; i != t.length; i++) {
        if (t[i] != 0)
            s[i] = t[i];
    }

    var y = s[2];
    if (y < 30)
        s[2] = y + 2000;
    else if (y < 100)
        s[2] = y + 1900;

    var day = new Date(s[2], s[1] - 1, s[0]);
    c.value = [pad(day.getDate()), pad(day.getMonth() + 1), day.getFullYear()].join('/');
}

function PasswordBox() {

    TextBox.apply(this);

    this.prefix = function () { return null; }
    this.input.node.type = "password";

    var temp = this.appendNode("input");
    temp.hidden = true;

    this.isOwnAttribute = function (name, value) {
        if (name == 'name') {
            temp.name = value;
            return false;
        }
        return true;
    }
    this.beforeSubmit = function () {
        var v = this.input.node.value.trim();
        var p = this.prefix();

        if (p)
            v = MD5(p + v);
        temp.value = v;
    }

    this.confirm = function (password) {
        return this.input.valueOf() == password;
    }
}
function ConfirmPass() {
    TextBox.apply(this);
    this.input.setAttribute("type", "password");

    this.setRequired = function (pass) {
        if (!pass) return;

        var self = this;
        this.isError = function () {
            var v = self.valueOf();
            if (v == "") {
                self.setErrorText();
                return true;
            }

            if (pass.valueOf() != v) {
                self.setErrorText("Mật khẩu không khớp");
                return true;
            }
            return false;
        }

        this.addEvent("focusout", function () {
            self.isError();
        });
    }
}
function NameBox() {

    TextBox.apply(this);

    this.input.addEvent("change", function () {
        v = this.value;

        v = v.trim();
        var last = ' ';
        var arr = v.split('');
        var s = '';

        for (var i = 0; i != arr.length; i++) {
            var d = arr[i];
            if (last == ' ') {
                if (d == ' ') continue;
                d = d.toUpperCase();
            }
            else {
                d = d.toLowerCase();
            }
            s += (last = d);
        }

        this.value = s;
    });
}
function HtmlEditor() {

    TextBox.apply(this);

    this.input.hide();

    var editor = new HtmlElement("div", this.input.node.className);
    editor.node.contentEditable = true;

    this.content.append(editor);
    this.content.node.style.height = "auto";

    this.attributes.dataCaption = "show";
    this.attributes.dataType = "html";

    this.isOwnAttribute = function (name, value) {
        if (name == 'name') {
            this.input.node.name = value;
            editor.node.id = value;
            return false;
        }
        return true;
    }

    this.beforeSubmit = function () {
        this.input.node.value = this.valueOf();
    }
    this.needFormData = function () { return true; }

    this.setValue = function (value) {
        editor.node.innerHTML = unescape(value);
    }
    this.valueOf = function () {
        var v = escape(editor.node.innerHTML);
        return v;
    }
    this.textValue = function () {
        return editor.node.innerText;
    }
    this.htmlValue = function () {
        return editor.node.innerHtml;
    }

    this.setRequired = function () { }
}

function SearchBox() {
    Field.apply(this);

    this.input = this.content.append(new HtmlElement("input", "field-input"));
    this.input.addEvent("keypress", function () {
        if (val.value != '' && event.keyCode == 13)
            queryManager.openURL("?search=" + escape(val.value));
    });
    this.input.addEvent("focus", function () {
        val.parentElement.setAttribute("data-search", "focus");
    });

    this.input.addEvent("focusout", function () {
        val.parentElement.removeAttribute("data-search");
    });

    var val = this.input.node;
    val.setAttribute("autocomplete", "on");
    val.name = "search";
    this.attributes.dataRole = val.name;
    this.attributes.placeholder = "search ...";

    this.content.appendNode("span").addEventListener("click", function () {
        if (val.value != '')
            queryManager.openURL("?search=" + escape(val.value));
        else
            val.focus();
    });
}

function DataSender() {

    var formData = new FormData();
    this.append = function (key, data) {
        formData.append(key, data);
    }
    this.send = function (params, url) {
        if (!url)
            url = window.location.href;

        var xhr = new XMLHttpRequest();
        var query = "?update=";
        if (params)
            query += params;

        xhr.addEventListener("load", function (e) { queryManager.openURL(url); });

        xhr.open("POST", query, false);
        xhr.send(formData);
    }
}

function Button(name, info, form) {
    HtmlElement.apply(this, ["button", null, info.caption]);

    this.node.name = name;
    if (info.onclick) {
        this.setAttribute("onclick", info.onclick + ";return false;");
    }
    else {
        this.addEvent("click", function () {
            return form.onSubmit(this);
        });
    }
}
function FormView(info) {
    Paragraph.apply(this, [info]);

    this.attributes = { autocomplete: "off", dataRole: 'form' };

    this.submit = function () {
        if (this.onSubmit())
            this.controls.node.submit();
    }
    this.onSubmit = function (button) {

        var sender = null;

        for (var i in inputs) {
            var control = inputs[i];
            if (control.isError())
                return false;

            if (control.needFormData() && !sender)
                sender = new DataSender();

            control.beforeSubmit();
        }

        var key = null;
        if (info && info.keys)
            key = info.keys[0];

        if (sender) {

            if (button) button.disabled = true;

            for (var i in inputs) {
                var control = inputs[i];
                sender.append(control.attributes.name, control.valueOf());
            }


            sender.send(key);
            return false;
        }


        if (button) button.value = key;
        return true;
    }

    var inputs = [];

    this.getInputs = function () { return inputs; }
    this.controls = this.append(new function () {
        HtmlElement.apply(this, ["form"]);
        var content = this.appendElement("div");

        this.createEntity = function (key, value) {
            var type = value.type;
            if (!type) type = "TextBox";

            var control = content.append(new window[type]);
            var k = inputs.length;

            if (k == 0 && control.input)
                control.input.node.tabindex = 0;;

            return inputs[k] = control;
        }
    });

    var self = this;
    this.actions = this.controls.append(new function () {
        Panel.apply(this, ["footer"]);

        this.createEntity = function (key, value) {
            return this.append(new Button(key, value, self));
        }
    });
}

function onTreeViewItemClick(info) {
    alert("call onTreeViewItemClick(info)");
}

function TreeViewContent(cls) {
    HtmlElement.apply(this, ["div", cls]);

    function Item(info) {
        HtmlElement.apply(this, ["div"]);

        this.label = this.appendElement("label");
        var icon = this.label.appendNode("span");
        if (info.url) {
            var a = new HtmlElement("a", null, info.caption);
            this.label.append(a);
            a.node.href = info.url;

            if (info.url == '#') {
                a.addEvent("click", function () {
                    onTreeViewItemClick(info);
                });
            }

            var cls = info.name;
            if (!cls)
                cls = "leaf";
            this.node.className = cls;
            return;
        }

        this.label.node.appendChild(document.createTextNode(info.caption));
        this.label.attributes = { dataState: "closed" };

        this.label.addEvent("click", function () {
            var name = "data-state";
            this.setAttribute(name, this.getAttribute(name)[0] == 'c' ? "opened" : "closed")
        });

        this.label.updateAttributes();
        this.content = this.append(new TreeViewContent("child-content"));
    }

    this.newItem = function (info) {
        return this.append(new Item(info));
    }

    this.dataBind = function (data) {
        if (!data) return;

        for (var i in data) {
            var v = data[i];
            var item = this.newItem(v);
            if (v.childs)
                item.content.dataBind(v.childs);
        }
    }
}

function TreeView(info) {
    TreeViewContent.apply(this, ["tree-view"]);

    var baseDataBind = this.dataBind;
    this.dataBind = function (info) {
        baseDataBind.call(this, info.nodes);
    }
}

function doCancel() {
    window.history.back();
    return false;
}
