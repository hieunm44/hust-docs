﻿function Entity() {
    this.dataBind = function (info) {
        for (var key in info) {
            var value = info[key];
            if (value == null)
                continue;

            var e = this[key];

            if (e == null)
                e = this.createEntity(key, value);

            if (e != null) {
                this[key] = e;
                e.dataBind(value);
            }
        }
    }
    this.createEntity = function (key, value) {
        return null;
    }
}
function HtmlElement(tagName, className, content) {

    Entity.apply(this);

    this.node = null;
    if (tagName != null) {
        this.node = document.createElement(tagName);
        if (content != null) this.node.innerHTML = content;
        if (className != null)
            this.node.className = className;
    }

    this.addEvent = function (name, func) {
        this.node.addEventListener(name, func);
    }

    this.append = function (element) {
        element.updateAttributes();
        this.node.appendChild(element.node);
        return element;
    }
    this.prepend = function (element) {
        element.updateAttributes();
        this.node.insertBefore(element.node, this.node.firstElementChild);
        return element;
    }

    this.appendElement = function (tagName, className) {
        return this.append(new HtmlElement(tagName, className));
    }
    this.prependElement = function (tagName, className) {
        return this.prepend(new HtmlElement(tagName, className));
    }

    this.appendNode = function (tagName, className) {
        return this.append(new HtmlElement(tagName, className)).node;
    }
    this.prependNode = function (tagName, className) {
        return this.prepend(new HtmlElement(tagName, className)).node;
    }

    this.show = function (n) {
        if (n == null) n = "block";
        this.node.style.display = n;
    }
    this.hide = function () {
        this.node.style.display = "none";
    }
    this.remove = function () {
        this.node.parentNode.removeChild(this.node);
    }

    this.attributes = null;
    this.isOwnAttribute = function (name, value) { return true; }
    this.isAttributeUpdated = function (name, value) { return false; }
    function getAttributeName(key) {
        var s = "";
        for (var i in key) {
            var c = key[i];
            if (c >= 'A' && c <= 'Z') {
                c = c.toLowerCase();
                s += '-';
            }
            s += c;
        }
        return s;
    }

    this.updateAttributes = function () {
        if (this.attributes) {
            for (var key in this.attributes) {
                var v = this.attributes[key];

                if (key == "info" && v) {
                    this.dataBind(v);
                    continue;
                }

                if (!this.isOwnAttribute(key, v))
                    continue;

                if (this.isAttributeUpdated(key, v))
                    continue;

                var name = getAttributeName(key);
                this.setAttribute(name, v);
            }
        }
        this.updateAttributesCompleted();
    }
    this.updateAttributesCompleted = function () { }

    this.setAttribute = function (name, value) {
        if (value == null) this.node.removeAttribute(name, value);
        else this.node.setAttribute(name, value);
    }

    this.valueOf = function () { return this.node.value; }
}
function HtmlNode(node) {
    HtmlElement.apply(this);
    this.node = node;
}

function Panel(className) {
    HtmlElement.apply(this, ["div", className]);
}

function QueryManager() {

    var h = window.location.href;
    var i = h.indexOf('?');

    this.content = {};
    if (i != -1) {
        var v = h.substring(i + 1).split('&');
        for (i = 0; i != v.length; i++) {
            var s = v[i].split('=');
            this.content[s[0]] = s[1];
        }
    }

    this.toQuery = function () {
        var s = "";
        for (var name in this.content) {
            var v = this.content[name];
            if (!v) continue;

            if (s.length != 0)
                s += '&';
            s += name + '=' + v;
        }
        return '?' + s;
    }

    var anchor = new HtmlElement("a");
    this.openURL = function (targetURL) {
        if (!targetURL)
            targetURL = this.toQuery();
        //alert(browser());
        //anchor.node.href = targetURL;
        //anchor.node.click();

        window.location.href = targetURL;

    }

    var browser = function () {
        // Return cached result if avalible, else get result then cache it.
        if (browser.prototype._cachedResult)
            return browser.prototype._cachedResult;

        // Opera 8.0+
        var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

        // Firefox 1.0+
        var isFirefox = typeof InstallTrigger !== 'undefined';

        // Safari 3.0+ "[object HTMLElementConstructor]" 
        var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);

        // Internet Explorer 6-11
        var isIE = /*@cc_on!@*/false || !!document.documentMode;

        // Edge 20+
        var isEdge = !isIE && !!window.StyleMedia;

        // Chrome 1+
        var isChrome = !!window.chrome && !!window.chrome.webstore;

        // Blink engine detection
        var isBlink = (isChrome || isOpera) && !!window.CSS;

        return browser.prototype._cachedResult =
            isOpera ? 'Opera' :
            isFirefox ? 'Firefox' :
            isSafari ? 'Safari' :
            isChrome ? 'Chrome' :
            isIE ? 'IE' :
            isEdge ? 'Edge' :
            isBlink ? 'Blink' :
            "Don't know";
    }
}

function SubPageContent() {
    HtmlElement.apply(this, ["div"]);
    this.node.id = "subpage";

    this.addPage = function (caption, url) {
        var a = this.appendElement("div").appendNode("a");
        a.innerText = caption;

        if (window.location.href.indexOf(url) != -1) {
            a.parentElement.setAttribute("data-role", "active");
            return;
        }

        a.href = url;
    }

    this.dataBind = function (pages) {
        for (var i in pages) {
            var a = pages[i];
            this.addPage(a.caption, a.url);
        }
    }
}
function SideMenu() {
    HtmlElement.apply(this, ["div", "nav-side-menu"]);

    this.caption = this.append(new function () {
        Panel.apply(this, ["menu-caption"]);
        this.dataBind = function (info) {
            this.node.innerHTML = info.caption;
            this.addEvent("click", function () { queryManager.openURL(info.url); });
        }
    });
    this.button = this.append(new HtmlElement("i", "fa fa-bars fa-2x toggle-btn"));
    this.button.node.setAttribute("data-toggle", "collapse");
    this.button.node.setAttribute("data-target", "#menu-content");

    var content = this.append(new HtmlElement("div", "menu-list")).append(new HtmlElement("ul", "menu-content collapse"));
    content.node.id = "menu-content";

    var cur = document.location.pathname.split('/')[1];
    function Category(f, categoryId) {

        HtmlElement.apply(this, ["li", "collapsed"]);
        this.node.setAttribute("data-toggle", "collapse");
        this.node.setAttribute("data-target", "#category" + categoryId);

        var a = this.append(new HtmlElement("a"));
        a.node.setAttribute("href", "#");
        a.node.innerText = f.caption.toUpperCase();

        a.appendNode("span", "arrow");

        var ul = this.append(new HtmlElement("ul", "sub-menu collapse"));
        ul.node.id = "category" + categoryId;

        if (cur != null && cur == f.name) {
            cur = null;
            ul.node.className += " in";
        }

        this.addSub = function (text, href) {
            ul.append(new SubMenu(text, href));
        }
    }
    function SubMenu(text, href) {
        HtmlElement.apply(this, ["li"]);
        if (href != null) {
            var a = this.appendNode("a");
            a.href = href;
            a.text = text;
        }
        else {
            this.node.innerText = text;
        }
    }

    this.dataBind = function (fhd) {
        for (var i in fhd) {
            var f = fhd[i];
            var ca = content.append(new Category(f, i));

            var items = f.items;
            for (var j in items) {
                ca.addSub(items[j][0], items[j][1]);
            }
        }
    }
}

function MainContent() {
    Panel.apply(this);
    this.node.id = "main-content";

    this.newParagraph = function (info) {
        var para = new window[info.type](info);

        var key = info.ID;
        if (!key) key = 'first';

        para.node.id = key;
        this[key] = para;

        para.dataBind(info);
        return this.append(para);
    }
    this.dataBind = function (arr) {
        for (var i in arr) {
            this.newParagraph(arr[i]);
        }
    }
}

function Layout(page) {

    HtmlElement.apply(this, ["div", "layout"]);

    this.beginAddNew = function () { queryManager.openURL("?add="); }

    this.mainContent = this.append(new MainContent());

    this.createEntity = function (key, info) {
        switch (key) {
            case 'home': {
                if (this.sideMenu == null)
                    this.createEntity("sideMenu");
                return this.sideMenu.caption;
            }
            case 'sideMenu':
                return this.append(new SideMenu());

            case 'subpages':
                return this.mainContent.prepend(new SubPageContent());
        }
        return null;
    }

    if (page) this.dataBind(page);
}

function Paragraph(data) {
    Panel.apply(this, ["paragraph"]);

    this.header = this.append(new function () {
        Panel.apply(this, ["header"]);

        function Text(role) {
            HtmlElement.apply(this, ["span"]);
            this.node.setAttribute("data-role", role);

            this.dataBind = function (info) {
                this.node.innerText = info;
            }
        }

        this.caption = this.append(new Text("main-caption"));
        this.subCaption = this.append(new Text("sub-caption"));
        this.actions = this.append(new function () {
            Panel.apply(this, ["action-panel"]);
            this.node.style.position = "relative";

            function Link(name, info) {
                HtmlElement.apply(this, ["a", "pa " + name, info.caption]);

                this.dataBind = function (ainfo) {
                    if (ainfo.url) {
                        this.setAttribute("href", ainfo.url);
                    }
                    if (ainfo.onclick) {
                        this.setAttribute("onclick", ainfo.onclick);
                    }
                }
            }

            this.createEntity = function (key, value) {
                return this.append(new Link(key, value));
            }

        });

        this.createEntity = function (key, value) {
            if (key == "search") {
                this.actions.append(new SearchBox());
            }
            return null;
        }
    });
}

function ContextMenuContent() {
    Panel.apply(this);
    this.attributes = { style: "position: absolute", dataRole: "context-menu-content" };
    this.newItem = function (text, url) {
        var a = this.appendElement("div").appendElement("a");
        a.node.innerText = text;
        a.node.href = url;
        return a;
    }
}
function ContextMenu(data) {
    Panel.apply(this);
    this.attributes = { style: "position: relative", dataRole: "context-menu" };

    var label = this.appendElement("label");
    var caption = label.appendElement("span").node;

    var content = label.append(new ContextMenuContent());
    label.append(content);

    this.newItem = function (text, url) {
        return content.newItem(text, url);
    }

    this.dataBind = function (data) {
        caption.innerText = data.caption;
        if (!data.items) return;
        for (var i in data.items) {
            var item = data.items[i];
            this.newItem(item[0], item[1]);
        }
    }

    if (data) this.dataBind(data);
}

function DropDownMenu(info) {
    Panel.apply(this, ["drop-down"]);

    var span = this.appendNode("span", "pa");

    var list = this.append(new ContextMenuContent());
    function switchList() {
        list.node.style.display == "block" ? list.hide() : list.show();
        list.node.style.left = span.offsetLeft + "px";
    }

    window.addEventListener("click", function (e) {
        if (e.srcElement != list.node.previousElementSibling)
            list.hide();
    });
    this.node.addEventListener("click", function () {
        switchList();
    });

    this.newItem = function (text, url) {
        return list.newItem(text, url);
    }
    this.dataBind = function (data) {
        span.innerText = data.caption;
        for (var i in data.items) {
            var v = data.items[i];
            this.newItem(v[0], v[1]);
        }
    }

    if (info) this.dataBind(info);
}

function StyleSheetItem(name) {
    var nodes = [];
    function pair(n, v) {
        this.name = n;
        this.value = v;
    }
    this.setAttribute = function (n, v) {
        for (var i in nodes) {
            if (nodes[i].name == n) {
                nodes[i].value = v;
                return;
            }
        }

        nodes[nodes.length] = new pair(n, v);
    }

    this.getContent = function () {
        var s = "." + name + "{";
        for (var i in nodes) {
            if (nodes[i].value == null)
                continue;
            s += nodes[i].name + ":" + nodes[i].value + ";";
        }
        s += "}";
        return s;
    }
}
function StyleSheet() {
    HtmlElement.apply(this, ["style"]);

    this.items = [];
    this.append = function (name) {
        return this.addItem(new StyleSheetItem(name));
    }

    this.addItem = function (item) {
        this.items[this.items.length] = item;
        return item;
    }

    this.refresh = function () {
        var s = "";
        for (var i in this.items)
            s += this.items[i].getContent();
        this.node.innerText = s;
    }

    this.dataBind = function () { }
}

function setRefreshInterval(seconds) {
    setInterval(function () { queryManager.openURL(""); }, 1000 * seconds);
}