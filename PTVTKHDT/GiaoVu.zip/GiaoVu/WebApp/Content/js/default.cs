using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.Content.js
{
    public partial class Entity : App.DataEntity
    {
        public string FileName;
        public override object GetAttribute(string name)
        {
            return FileName;
        }

        public override bool HasData
        {
            get
            {
                return true;
            }
        }

        public override object ID
        {
            get
            {
                return FileName;
            }
        }
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        public override List<Entity> Select(string filter, string sort)
        {
            foreach (var fi in new Service.JSDirectory().GetFiles())
            {
                this.Add(new Entity { FileName = fi.Name });
            }
            return this;
        }
        public override void UpdateView(AppView view)
        {
            view.DataSource = this.Select();
            view.DataBind();
        }
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        protected override void ProcessPostData()
        {
            Service.Content.Upload(this.Command.Request.Files[0], null);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}