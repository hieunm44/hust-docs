﻿function ImportEngine() {
    var main = layout.mainContent;
    var mainCaption = page.mainContent[0].header.caption;
    var iInfo = page.mainContent[0].importInfo;
    var data = [];

    var importData = {
        ID: 'formPaste',
        type: 'FormView',
        header: {
            caption: mainCaption,
            subCaption: 'Nhập liệu từ clipboard',
        },
        controls: { text: { name: 'import-text', type: 'HtmlEditor' } },
        actions: {
            config: { caption: 'Cấu hình', onclick: 'importEngine.showConfig()' },
            ok: { caption: 'Nhập', onclick: 'importEngine.showData()' },
        }
    };
    var frmPaste = main.newParagraph(importData);
    var frmCauHinh;

    this.showData = function () {
        var previewData = {
            ID: 'preview',
            type: 'Table',
            header: {
                caption: mainCaption,
                subCaption: 'Các bản ghi nhập liệu',
                actions: {
                    submit: { caption: 'Xác nhận', url: '#', onclick: 'importEngine.send()' },
                    cancel: { caption: 'Hủy', url: window.location.href }
                },
            },
            columns: page.mainContent[0].importInfo,
            data: [],
        };

        var lines = frmPaste.controls.text.textValue().split('\n');

        /* Xác định vị trí các cột */
        var k = [];
        var header = lines[0].toLowerCase().split('\t');
        for (var i in iInfo) {
            var name = iInfo[i].src;
            if (!name)
                name = iInfo[i].caption;

            var f = name.toLocaleLowerCase();

            k[i] = -1;
            for (var j in header) {
                if (header[j] == f) {
                    k[i] = j;
                    break;
                }
            }
        }

        /* Đọc dữ liệu */
        data = [];
        if (k.length > 0) {
            for (var i = 1; i < lines.length; i++) {
                if (lines[i].length == 0)
                    continue;

                var line = lines[i].split('\t');
                var values = [];

                var hasData = false;
                for (var j in k) {
                    var index = k[j];
                    if (index >= 0) {
                        values[j] = line[index];
                        hasData = true;
                    }
                    else {
                        values[j] = '';
                    }
                }

                if (hasData)
                    data[data.length] = values;
            }

            if (data.length > 0) {
                previewData.data = data;
                previewData.pageSplit = { index: 1, rows: 10, total: data.length };
            }
        }

        var view = main.newParagraph(previewData);

        view.onPageRequest = function (index) {
            view.pageSplit.dataBind(previewData.pageSplit);
        }

        frmPaste.remove();
        view.show();
    }

    main.first.hide();
    frmPaste.show();

    this.showConfig = function () {
        var info = {
            header: { caption: 'Cấu hình nhập liệu', subCaption: mainCaption },
            ID: 'config',
            type: 'FormView',
            actions: {
                ok: { caption: 'Hoàn tất', onclick: 'importEngine.acceptConfig()' },
                cancel: { caption: 'Hủy', onclick: 'importEngine.hideConfig()' }
            },
            controls: {},
        };

        for (var i in iInfo) {
            var c = { caption: iInfo[i].caption, required: 0, value: iInfo[i].src };

            info.controls['f' + i] = c;
        }

        frmCauHinh = layout.mainContent.newParagraph(info);
        frmCauHinh.onSubmit = function (button) {
            button.disabled = true;

            hideConfig();
        }


        frmPaste.hide();
        frmCauHinh.show();

    }

    this.acceptConfig = function () {
        var controls = layout.mainContent.config.getInputs();
        for (var i in controls) {
            var v = controls[i].valueOf();
            iInfo[i].src = v.length > 0 ? v : null;
        }
        this.hideConfig();
    }

    this.hideConfig = function () {
        frmCauHinh.remove();
        frmPaste.show();
    }

    this.send = function () {
        var names = [];
        var src = [];
        for (var i in iInfo) {
            names[i] = iInfo[i].name;
            src[i] = iInfo[i].caption;
        }

        var lines = [];
        for (var i in data) {
            lines[i] = data[i].join('\t');
        }

        var s = names.join('\t') + '\n' + src.join('\t') + '\n' + lines.join('\n');

        var sender = new DataSender();
        sender.append("import", escape(s));

        sender.send();
    }
}