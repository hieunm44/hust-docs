﻿function BarChart(data) {
    HtmlElement.apply(this, ["canvas"]);

    var colors;
    var w, h;
    var horiz;
    var maxVal;
    var ctx = this.node.getContext("2d");

    function Bar() {
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;

        this.draw = function (color) {
            ctx.fillStyle = color;
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }
    function BarGroup(values) {
        var bars = [];
        for (var i in values)
            bars[i] = new Bar();

        this.calculate = function (width, height) {

            if (horiz) {
                var t = width; width = height; height = t;
            }

            var dx = width / values.length;
            var dy = height / maxVal;
            var x = dx / 4;

            for (var i in bars) {
                var b = new Bar();
                var h = values[i] * dy;

                b.x = x;
                b.y = height - h;
                b.width = dx / 2;
                b.height = h;

                if (horiz) {
                    b.y = x;
                    b.x = 0;

                    b.height = b.width;
                    b.width = h;
                }
                x += dx;

                bars[i] = b;
            }
        }

        this.draw = function () {
            var j = 0;
            for (var i in bars) {
                bars[i].draw(colors[j]);
                if (++j == colors.length)
                    j = 0;

            }
        }

        this.offset = function (dx, dy) {
            for (var i in bars) {
                bars[i].x += dx;
                bars[i].y += dy;
            }
        }
    }

    var groups = [];
    function createGroup(values) {
        var g = new BarGroup(values);
        var i = groups.length;

        groups[i] = g;
        g.calculate(w, h);

        var dx = w * i;
        var dy = 0;

        if (horiz) { dx = 0; dy = h * i; }
        g.offset(dx, dy);


        return g;
    }

    function getMax(values) {
        var max = values[0];
        for (var i in values) {
            if (max < values[i]) max = values[i];
        }
        return max;
    }

    this.dataBind = function (data) {
        var c = this.node;
        var ratio = Math.max(window.devicePixelRatio || 1, 1);
        c.width = c.offsetWidth * ratio;
        c.height = c.offsetHeight * ratio;

        w = c.width;
        h = c.height;
        if (horiz = (data.orient == 'horiz'))
            h /= data.items.length;
        else
            w /= data.items.length;

        colors = data.colors;
        if (!colors) colors = ['red', 'green', 'blue'];

        var items = data.items;
        if (!data.max) {
            for (var i in items) {
                var max = getMax(items[i]);
                if (!maxVal)
                    maxVal = max;

                if (max > maxVal) maxVal = max;
            }
        }
        else {
            maxVal = data.max;
        }


        for (var i in items) {
            createGroup(items[i]).draw();
        }
    }
}