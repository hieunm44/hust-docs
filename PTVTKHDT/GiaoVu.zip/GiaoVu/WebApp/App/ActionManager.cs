﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

using VST.Schema;
namespace App
{
    //using VST.Schema.FHD;
    //using VST.Html;
    //public class ActionManager
    //{
    //    public static ActionGroup PageActions; 
    //    public static void LoadActions(Diagram diagram, string path)
    //    {
    //        var tags = new ActionGroup();
    //        tags.LoadTemplate(path);

    //        PageActions = tags;

    //        foreach (var p in diagram.Map)
    //        {
    //            var e = (Entity)p.Value;
    //            if (e.ActionList != null)
    //                continue;

    //            string a = e.GetString("action");
    //            if (a == string.Empty)
    //                continue;

    //            if (a[0] == '0')
    //                continue;

    //            if (a[0] == '/')
    //            {
    //                if (a.Length == 1)
    //                    a += e.Name;

    //                var actions = tags.GetActionNodes(a);
    //                var dir = e.IsDirectory;
    //                if (dir == false)
    //                    e.ActionList = actions;

    //                foreach (XmlNode childNode in e.Node)
    //                {
    //                    var sub = childNode.Name + '/';
    //                    var child = diagram[p.Key + sub];
    //                    a = child.GetString("action");

    //                    if (a == string.Empty)
    //                    {
    //                        child.ActionList = actions.Clone();
    //                    }
    //                    else
    //                    {
    //                        if (a[0] == '+')
    //                            child.ActionList = actions + tags.GetActionNodes(a.Substring(1));
    //                    }

    //                    if (dir == false)
    //                        sub = "";
    //                    CreateDefaultHref(p.Key, sub, child.ActionList);
    //                }

    //                if (dir == false)
    //                    CreateDefaultHref("", e.Name, e.ActionList);
    //                continue;
    //            }
    //            e.ActionList = tags.GetActionNodes(a);
    //        }
    //    }
    //    static void CreateDefaultHref(string path, string sub, VST.Schema.ActionList lst)
    //    {
    //        var a = new VST.Html.Controls.HtmlControl();
    //        string h;
    //        foreach (XmlElement e in lst)
    //        {
    //            a.Node = e;
    //            h = a.href;
    //            if (h == string.Empty)
    //            {
    //                a.href = "../" + a.id;
    //                continue;
    //            }

    //            if (h == "?")
    //            {
    //                a.href = path;
    //                continue;
    //            }

    //            if (h[0] == '?')
    //            {
    //                a.href = path + h;
    //                continue;
    //            }
    //        }
    //    }
    //    public static VST.Schema.ActionList GetPageAction(Entity e)
    //    {
    //        if (e.GetString("action") == "0")
    //            return null;

    //        if (e.ActionList == null)
    //            e.ActionList = GetPageAction(e.Parent);
    //        return e.ActionList;
    //    }
    //    public static VST.Schema.ActionList GetPageAction()
    //    {
    //        return GetPageAction(Engine.FunctionalContext);
    //    }
    //    public static VST.Schema.ActionList GetPageAction(params string[] items)
    //    {
    //        return PageActions.GetActionNodes(items);
    //    }
    //    public static VST.Schema.ActionList GetPageAction(string value)
    //    {
    //        return PageActions.GetActionNodes(value.Split(','));
    //    }    
    //}


    //public class ActionGroup : XmlEntity
    //{
    //    public Dictionary<string, XmlElement> Map { get; private set; }

    //    public void LoadTemplate(string path)
    //    {
    //        var tags = Builder.Tags;
    //        var old = tags.Root["actions"];
    //        if (old != null)
    //            tags.Root.RemoveChild(old);

    //        var doc = new XmlDocument();
    //        doc.Load(path + "/design/actions.xml");

    //        this.Node = (XmlElement)tags.Document.ImportNode(doc.DocumentElement, true);
    //        this.Map = new Dictionary<string, XmlElement>();

    //        var node = this.Node.FirstChild;
    //        foreach (XmlElement child in node)
    //        {
    //            var a = child.Attributes["id"];
    //            if (a != null)
    //                this.Map.Add(a.Value, child);
    //        }

    //        while (true)
    //        {
    //            node = node.NextSibling;
    //            if (node == null)
    //                break;


    //            var newNode = this.Document.CreateElement(node.Name);
    //            this.Map.Add('/' + node.Name, newNode);

    //            foreach (XmlElement e in node)
    //            {
    //                if (e.Name == "a" || e.Name == "button")
    //                {
    //                    newNode.AppendChild(e.Clone());
    //                    continue;
    //                }

    //                XmlElement src;
    //                if (this.Map.TryGetValue(e.Name, out src) == false)
    //                    continue;

    //                var child = (XmlElement)newNode.AppendChild(src.Clone());
    //                foreach (XmlAttribute a in e.Attributes)
    //                    child.SetAttribute(a.Name, a.Value);

    //                if (e.InnerText != string.Empty)
    //                    child.InnerText = e.InnerText;
    //            }
    //        }
    //    }
    //    public ActionList GetActionNodes(params string[] items)
    //    {
    //        var lst = new ActionList();
    //        foreach (string item in items)
    //        {
    //            string key = item.Trim();
    //            if (key.Length == 0)
    //                continue;

    //            XmlElement node;
    //            if (key[0] == '/')
    //            {
    //                node = this.Map[key];
    //                foreach (XmlNode child in node)
    //                {
    //                    lst.Add(child.Clone());
    //                }
    //            }
    //            else
    //            {
    //                lst.Add(this.Map[key].Clone());
    //            }
    //        }
    //        return lst;
    //    }
    //    public ActionList GetActionNodes(string actions)
    //    {
    //        return this.GetActionNodes(actions.Split(','));
    //    }
    //}

}