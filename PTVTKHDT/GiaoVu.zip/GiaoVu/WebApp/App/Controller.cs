﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public partial class Controller : VST.IController
    {
        public IModel Model { get; protected set; }
        public ICollection Collection { get; protected set; }
        public PostBackCommand Command
        {
            get;
            set;
        }

        public virtual void ProcessRequest(App.PostBackCommand command)
        {
            if (this.Collection == null)
                this.Collection = (ICollection)this.LoadCollection(null);

            if (this.Model == null)
                this.Model = this.Collection;

            if (this.Command == null)
                this.Command = command;

            switch (command.ActionIndex)
            {
                case ActionIndex.Add:
                    this.AddEntity();
                    return;

                case ActionIndex.Open:
                    this.OpenEntity(this.Collection.Find(command.CommandValue));
                    return;

                case ActionIndex.Edit:
                    this.BeginEdit(this.Collection.Find(command.CommandValue));
                    return;

                case ActionIndex.Update:
                case ActionIndex.Submit:
                    this.ProcessPostData();
                    return;

                case ActionIndex.Delete:
                    ProcessDelete(command);
                    return;

                case ActionIndex.Search:
                    Engine.GetSearchEngine(command);
                    return;

                case ActionIndex.Download:
                    this.ProcessDownload(null, null);
                    return;
            }
        }

        public virtual void ProcessDelete(PostBackCommand command)
        {
            var model = this.Collection;
            foreach (string key in command.ItemKeys)
                ((DataEntity)model.Find(key)).Delete();
            this.UpdateDataBase();
        }

        public virtual void ProcessView(string name, AppView container)
        {
            this.Model.UpdateView(container);
            //if (name == "main-content")
            //{
            //    var model = this.Model;
            //    var view = model.CreateDefaultView();
            //    view = model.UpdateView(view);

            //    if (view != null)
            //        this.ProcessViewCompleted(view, container);
            //}
        }

        protected virtual IModel LoadCollection(string name)
        {
            if (name == null)
                name = Engine.FunctionalContext.ModelName;

            var collection = (VST.IDataCollection)this.CreateDefaultCollection();
            if (name != string.Empty)
                collection.Load(Global.DataProvider, name);

            return (IModel)collection;
        }
        protected virtual ICollection CreateDefaultCollection()
        {
            return new DefaultCollection();
        }

        protected virtual void OpenEntity(IEntity e)
        {
            this.Model = e;
        }
        protected virtual void BeginEdit(IEntity e)
        {
        }
        protected virtual void AddEntity()
        {
            this.Model = this.Collection.NewEntity();
        }

        protected virtual void UpdateDataBase(string backUrl)
        {
            Global.DataProvider.UpdateDataBase();
            Engine.Finish(backUrl);
        }
        public void UpdateDataBase()
        {
            this.UpdateDataBase(null);
        }

        protected virtual void ProcessPostData()
        {
            var command = this.LoadFormData();
            if (command == null)
                return;

            string key = command.CommandValue;
            if (key == "null")
                key = string.Empty;

            var entity = (DataEntity)this.Collection.Find(key);
            if (entity == null)
                entity = (DataEntity)this.Collection.NewEntity();

            entity.Execute(command);

            if (command.Exception == null)
            {
                Global.DataProvider.UpdateDataBase();
                this.UpdateDataBase();
            }
            else
            {
                this.RaiseException();
            }
        }

        protected virtual void RaiseException()
        {
        }

        protected virtual PostBackCommand LoadFormData()
        {
            var form = this.Command.Request.Form;
            foreach (string key in form.AllKeys)
                this.Command.Add(key, form[key]);

            return this.Command;
        }

        protected virtual void ProcessDownload(string attach, string fileName)
        {
            if (attach == null)
                attach = this.Command.GetString("attach");
            if (fileName == null)
                fileName = this.Command.GetString("filename");

            var fc = new FileController();
            fc.Download(this.Command, attach, fileName);
        }
    }
}