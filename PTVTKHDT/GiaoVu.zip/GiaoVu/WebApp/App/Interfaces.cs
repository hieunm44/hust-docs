﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace App
{
    public interface IModel : VST.Base.IModel<App.AppView>
    {
        string Name { get; }
    }

    public interface IEntity : IModel, VST.Base.IEntity<App.AppView>
    {
        object ID { get; }
        bool IsNew { get; }
        bool HasData { get; }
    }
}
