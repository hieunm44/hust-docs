﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public class StringList : List<object>
    {
        string _sep;
        public StringList(string seperator)
        {
            _sep = seperator;
        }
        public StringList()
        {
            _sep = "|";
        }

        public override string ToString()
        {
            string s = string.Empty;
            foreach (var v in this)
            {
                if (s.Length != 0)
                    s += _sep;
                s += v;
            }
            return s;
        }
        public string ToString(string format)
        {
            return string.Format(format, this.ToArray());
        }

        public void AddKey(object key)
        {
            if (this.Contains(key) == false)
                base.Add(key);
        }
    }

    public class DataPath : StringList
    {
        public DataPath() : base("/") { }
        public DataPath(string path) : base("/")
        { 
            this.AddRange(path.Split('/')); 
        }

        //string _name;
        //public string Name
        //{
        //    get 
        //    {
        //        if (_name == null)
        //        {
        //            string s = this.Value;
        //            int last = s.Length - 1;

        //            if (s[last] == '/')
        //                --last;

        //            int i = last;
        //            while (s[i] != '/') i--;

        //            _name = s.Substring(i + 1, last - i);
        //        }
        //        return _name; 
        //    }
        //}
        //public DataPath Parent
        //{
        //    get
        //    {
        //        string s = this.Value;
        //        return new DataPath { Value = s.Substring(0, s.Length - this.Name.Length - 1) };
        //    }
        //}

        public string[] ToLower()
        {
            int i = 0;
            var s = new string[this.Count];

            foreach (var v in this)
                s[i++] = v.ToString().ToLower();

            return s;
        }
    }

    public class FunctionParam : StringList
    {
        public FunctionParam() : base(",") { }
    }

    //public class JSArray
    //{
    //    List<object> _values = new List<object>();
    //    public void Add(object value)
    //    {
    //        _values.Add("'" + value + "'");
    //    }

    //    public void Add(string name, object value)
    //    {
    //        _values.Add("'" + name + "':'" + value + "'");
    //    }

    //    public void AddObject(string value)
    //    {
    //        _values.Add(value);
    //    }

    //    public override string ToString()
    //    {
    //        string s = "";
    //        foreach (var v in _values)
    //        {
    //            if (s.Length > 0)
    //                s += ',';
    //            s += v;
    //        }
    //        return s;
    //    }
    //    public string ToArray()
    //    {
    //        return "[" + this.ToString() + "]";
    //    }
    //    public string ToList()
    //    {
    //        return "{" + this.ToString() + "}";
    //    }
    //}
}