﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace App
{
    public class Page : System.Web.UI.Page
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            Engine.Start(this);

            this.LoadServiceContent();
        }

        protected virtual void LoadServiceContent()
        {
            var s =
                "<script src='/content/js/chart.js?v=636737146140000000'></script>"
                + "<script src='/content/js/form.js?v=636737146140000000'></script>"
                + "<script src='/content/js/import.js?v=636737146140000000'></script>"
                + "<script src='/content/js/layout.js?v=636737146140000000'></script>"
                + "<script src='/content/js/security.js?v=636737146140000000'></script>"
                + "<script src='/content/js/table.js?v=636737146140000000'></script>"
                + "<link rel='stylesheet' type='text/css' href='/content/css/default/form.css?v=636737148958548919' />"
                + "<link rel='stylesheet' type='text/css' href='/content/css/default/layout.css?v=636737145940000000' />"
                + "<link rel='stylesheet' type='text/css' href='/content/css/default/table.css?v=636737145940000000' />";            
            //var content = new VSTContent.ContentSoapClient();
            var js = this.GetSection("JSContent");
            js.Add(new LiteralControl(s));

            //js.Add(new LiteralControl(content.GetJavaScript() + content.GetCSS(null)));
        }

        App.Controller _controller;
        public App.Controller Controller
        {
            get
            {
                if (_controller == null)
                    _controller = this.CreateDefaultController();
                return _controller;
            }
        }
        public virtual App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        public ControlCollection GetSection(string name)
        {
            return this.Master.FindControl(name).Controls;
        }

        Json.PageInfo _info;
        public Json.PageInfo Info
        {
            get
            {
                if (_info == null)
                    _info = new Json.PageInfo();
                return _info;
            }
        }

        protected virtual void LoadSiteMap()
        {
            var level = Engine.User.Level;
            var diagram = Engine.FunctionalContext.Diagram;

            this.Info.Home.Caption = diagram.Root.GetAttribute("menu");
            this.Info.Home.Url = Engine.User.HomeUrl;

            var fhd = this.Info.FHD;
            foreach (var e in diagram.GetFirstLevel(level))
            {
                var category = fhd.CreateCollection();
                category.Name = e.Name;
                category.Caption = e.MenuText;

                var items = (Json.Array)category.Add("items", new Json.Array());

                foreach (var child in e.Childs)
                {
                    if (child.CheckUserMenu(level) == false)
                        continue;

                    var item = items.CreateArray();
                    item.Add(child.MenuText);
                    item.Add(child.FullPath);
                }
            }

            var context = Engine.FunctionalContext;
            if (context.Depth > 2)
            {
                var sub = new Json.Array();
                var dir = context.Parent;
                foreach (var e in dir.Childs)
                {
                    if (e.CheckUserMenu(level))
                    {
                        var link = (Json.Link)sub.Add(new Json.Link());
                        link.Caption = e.MenuText;
                        link.Url = e.Href;
                    }
                }

                if (sub.IsEmpty == false)
                    this.Info.Add("subpages", sub);
            }
        }

        protected virtual AppView CreateView(string name)
        {
            var view = this.CreateViewCore();
            view.LoadTempalte(name);

            return view;
        }

        protected virtual AppView CreateViewCore()
        {
            if (this.Controller.Model is VST.IDataCollection)
                return new App.View.DataView();

            return new App.View.FormView();
        }

        protected override void OnLoad(EventArgs e)
        {
            this.LoadSiteMap();

            var view = this.CreateView(Engine.FunctionalContext.GuiName);
            if (view != null)
            {
                this.Info.MainContent.Add(view.JsonTemplate);
                this.Controller.ProcessView(null, view);

                var context = Engine.FunctionalContext;
                this.CreateHeader(this.Info.MainContent[0] as Json.Paragraph, context.Caption, context.GetString("sub-caption"));
            }

            this.CreateUserInfo();
            this.GetSection("PageInfoContent").Add(new LiteralControl(string.Format("<script>page = {0};</script>", this.Info)));
        }

        protected virtual void CreateHeader(Json.Paragraph paragraph, string caption, string subCaption)
        {
            paragraph.Caption = caption;

            if (!string.IsNullOrEmpty(subCaption))
                paragraph.SubCaption = subCaption;
        }

        protected virtual void CreateUserInfo()
        {
            this.Info.Add("user", Engine.User.ToJson());
        }
    }
}