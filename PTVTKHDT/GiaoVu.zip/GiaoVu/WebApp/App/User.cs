﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml;

namespace App.User
{
    public partial class Entity : App.DataEntity
    {
        public Entity() { }
        public Entity(Service.AccountInfo info)
        {
            this.Row = info.Row;
            this.Level = info.Level;
            
            this.UserName = info.GetString("name");
            this.HomeUrl = "/" + info.GetAttribute("Author.Site");

            if (info.Profile != null)
                this.Description = info.Profile.GetString("FullName");
            else
                this.Description = (string)info.GetAttribute("Author.Desciption");

        }

        public object ProfileId
        {
            get { return this.GetAttribute("User.Id"); }
        }

        public String UserName { get; set; }
        public Int32 Level { get; set; }
        public String Description { get; set; }
        public string HomeUrl { get; set; }
        public string FHD { get; set; }

        public Json.Collection ToJson()
        {
            var map = new Json.Collection();
            map.Name = this.UserName;
            map.Add("level", this.Level);

            return map;
        }
    }
}
