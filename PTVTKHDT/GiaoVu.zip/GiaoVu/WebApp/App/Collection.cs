﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public interface ICollection : VST.ICollection, IModel
    {
        IEntity NewEntity();
        IEntity Find(object key);
    }

    public interface IDataCollection
    {
        VST.Data.DataEngine DataEngine { get; set; }
    }

    public partial class DataCollection<TEntity> : VST.Data.DataCollection<TEntity>, ICollection, IDataCollection
        where TEntity : DataEntity, new()
    {
        public DataCollection()
        {
        }
        public DataCollection(string name)
        {
            this.Table = Global.DataProvider.Select(name);
        }

        protected virtual void SetContextParam(VST.Schema.FHD.Entity context)
        {
            this.DataEngine.And(context.DataFilter);

            if (!string.IsNullOrEmpty(context.DataSort))
                this.DataEngine.Sort = context.DataSort;
        }


        public virtual void UpdateView(AppView view)
        {
            var context = Engine.FunctionalContext;
            this.SetContextParam(context);

            var info = Engine.GetSplitPageInfo(this.DataEngine.Length);
            var items = this.GetPageItems(info);

            view.JsonTemplate.Add("pageSplit", info);

            view.DataSource = this;
            view.DataBind();
        }

        public virtual ICollection GetPageItems(Json.PageSplitInfo info)
        {
            int pageIndex = info.Index - 1;
            int pageSize = info.PageSize;

            int start = pageIndex * pageSize;
            int length = pageSize;

            if (start + length > _engine.Length)
                length = _engine.Length - start;

            this.Clear();
            foreach (var r in this.DataEngine.Offset(start, length))
                this.Add(new TEntity { Row = r });

            return this;
        }

        VST.Data.DataEngine _engine;
        public VST.Data.DataEngine DataEngine
        {
            get
            {
                if (_engine == null)
                    _engine = new VST.Data.DataEngine(this.Table);
                return _engine;
            }
            set
            {
                _engine = value;
            }
        }

        public IEntity NewEntity()
        {
            return new TEntity { Row = Engine.CreateEmptyDataRow(this.Table) };
        }
        public virtual IEntity GetEntityById(object id)
        {
            if (id == null || id == DBNull.Value || id.Equals(string.Empty))
                return NewEntity();

            var e = this.Find(id);
            if (e == null)
                e = NewEntity();
            return e;
        }

        public string Name
        {
            get { return this.Table.TableName; }
        }

        public virtual IEntity Find(object key)
        {
            var r = this.Table.Rows.Find(key);
            if (r == null)
                return null;
            return new TEntity { Row = r };
        }
        public System.Data.DataRow FindFirst(string columnName, object key)
        {
            var col = this.Table.Columns[columnName];
            if (key.GetType() != col.DataType)
                key = Convert.ChangeType(key, col.DataType);

            foreach (System.Data.DataRow r in this.Table.Rows)
                if (r[col].Equals(key))
                    return r;
            return null;
        }

        public TEntity FindFirstEntity(string columnName, object key)
        {
            var row = this.FindFirst(columnName, key);
            return new TEntity { Row = row };
        }

        public virtual List<TEntity> Select(string filter, string sort)
        {
            var dataView = new System.Data.DataView(this.Table, filter, sort, System.Data.DataViewRowState.CurrentRows);

            this.Clear();
            foreach (System.Data.DataRowView dv in dataView)
                this.Add(new TEntity { Row = dv.Row });

            return this;
        }
        public List<TEntity> Select(string filter)
        {
            return this.Select(filter, null);
        }
        public List<TEntity> Select()
        {
            return this.Select(null, null);
        }

        public TEntity InsertEntity(params object[] values)
        {
            var r = this.Table.Rows.Add(values);
            return new TEntity { Row = r };
        }

        public int Delete(string filter)
        {
            var count = this.Select(filter).Count;
            foreach (var e in this)
                e.Delete();

            return count;
        }

        public virtual void UpdateDataBase()
        {
            Global.DataProvider.UpdateDataBase();
        }
        public void RemoveAttribute(string name)
        {
            var col = this.Table.Columns[name];
            if (col != null)
                this.Table.Columns.Remove(col);
        }
    }

    public class DefaultCollection : DataCollection<DataEntity>
    {
        public DefaultCollection() { }
        public DefaultCollection(string name)
            : base(name)
        {
        }

        System.Data.DataRow GetDataRow(object id)
        {
            return this.Table.Rows.Find(id);
        }

        public override void UpdateDataBase()
        {
            foreach (var e in this)
            {
                if (e.IsNew)
                    this.Table.Rows.Add(e.Row);
            }
            base.UpdateDataBase();
        }
    }
}