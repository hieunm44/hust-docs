﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.NetWork
{
    using System.IO;
    using System.Net.NetworkInformation;
    using System.Net.Security;
    using System.Net.Sockets;
    using System.Net;
    using System.Net.Mail;

    public class MailServer
    {
        public string Address { get; set; }
        protected string Password { get; set; }
        public string Host { get; set; }
        public int Port { get; set; }

        public MailServer() { }
        public MailServer(string address, string pass, string host, int port)
        {
            Address = address;
            Password = pass;
            Host = host;
            Port = port;
        }

        public object ReadMail(int index)
        {
            return ReadMail(index, Address, Password);
        }
        public static object ReadMail(int index, string name, string pass)
        {
            try
            {
                // create an instance of TcpClient 
                TcpClient tcpclient = new TcpClient();

                // HOST NAME POP SERVER and gmail uses port number 995 for POP 
                tcpclient.Connect("pop.gmail.com", 995);

                // This is Secure Stream // opened the connection between client and POP Server
                System.Net.Security.SslStream sslstream = new SslStream(tcpclient.GetStream());

                // authenticate as client  
                sslstream.AuthenticateAsClient("pop.gmail.com");

                //bool flag = sslstream.IsAuthenticated;   // check flag

                // Asssigned the writer to stream 

                System.IO.StreamWriter sw = new StreamWriter(sslstream);

                // Assigned reader to stream

                System.IO.StreamReader reader = new StreamReader(sslstream);

                // refer POP rfc command, there very few around 6-9 command

                // sent to server
                sw.WriteLine("USER " + name);
                sw.Flush();

                sw.WriteLine("PASS " + pass);
                sw.Flush();

                // RETR 1 will retrive your first email. it will read content of your first email
                sw.WriteLine("RETR " + index.ToString());

                sw.Flush();
                // close the connection

                sw.WriteLine("Quit ");
                sw.Flush();

                string str = string.Empty;
                string strTemp = string.Empty;
                while ((strTemp = reader.ReadLine()) != null)
                {
                    // find the . character in line
                    if (strTemp == ".")
                    {
                        break;
                    }
                    if (strTemp.IndexOf("-ERR") != -1)
                    {
                        break;
                    }
                    str += strTemp;
                }


                reader.Close();
                sw.Close();

                return str;
            }
            catch (Exception ex)
            {
                return ex;
            }
        }

        public bool SendMail(string to, string subject, string body, bool html)
        {
            SmtpClient smtp = new SmtpClient(Host, Port);

            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential(Address, Password);
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;

            var msg = new MailMessage(Address, to)
            {
                Subject = subject,
                Body = body,
                IsBodyHtml = html,
            };
            smtp.Send(msg);

            return true;
        }

        public static MailServer RegisterGoogleMailServer(string address, string pass)
        {
            return new MailServer(address, pass, "smtp.gmail.com", 587);
        }

        public static MailServer GiaoVu
        {
            get { return RegisterGoogleMailServer("giaovu.dtvt@gmail.com", "2805p4094@mming0908"); }
        }
    }
}
