﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public class TextTemplateEntity : DataEntity
    {
        public string Key { get { return (string)this.ID; } }
        public string Value { get { return this.GetString("Value"); } }
        public string Text { get { return this.GetString("Viet"); } }

        public Json.Collection ToLink()
        {
            var link = new Json.Link();
            link.Caption = this.Text;

            var v = this.Value;
            if (v != string.Empty)
            {
                if (v.EndsWith(")"))
                    link.OnClick = v;
                else
                    link.Url = v;
            }
            return link;
        }
    }

    public class TextTemplate : DataCollection<TextTemplateEntity>
    {
        public TextTemplate()
            : base("TextTemplate")
        {
        }

        public TextTemplateEntity this[string key]
        {
            get
            {
                return (TextTemplateEntity)this.Find(key);
            }
        }

        public static string GetValue(string name)
        {
            var model = new TextTemplate();
            return model[name].Value;
        }
    }
}