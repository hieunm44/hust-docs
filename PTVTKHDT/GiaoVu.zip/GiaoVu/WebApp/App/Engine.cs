﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace App
{
    public interface IEngine
    {
        Engine Engine { get; }
    }


    public partial class Engine
    {
        class PageIndex : Dictionary<VST.Schema.FHD.Entity, string>
        {
            public string Current
            {
                get
                {
                    string v;
                    TryGetValue(Engine.FunctionalContext, out v);
                    return v;
                }
                set
                {
                    var key = Engine.FunctionalContext;
                    if (this.ContainsKey(key))
                        this[key] = value;
                    else
                        this.Add(key, value);
                }
            }
        }

        public static System.Web.SessionState.HttpSessionState Session
        {
            get
            {
                if (HttpContext.Current == null)
                    return null;
                return HttpContext.Current.Session;
            }
        }

        public static System.Web.HttpApplicationState Application { get { return HttpContext.Current.Application; } }

        public static VST.Schema.FHD.Entity FunctionalContext { get; set; }

        public static App.User.Entity User
        {
            get
            {
                if (HttpContext.Current == null)
                    return null;

                return (App.User.Entity)Session["user"];
            }
            set { Session["user"] = value; }
        }

        public static App.Page Page { get; set; }
        public static void Start(App.Page page)
        {
            Engine.Page = page;

            var user = Engine.User;
            //if (user.Level == 0)
            //{
            //    string url = user.LoadCookie();
            //    if (url != null)
            //        page.Response.Redirect(url);
            //}

            var ctx = FunctionalContext;
            if (ctx.MinLevel > user.MaxLevel || ctx.MaxLevel < user.MinLevel)
            {
                page.Response.Redirect("/account/login?request=" + ctx.Href);
            }

            var controller = page.Controller;
            var postBack = new PostBackCommand(page.Request);

            switch (postBack.ActionIndex)
            {
                case ActionIndex.Cancel: Engine.Finish(null); return;
                case ActionIndex.Search:
                    if (string.IsNullOrEmpty(postBack.CommandValue))
                    {
                        Engine.Finish(null);
                        return;
                    }
                    break;
                case ActionIndex.Href:
                    var href = postBack.CommandValue;
                    if (href == "home")
                        href = User.HomeUrl;
                    Engine.Finish(href);
                    return;
            }

            controller.Command = postBack;
            controller.ProcessRequest(postBack);
        }

        public static void Finish(string url)
        {
            if (url == null)
            {
                url = FunctionalContext.Href;
                var p = GetCurrentPageIndex();
                if (p != null)
                    url += "?page=" + p;
            }
            Page.Response.Redirect(url);
        }

        public static void Exit()
        {
        }

        public static VST.Data.SearchEngine GetSearchEngine(PostBackCommand command)
        {
            var data = Page.Controller.Collection as VST.IDataCollection;
            string key = "search" + ((IModel)data).Name;
            VST.Data.SearchEngine se = null;

            if (command["page"] != null)
                se = Session[key] as VST.Data.SearchEngine;
            if (se == null || se.Value != command.CommandValue)
                Session[key] = se = new VST.Data.SearchEngine(data.Table, FunctionalContext.Search, command.CommandValue);

            ((IDataCollection)data).DataEngine = se;
            return se;
        }

        public static DataRow CreateEmptyDataRow(DataTable table)
        {
            return table.NewRow();
            //if (_emptyDataMap == null)
            //    _emptyDataMap = new Dictionary<DataTable, DataRow>();

            //DataRow row;
            //if (_emptyDataMap.TryGetValue(table, out row) == false)
            //{
            //    _emptyDataMap.Add(table, row = table.NewRow());
            //    return row;
            //}

            //if (row.RowState != DataRowState.Detached ||
            //    row.RowState == DataRowState.Deleted)
            //    _emptyDataMap[table] = row = table.NewRow();
            //return row;
        }

        public static string GetCurrentPageIndex()
        {
            var p = Session["page-index-manager"] as PageIndex;
            if (p == null)
                return null;
            return p.Current;
        }
        public static Json.PageSplitInfo GetSplitPageInfo(int total)
        {
            var info = new Json.PageSplitInfo();
            var index = Page.Request["page"];
            if (index != null)
            {
                var p = Session["page-index-manager"] as PageIndex;
                if (p == null)
                    Session["page-index-manager"] = p = new PageIndex();
                p.Current = index;
            }
            else
            {
                index = "1";
            }
            var pageSize = Engine.FunctionalContext.PageSize;
            if (pageSize == -1)
                pageSize = 10;
            else if (pageSize == 0)
                pageSize = total;

            info.Index = int.Parse(index);
            info.PageSize = pageSize;
            info.Total = total;

            return info;
        }

        public static StringList CreateFieldCollection(string src)
        {
            var lst = new StringList(",");

            foreach (string item in src.Split(','))
            {
                string v = item.Trim();
                int i = v.IndexOf('.');
                if (i < 0 || v[i + 1] != '*')
                {
                    lst.Add(v);
                    continue;
                }

                string name = v.Substring(0, i);
                var model = Global.DataProvider.Tables[name];
                foreach (DataColumn col in model.Columns)
                    lst.Add(name + '.' + col.ColumnName);
            }

            return lst;
        }
    }

    public class KeepAlive : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}