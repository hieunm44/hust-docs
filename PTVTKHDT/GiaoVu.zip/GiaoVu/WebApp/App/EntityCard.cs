﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.EntityCard
{
    public abstract class Controller : App.Controller
    {
        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Open)
            {
                var model = new DefaultCollection(command.GetString("model"));
                Engine.Session[model.Name] = model.Find(command.CommandValue);
                Engine.Finish(null);

                return;
            }
        }
    }

    public class Page : App.Page
    {
    }
}