﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App
{
    public partial class DataEntity : VST.Data.DataEntity, IEntity
    {
        public virtual void UpdateView(AppView view)
        {
            view.DataSource = this;
            view.DataBind();
        }


        public bool IsNew
        {
            get
            {
                return this.Row == null
                    || this.Row.RowState == System.Data.DataRowState.Detached;
            }
        }

        public virtual bool HasData
        {
            get
            {
                return this.Row != null && this.Row.RowState != System.Data.DataRowState.Deleted;
            }
        }

        public virtual object ID { get { if (this.Row == null) return null; return this.Row[0]; } }

        public string Name { get { return this.Row.Table.TableName; } }

        protected virtual void BeginExecute(PostBackCommand command) { }
        public virtual void Execute(PostBackCommand command)
        {
            this.BeginExecute(command);
            foreach (var p in command)
            {
                this.SetAttribute(p.Key, p.Value);
            }
            this.EndExecute(command);
        }
        protected virtual void EndExecute(PostBackCommand command)
        {
            if (this.IsNew)
            {
                this.Row.Table.Rows.Add(this.Row);
                command.OutputValue = this.ID;
            }
        }

        public object[] Values
        {
            get { return this.Row.ItemArray; }
        }

    }
}

namespace App
{
    public class XmlEntity : VST.Base.XmlEntity
    {
    }
}