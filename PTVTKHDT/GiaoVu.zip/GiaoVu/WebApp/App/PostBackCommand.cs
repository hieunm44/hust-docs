﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace App
{
    public enum ActionIndex
    {
        Delete = -1,
        Update,
        Insert,
        Add,
        Open,
        Edit,
        Submit,
        Cancel,
        Error,
        PostData,
        Accept,
        Search,
        Result,
        Download,
        Folder,
        Refresh,
        Href,
        Send,

        None,
    }
    public class Action
    {
        public const string Accept = "accept";
        public const string Submit = "submit";
        public const string Add = "add";
        public const string Delete = "delete";
        public const string Download = "download";
        public const string Search = "search";
        public const string Open = "open";
        public const string Cancel = "cancel";
        public const string Insert = "insert";
        public const string Update = "update";
        public const string Primary = "primary-key";
        public const string Result = "result";
        public const string Page = "page";
        public const string Error = "error";
        public const string Query = "query";
        public const string Href = "href";
        public const string Edit = "edit";
        public const string Export = "export";
        public const string PostData = "__post";
        public const string Send = "send";

        Dictionary<string, ActionIndex> _map;
        public Action()
        {
            _map = new Dictionary<string, ActionIndex>();
            for (ActionIndex i = ActionIndex.Delete; i < ActionIndex.None; i++)
            {
                _map.Add(i.ToString().ToLower(), i);
            }
        }

        public ActionIndex Find(string name)
        {
            ActionIndex i;
            if (_map.TryGetValue(name, out i))
                return i;
            return ActionIndex.None;
        }
    }

    public class ValueCollection : Dictionary<string, object>
    {
        public ValueCollection() { }
        public ValueCollection(string value)
        {
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (c != ' ')
                {
                    int j = i + 1;
                    while (j < value.Length && value[j] != '=')
                        j++;

                    for (int k = j + 2; k < value.Length; k++)
                    {
                        if (value[k] == '\'')
                        {
                            string name = value.Substring(i, j - i);
                            string v = value.Substring(j + 2, k - j - 2);
                            base.Add(name, v);
                            i = k + 1;
                            break;
                        }
                    }
                }
            }
        }

        new public object this[string name]
        {
            get
            {
                object v = null;
                TryGetValue(name, out v);
                return v;
            }
            set
            {
                if (this.ContainsKey(name))
                    base[name] = value;
                else
                    base.Add(name, value);
            }
        }
        new void Remove(string key)
        {
            if (this.ContainsKey(key))
                base.Remove(key);
        }
        public void WriteTo(XmlDocument document)
        {
            var root = document.DocumentElement;
            foreach (var p in this)
            {
                var node = document.CreateElement(p.Key);
                if (p.Value != null)
                    node.InnerText = p.Value.ToString();
                root.AppendChild(node);
            }
        }
        public override string ToString()
        {
            string s = string.Empty;
            foreach (var p in this)
            {
                s += string.Format(" {0}='{1}'", p.Key, p.Value);
            }
            return s;
        }
    }
    public class QueryString : ValueCollection
    {
        public QueryString() { }
        public QueryString(string value)
        {
            var s = value.Split('&');
            foreach (string v in s)
            {
                int i = v.IndexOf('=');
                if (i < v.Length - 1)
                    this.Add(v.Substring(0, i), v.Substring(i + 1));
            }
        }

        public override string ToString()
        {
            string v = "";
            foreach (var p in this)
            {
                if (v.Length != 0)
                    v += '&';
                v += string.Format("{0}={1}", p.Key, p.Value);
            }
            return v;
        }
    }
    public partial class PostBackCommand : ValueCollection
    {
        static Action _action;

        public string CommandName { get; set; }
        public string CommandValue { get; set; }

        public ActionIndex ActionIndex
        {
            get;
            set;
        }

        public HttpRequest Request
        {
            get;
            private set;
        }
        public PostBackCommand() { }
        public PostBackCommand(HttpRequest request)
        {
            if (_action == null)
                _action = new Action();

            this.Request = request;
            var query = request.QueryString;

            this.ActionIndex = App.ActionIndex.None;

            if (query != null && query.Count > 0)
            {
                foreach (string name in query.Keys)
                {
                    string v = query[name];
                    if (this.CommandName == null && (this.ActionIndex = _action.Find(name)) != ActionIndex.None)
                    {
                        this.CommandName = name;
                        this.CommandValue = v;
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(v))
                            this.Add(name, v);
                    }
                }
            }
        }
        public PostBackCommand(XmlNode node)
        {
            foreach (XmlAttribute a in node.Attributes)
            {
                string v = a.Value;
                if (string.IsNullOrWhiteSpace(v))
                    continue;

                this.Add(a.Name, v);
            }
        }

        public string[] Split(string value)
        {
            int vLen = value.Length - 1;
            var lst = new List<string>();
            if (vLen > 1 && value[0] == '{' && value[vLen] == '}')
            {
                int start = 1, i = 1;
                while (i <= vLen)
                {
                    char c = value[i++];
                    if (c == '|' || c == '}')
                    {
                        int len = i - start - 1;
                        if (len > 0)
                            lst.Add(value.Substring(start, len));
                        start = i;
                    }
                }
            }
            return lst.ToArray();
        }

        public object Exception
        {
            get { return this["-Exception"]; }
            set { this["-Exception"] = value; }
        }

        public override string ToString()
        {
            string s = string.Empty;
            foreach (var pair in this)
            {
                s += string.Format(" {0}='{1}'", pair.Key, pair.Value);
            }
            return s;
        }
        public string ToString(string format, params string[] param)
        {
            if (param.Length == 0) return format;

            var v = new object[param.Length];
            for (int i = 0; i < param.Length; i++)
                v[i] = this[param[i]];
            return string.Format(format, v);
        }

        public string GetString(string name)
        {
            var v = base[name];
            if (v != null && !(v is string))
                return v.ToString();
            return (string)v;
        }
        public int GetInt(string name)
        {
            var v = base[name];
            if (v == null)
                return 0;

            if (v is string)
                return int.Parse((string)v);
            return (int)v;
        }

        string[] _itemKeys;
        public string[] ItemKeys
        {
            get
            {
                if (_itemKeys == null)
                    _itemKeys = this.Split(this.CommandValue);
                return _itemKeys;
            }
        }
        public string[] GetItemKeys()
        {
            if (this.ItemKeys.Length > 0)
                return ItemKeys;
            return new string[] { CommandValue };
        }

        public object OutputValue { get; set; }

        public bool Handled { get; set; }

        public void RemoveKeys(params string[] keys)
        {
            foreach (string name in keys)
                this.Remove(name);
        }
        public void AddKeys(params string[] keys)
        {
            foreach (string name in keys)
                this.Add(name, null);
        }
        public void ConvertNumberValues(params string[] fields)
        {
            foreach (string key in fields)
            {
                object v = null;
                if (this.TryGetValue(key, out v) == false || !(v is string))
                    continue;

                long a = 0, f = 0;
                foreach (char c in (string)v)
                {
                    if (c == ',') continue;
                    if (c == '.') { f = 1; continue; }

                    a = (a << 1) + (a << 3) + (c & 15);
                    if (f != 0) f = (f << 1) + (f << 3);

                }

                this[key] = (f > 1) ? (double)a / f : a;
            }
        }
        public void ConvertDateValues(params string[] fields)
        {
            if (fields.Length == 0)
            {
                var lst = new List<string>();
                foreach (var p in this)
                {
                    if (p.Key.ToLower().Contains("ngay"))
                        lst.Add(p.Key);
                }
                fields = lst.ToArray();
            }
            foreach (string key in fields)
            {
                string v = (string)this.GetString(key);
                if (string.IsNullOrEmpty(v) == false)
                    this[key] = VST.Viet.Date.Convert(v);
            }
        }
        public PostBackCommand GetFormData()
        {
            var frm = this.Request.Form;
            foreach (var k in frm.AllKeys)
            {
                string v = frm[k];

                if (v == "null")
                {
                    this.Add(k, DBNull.Value);
                    continue;
                }
                if (v.IndexOf("ESC:") == 0)
                    v = Project.Convert.Descape(v.Substring(4));
                this.Add(k, v);
            }
            return this;
        }


        public bool Is(string name) { return this.CommandName == name; }
        public void SendRequest(bool handled)
        {
            this.Handled = handled;
            this.CommandName = Action.Href;
            this.CommandValue = null;

            HttpContext.Current.Response.Redirect(this.Request.CurrentExecutionFilePath);
        }
        public void SendRequest(string url)
        {
            //if (url == null)
            //    url = this.Request.CurrentExecutionFilePath;

            //if (url[0] != '/')
            //{
            //    var path = this.Request.Path;
            //    path = path.Substring(0, path.LastIndexOf('/') + 1);
            //    url = path + url;
            //}

            //this.CommandName = Action.Href;
            //this.CommandValue = url + "/";

            //this.Handled = false;
            //Engine.PostBack = this;

            //HttpContext.Current.Response.Redirect("/");
        }
    }
}