﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace App.Api
{
    public class CustomerController : ApiController
    {
        public string Login(string name, string pass)
        {
            var service = new Service.Account();
            return service.Login(name, pass);
        }
    }
}