using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.account.profile.mat_khau
{
    public partial class Entity : App.DataEntity
    {
        public Entity()
        {
        }
        public override object GetAttribute(string name)
        {
            return string.Empty;
        }

        public string State;

        public override object ID
        {
            get
            {
                return 0;
            }
        }

        public override void UpdateView(AppView view)
        {
            if (this.State != null)
                view.JsonTemplate.Add("error", 1);
            base.UpdateView(view);
        }
    }
    public partial class DataCollection : DataCollection<Entity>
    {
    }
    public partial class Controller : App.Controller
    {
        //protected override IModel LoadCollection(string name)
        //{
        //    return new DefaultCollection("user");
        //}
        //protected override ICollection CreateDefaultCollection()
        //{
        //    return new DataCollection();
        //}

        public override void ProcessRequest(PostBackCommand command)
        {
            var e = new Entity();
            if (command.ActionIndex == ActionIndex.Update)
            {
                var api = new Service.Account();
                e.State = api.ChangePassword(Engine.User.UserName, command.GetString("OldPass"), command.GetString("Pass"));

                if (e.State == NameManager.OK)
                    Engine.Finish(Engine.User.HomeUrl);
            }
            this.Model = e;
        }
    }

    public partial class Default : App.Page
    {
        protected override AppView CreateViewCore()
        {
            return new App.View.FormView();
        }
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}