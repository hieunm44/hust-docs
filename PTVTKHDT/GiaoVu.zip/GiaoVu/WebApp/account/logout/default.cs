using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.account.logout
{
    public partial class Entity : App.DataEntity
    {
    }
    public partial class DataCollection : DataCollection<Entity>
    {
    }
    public partial class Controller : App.Controller
    {
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            new Project.CookieWriter().Remove(NameManager.User);
            Engine.Session.Abandon();

            Engine.User = new User.Entity();
            Engine.Finish("/");
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}