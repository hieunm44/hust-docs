﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.account.login
{
    public partial class Entity : DataEntity
    {
        User.Entity _info;
        public Entity()
        {
        }
        public Entity(User.Entity info)
        {
            _info = info;
        }

        public override void UpdateView(AppView view)
        {
            if (_info != null)
            {
                var error = view.JsonTemplate.CreateCollection("loginError");
                error.Add("type", _info.UserName == null ? "Name" : "Pass");
            }
            base.UpdateView(view);
        }
    }

    public partial class Controller : App.Controller
    {
        public override void ProcessView(string name, AppView container)
        {
            if (this.Model != null)
                this.Model.UpdateView(container);
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            var e = new Entity();
            if (command.ActionIndex == ActionIndex.Update)
            {
                string name = command.GetString("Name");
                string pass = command.GetString("Pass");

                //var info = new Service.AccountInfo(name, pass);
                var user = Service.Account.Core.Login(name, pass);
                if (user.Description != null)
                {
                    if (command.GetInt("Check") != 0)
                    {
                        string s = string.Format("name='{0}' pass='{1}'", name, pass);
                        new Project.CookieWriter().Write("user", s, 3);
                    }

                    user.UserName = name;
                    Engine.Session[NameManager.User] = user;
                    Engine.Finish(user.HomeUrl);
                }
                else
                {
                    e = new Entity(user);
                }
            }

            this.Model = e;

        }
    }

    public partial class Default : App.Page
    {
        protected override void OnInit(EventArgs e)
        {
            Engine.Page = this;
            this.Controller.ProcessRequest(new PostBackCommand(this.Request));

            this.LoadServiceContent();
        }

        protected override void LoadSiteMap()
        {

        }

        protected override App.AppView CreateViewCore()
        {
            return new App.View.FormView();
        }

        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }


        protected override void CreateUserInfo()
        {
            //base.CreateUserInfo();
        }

    }
}