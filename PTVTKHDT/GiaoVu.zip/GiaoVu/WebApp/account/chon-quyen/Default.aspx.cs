﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.account.chon_quyen
{
    public class Entity : DataEntity
    {
        public override void Execute(PostBackCommand command)
        {
            Engine.User.Level = (int)this.ID;
            Engine.Finish(Engine.User.HomeUrl = "/" + this.GetString("Site"));
        }
    }
    public class DataCollection : App.DataCollection<Entity>
    {
        public override void UpdateView(AppView view)
        {
            this.Select("Id <= " + Engine.User.GetString("AuthorId") + " and Id > " + Author.SinhVien, "Id desc");
            view.DataSource = this;
            view.DataBind();
        }
    }
    public class Controller : App.Controller
    {
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}