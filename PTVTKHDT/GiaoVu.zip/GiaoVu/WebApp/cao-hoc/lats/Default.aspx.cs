﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.cao_hoc.lats
{
    public class Controller : App.DuLieu.Controller
    {

    }

    public partial class Default : App.DuLieu.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}