using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.giang_vien.phan_cap
{
    public partial class Entity : App.DataEntity
    {
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {

    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }

        public override void ProcessView(string name, AppView container)
        {
            base.ProcessView(name, container);
            var pcgd = new DefaultCollection("PhanCapGD");
            var pc = container.JsonTemplate.CreateArray("pcgd");
            foreach (var e in pcgd.Select())
            {
                var item = pc.CreateArray();
                item.Add(e.ID);
                item.Add(e.GetString("Ten"));
            }
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}