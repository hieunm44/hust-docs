﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.giao_vu.du_lieu.cbgd
{
    class IEngine : App.DuLieu.ImportEngine
    {
        protected DefaultCollection HocPhan = new DefaultCollection("HocPhan");
        Dictionary<string, object> _canBo;

        string GetKey(object value)
        {
            char[] v = VST.Viet.Text.GetLatinhCharacterOnly((string)value).ToCharArray();
            int i = 0;
            foreach (char c in v)
                if (c >= 'a' && c <= 'z')
                    v[i++] = c;
            return new string(v, 0, i);

        }

        public IEngine()
        {
            var map = new Dictionary<string, object>();
            foreach (var e in new DefaultCollection("CanBo").Select())
            {
                var ten = this.GetKey(e.GetAttribute("HoTen"));
                if (map.ContainsKey(ten) == false)
                    map.Add(ten, e.ID);
            }
            _canBo = map;
        }

        List<object> _cacCanBo;
        protected override void CheckAllParent()
        {
            string maHP = this.GetValue("MaHP");
            if (string.IsNullOrWhiteSpace(maHP))
            {
                this.State = DuLieu.ImportState.DoNotWrite;
                return;
            }


            this.CheckParent(HocPhan, "MaHP");

            var hoten = this.GetValue("HoTen");
            var lst = new List<string>();
            if (hoten != string.Empty)
                lst.Add(hoten);

            var maybe = this.GetValue("MayBe");
            if (maybe != string.Empty)
                lst.AddRange(maybe.Split(','));

            _cacCanBo = new List<object>();
            foreach (var s in lst)
            {
                object id = null;
                var key = GetKey(s);
                if (_canBo.TryGetValue(key, out id))
                    _cacCanBo.Add(id);
            }

            foreach (var id in _cacCanBo)
                _entity.Row.Table.Rows.Add(id, maHP);


            this.State = DuLieu.ImportState.DoNotWrite;
        }

        protected override void WriteCore(string name, string value)
        {
            switch (name)
            {
                case "HoTen":
                    _entity.SetAttribute("GiangVienId", _canBo[GetKey(value)]);
                    return;

                case "MayBe":
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        foreach (var ten in value.Split(','))
                        {
                            var key = GetKey(ten);
                            if (_canBo.ContainsKey(key))
                            {
                                _entity.Row.Table.Rows.Add(null, _canBo[key], GetValue("MaHP"));
                            }
                        }
                    }
                    return;
            }
            base.WriteCore(name, value);
        }
    }

    public class Entity : DataEntity
    {
        public override void UpdateView(AppView view)
        {
            base.UpdateView(view);
            var canbo = new DefaultCollection("CanBo");
            var giangDay = new DefaultCollection("CBGD");
            var data = view.JsonTemplate.CreateArray("canbo");

            foreach (var e in canbo.Select())
            {
                var item = data.CreateArray();
                item.Add(e.ID);

                var hoten = e.GetString("HoTen");
                int i = VST.Viet.Text.FindNamePos(hoten);
                item.Add(hoten.Substring(i) + ' ' + hoten.Substring(0, i - 1));
            }

            var gv = view.JsonTemplate.CreateArray("giangDay");
            foreach (var e in giangDay.Select("MaHP='" + this.ID + "'"))
            {
                gv.Add(e.GetInt("GiangVienId"));
            }
        }

        public override void Execute(PostBackCommand command)
        {
            var giangDay = new DefaultCollection("CBGD");
            giangDay.Delete("MaHP='" + this.ID + "'");

            foreach (var canBoId in command.Split(command.GetString("values")))
            {
                giangDay.Insert(canBoId, this.ID);
            }
        }
    }
    public class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection() : base("HocPhan") 
        {
        }

        public override void UpdateView(AppView view)
        {
            Global.DataProvider.Select("CBGD");
            var col = this.Table.Columns.Add("SoLuong", typeof(int), "count(child(HocPhan_CBGD).GiangVienId)");
            base.UpdateView(view);

            this.Table.Columns.Remove(col);
        }
    }
    public class Controller : App.DuLieu.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        protected override void BeginImport(string data, DuLieu.ImportEngine engine)
        {
            var model = new App.DuLieu.Collection("CBGD");
            this.Collection = model;
            base.BeginImport(data, new IEngine());

            model.Table.AcceptChanges();

            var table = model.DataEngine.ToTable(true, "GiangVienId", "MaHP");
            var col = model.Table.Columns[0];
            col.AutoIncrement = false;

            model.Table.Clear();

            foreach (System.Data.DataRow r in table.Rows)
            {
                model.Table.Rows.Add(r[0], r[1]);
            }

            col.AutoIncrement = true;
        }

        public override void ProcessDelete(PostBackCommand command)
        {
            var model = new DefaultCollection("CBGD");
            if (!string.IsNullOrEmpty(command.CommandValue))
            {
                foreach (var key in command.ItemKeys)
                model.Delete("MaHP='" + key + "'");
            }
            else
                model.Delete(null);
            Engine.Finish(null);
        }
    }


    public partial class Default : App.DuLieu.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

    }
}