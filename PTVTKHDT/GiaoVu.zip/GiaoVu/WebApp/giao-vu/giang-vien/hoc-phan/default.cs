using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.giang_vien.hoc_phan
{
    class IEngine : App.DuLieu.ImportEngine
    {
        protected DefaultCollection HocPhan = new DefaultCollection("HocPhan");
        protected override void CheckAllParent()
        {
            base.CheckParent(HocPhan, "MaHP");
        }

        //protected override void WriteCore(string name, string value)
        //{
        //    if (name == "HocPhan.KhoiLuong")
        //    {
        //        var i = value.IndexOf('(');
        //        if (i > 0)
        //        {
        //            _entity.SetAttribute("HocPhan.SoTC", value.Substring(0, i));
        //            _entity.SetAttribute("HocPhan.CTKL", value.Substring(i + 1, value.Length - i - 2));
        //        }
        //        return;
        //    }
        //    base.WriteCore(name, value);
        //}
    }
    public partial class Controller : App.DuLieu.Controller
    {
        protected override void BeginImport(string data, DuLieu.ImportEngine engine)
        {
            base.BeginImport(data, new IEngine());
        }
    }

    public partial class Default : App.DuLieu.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}