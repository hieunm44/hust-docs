﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.giao_vu.hoc_ky.phan_cong.giang_vien
{
    public class Entity : DataEntity
    {
        public override object GetAttribute(string name)
        {
            return base.GetAttribute(name);
        }
    }
    public class DataCollection : App.DataCollection<Entity>
    {
    }
    public class Controller : App.Controller
    {
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}