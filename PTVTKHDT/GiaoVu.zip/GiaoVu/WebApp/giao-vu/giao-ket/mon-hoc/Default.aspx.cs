﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.giao_vu.giao_ket.mon_hoc
{
    public class Entity : DataEntity
    {
        public Single SoGio { get; set; }
        
        StringList _hp;
        public StringList HocPhan
        {
            get
            {
                if (_hp == null)
                    _hp = new StringList(", ");
                return _hp;
            }
        }

        public override object GetAttribute(string name)
        {
            if (name == "SoGio")
                return SoGio;

            if (name == "HP")
                return _hp.ToString();

            return base.GetAttribute(name);
        }
    }
    public class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection() : base("PhanCapCBGD")
        {
        }

        public void LoadMaHP(object maHP)
        {
            var cbgd = new App.DataCollection<Entity>("CBGD");
            var map = new Dictionary<object, Entity>();
            foreach (var e in cbgd.Select("MaHP='" + maHP + "'"))
            {
                var key = e.GetAttribute("GiangVienId");
                map.Add(key, (Entity)this.Find(key));
            }
            var giaoKet = new DefaultCollection("GiangVienGiaoKet");
            foreach (var e in giaoKet.Select())
            {
                var key = e.GetAttribute("GiangVienId");
                Entity g;
                if (map.TryGetValue(key, out g))
                {
                    g.SoGio += e.GetSingleValue("TongQD");
                    g.HocPhan.Add(e.GetString("MaHP"));
                }
            }

            foreach (var e in map.Values)
                this.Add(e);
        }

        public override void UpdateView(AppView view)
        {
            view.DataSource = this;
            view.DataBind();
        }
    }
    public class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            var hp = command["filter"];
            if (hp != null)
            {
                var data = new DataCollection();
                data.LoadMaHP(hp);

                this.Model = data;
                return;
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        protected override AppView CreateViewCore()
        {
            if (this.Controller.Model is DataCollection)
                return new View.TableView();
            return base.CreateViewCore();
        }
    }
}