using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.giao_ket.chi_tiet
{
    class Entity : Export.Entity
    {
        public override object GetAttribute(string name)
        {
            if (name == "BoMon.Ten")
            {
                return new DefaultCollection("BoMon").Find(this.GetAttribute("CanBo.MaBM")).GetAttribute("Ten");
            }
            return base.GetAttribute(name);
        }
    }

    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new App.Project.GiaoKet.DataCollection();
        }

        protected override void ProcessDownload(string attach, string fileName)
        {
            var engine = new Export.TableEngine(this.Command)
            {
                TemplateFileName = "gvgk",
                ServerFileName = "temp",
                AttachName = "giao-ket"
            };
            
            var lst = new Export.EntityList();
            foreach (var e in ((App.Project.GiaoKet.DataCollection)this.Collection).Select())
                lst.Add(new Entity { Row = e.Row });

            if (lst.Count > 0)
            {
                var v = lst.ToArray();
                var e = v[0];
                e.Content = v;

                engine.Run(new Export.Entity[] { e });
                engine.StartDownload();
            }
            //base.ProcessDownload(attach, fileName);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}