using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.giao_ket.du_lieu
{
    class IEngine : App.DuLieu.ImportEngine
    {
        protected DefaultCollection HocPhan = new DefaultCollection("HocPhan");
        protected override void CheckAllParent()
        {
            var id = _values[this["MaHP"]];
            if (id == string.Empty || HocPhan.Find(id) == null)
                this.State = DuLieu.ImportState.DoNotWrite;
        }
    }
    public partial class Controller : App.DuLieu.Controller
    {
        protected override void BeginImport(string data, DuLieu.ImportEngine engine)
        {
            base.BeginImport(data, new IEngine());
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Update)
            {
                if (command.CommandValue == "calc")
                {
                    if (command.GetString("TichLuy") == "1")
                    {
                        var model = new DefaultCollection("PhanCapCBGD");
                        foreach (var e in model.Select())
                            e.SetAttribute("TichLuy", 0);
                    }
                    new Project.GiaoKet.DataCollection().Calculate(command.GetString("Nguon"));
                    this.UpdateDataBase("../chi-tiet");
                }
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.DuLieu.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}