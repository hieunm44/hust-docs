using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.giao_ket.thong_ke
{
    using Project.GiaoKet;

    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new TongHopCollection();
        }
        public override void ProcessRequest(PostBackCommand command)
        {
            var hk = command.GetString("HK");
            if (!string.IsNullOrEmpty(hk))
                TongHopCollection.HocKy = int.Parse(hk);

            var bm = command.GetString("BM");
            if (!string.IsNullOrEmpty(bm))
            {
                if (bm == NameManager.DTVT)
                    bm = null;
                TongHopCollection.BoMon = bm;
            }
            
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}