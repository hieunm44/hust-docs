using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.dau_ky.tong_hop.loai_lop
{
    public partial class Entity : App.DataEntity
    {
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        public override void UpdateView(AppView view)
        {
            var colQD = this.Table.Columns.Add("QuyDoi", typeof(int), "sum(child(LoaiLop_KLGD).QuyDoi)");
            var colTC = this.Table.Columns.Add("SoTC", typeof(int), "sum(child(LoaiLop_KLGD).SoTC)");
            base.UpdateView(view);

            this.Table.Columns.Remove(colQD);
            this.Table.Columns.Remove(colTC);
        }

        protected override void SetContextParam(VST.Schema.FHD.Entity context)
        {
            this.DataEngine.And("(not QuyDoi is null) or (not SoTC is null)");
        }
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        protected override AppView CreateViewCore()
        {
            return new App.View.TableView();
        }
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}