using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.dau_ky.tong_hop.hoc_phan
{
    public partial class DataCollection : App.TKB.DataCollection
    {
        //public override void UpdateView(AppView view)
        //{
        //    var map = this.LoadHocPhan();
        //    map.TinhKhoiLuong();

        //    view.DataSource = map.Values;
        //    view.DataBind();
        //}
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        protected override AppView CreateViewCore()
        {
            return new View.TableView();
        }
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}