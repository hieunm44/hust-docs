using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.dau_ky.tong_hop.phan_cap
{
    public partial class Entity : App.DataEntity
    {
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        public override void UpdateView(AppView view)
        {
            Global.DataProvider.Select("PhanCapCBGD");
            //var colQD = this.Table.Columns.Add("QuyDoi", typeof(Single), "sum(child(PhanCapGD_KLGD).QuyDoi)");
            var colGV = this.CreateAttribute("SoGV", typeof(int), "count(child(PhanCapCBGD).GiangVienId)");

            base.UpdateView(view);


            //this.Table.Columns.Remove(colQD);
            this.Table.Columns.Remove(colGV);
        }

        //protected override void SetContextParam(VST.Schema.FHD.Entity context)
        //{
        //    this.DataEngine.And("(not QuyDoi is null) or (not SoTC is null)");
        //}
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        protected override AppView CreateViewCore()
        {
            return new App.View.TableView();
        }
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}