using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.hoc_ky.tkb.da_phan_cong
{
    using PhanCongGiangDay;

    class Entity : Export.Entity
    {
    }

    public class DataCollection : App.DataCollection<TKBEntity>
    {
        public DataCollection() : base("TKB") { }
        public void CheckTrung()
        {
            var lst = new List<TKB.Entity>();
            object cb = null;
            foreach (var e in this.Select("not GiangVienId is null", "GiangVienId"))
            {
                var c = e.GetAttribute("GiangVienId");
                e.SetAttribute("Trung", null);

                if ((int)e.GetAttribute("LoaiLop.PhanCapGD") < 30)
                    continue;

                if (c.Equals(cb) == false)
                {
                    if (cb != null)
                    {
                        var arr = lst.ToArray();
                        for (int i = 0; i < arr.Length - 1; i++)
                            for (int j = i + 1; j < arr.Length; j++)
                                arr[i].CheckTrung(arr[j]);

                        lst.Clear();
                    }
                    cb = c;
                }
                var t = new TKB.Entity(e);
                lst.Add(t);
            }
            this.DataEngine.And("Trung='1'");
            this.DataEngine.Sort = "GiangVienId";
        }
    }

    public partial class Controller : TKBController
    {

        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            base.ProcessRequest(command);

            if (command["check"] != null)
            {
                var model = (DataCollection)this.Collection;
                model.CheckTrung();
            }
        }

        protected override void ProcessDownload(string attach, string fileName)
        {
            var engine = new Export.TableEngine(this.Command)
            {
                AttachName = "TKB",
                ServerFileName = "temp",
                TemplateFileName = "TKB"
            };

            var data = new Entity();
            var model = new App.DataCollection<Entity>("TKB");
            model.Select("not GiangVienId is null");
            data.Content = model.ToArray();

            engine.Run(new Entity[] { data });
            engine.StartDownload();

            App.Engine.Finish(null);
        }
    }

    public partial class Default : TKBPage
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}