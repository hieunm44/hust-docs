using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.PhanCongGiangDay
{
    //partial class GiangVien
    //{
    //    int soLop;
    //    string hp;

    //    public void UpdateData()
    //    {
    //        this.SetAttribute("HP", hp);
    //        this.SetAttribute("SoLop", soLop);
    //        this.SetAttribute("SoGio", SoGio);
    //    }

    //    public override object GetAttribute(string name)
    //    {
    //        switch (name)
    //        {
    //            case "HP":
    //                hp = "";
    //                foreach (var p in HocPhan)
    //                {
    //                    if (soLop > 0)
    //                        hp += ", ";
    //                    hp += p.Key;
    //                    soLop += p.Value;
    //                }
    //                return hp;

    //            case "SoGio": return SoGio;
    //            case "SoLop": return soLop;
    //        }
    //        return base.GetAttribute(name);
    //    }
    //}

    //partial class GiangVienCollection
    //{
    //    public override void UpdateDataBase()
    //    {
    //        if (_map != null)
    //        {
    //            this.UpdateHocPhan();
    //        }
    //        base.UpdateDataBase();
    //    }
    //    public override void UpdateView(AppView view)
    //    {
    //        if (_map != null)
    //        {
    //            var q = new GiangVienQueue();
    //            foreach (var e in _map.Values)
    //            {
    //                if (e.SoGio > 0.1)
    //                    q.Enqueue(e);
    //            }
    //            view.DataSource = q.Sort();
    //            view.DataBind();
    //        }
    //        else
    //        {
    //            base.UpdateView(view);
    //        }
    //    }
    //}
}

namespace App.giao_vu.hoc_ky.tkb.phan_cong_so_bo
{
    using App.Project.GiaoKet;
    class IEngine : lop.IEngine
    {
        protected DefaultCollection Lop = new DefaultCollection("Lop");

        protected override void CheckAllParent()
        {
            base.CheckParent(Lop, "MaLop");
            base.CheckParent(HocPhan, "Lop.MaHP");
        }

    }

    class Entity : DataEntity
    {
        object _maBM;
        public object MaBM
        {
            get
            {
                if (_maBM == null) _maBM = base.GetAttribute("CanBo.MaBM");
                return _maBM;
            }
        }
    }
    class DataCollection : App.DataCollection<Entity>
    {
    }

    public partial class Controller : App.Controller
    {

        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Update)
            {
                var gv = new GiangVienCollection();
                if (command.CommandValue == "calc")
                {
                    PhanCongGiangDay.Engine.ResetCBGD();

                    var model = new Project.GiaoKet.DataCollection();
                    model.Calculate("Lop");

                    this.UpdateDataBase("../chi-tiet");
                }

                if (command.CommandValue == "pc")
                {
                    var engine = new PhanCongGiangDay.Engine();
                    engine.PhanCong();

                    //var hp = new HocPhanMap(new HocPhanMap(gv, true), new Level(command.GetInt("min"), command.GetInt("max")));

                    this.UpdateDataBase("../da-phan-cong");
                    return;
                }
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}