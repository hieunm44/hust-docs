using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.hoc_ky.tkb.chua_phan_cong
{
    using PhanCongGiangDay;

    public partial class DataCollection : App.DataCollection<TKBEntity>
    {
    }
    public partial class Controller : TKBController
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : TKBPage
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }


    }
}