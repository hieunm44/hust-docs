using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.phan_cong.dau_ky.chi_tiet
{
    public class Entity : DataEntity
    {

    }

    public class DataCollection : App.DataCollection<Entity>
    {
        public DataCollection() : base("TKB") { }
    }

    public partial class Controller : App.giao_vu.giao_ket.chi_tiet.Controller
    {
        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Update && command.CommandValue == "accept")
            {
                const string chot = "chot";
                const string tl = "TichLuy";

                var data = new DefaultCollection("PhanCapCBGD");
                var col = data.Table.Columns.Add(chot, typeof(Single), "sum(child(PhanCapCBGD_GiangVienGiaoKet).TongQD)");

                foreach (var e in data.Select())
                    e.SetAttribute(tl, e.GetSingleValue(tl) + e.GetSingleValue(chot));

                data.Table.Columns.Remove(col);
                this.UpdateDataBase(null);

            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}