using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.giao_vu.hoc_ky.tkb
{
    class IEngine : lop.IEngine
    {
        DefaultCollection Lop = new DefaultCollection("Lop");
        protected override void CheckAllParent()
        {
            base.CheckParent(HocPhan, "Lop.MaHP");
            base.CheckParent(Lop, "MaLop");
        }
    }
    public partial class Controller : App.DuLieu.Controller
    {
        protected override void BeginImport(string data, DuLieu.ImportEngine engine)
        {
            base.BeginImport(data, new IEngine());
        }
    }

    public partial class Default : App.DuLieu.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}