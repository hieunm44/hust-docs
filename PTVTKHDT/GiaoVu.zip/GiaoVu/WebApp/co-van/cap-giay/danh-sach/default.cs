using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.cap_giay.tra.danh_sach
{
    public partial class Entity : App.DataEntity
    {
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        public object SHSV;
        protected override void SetContextParam(VST.Schema.FHD.Entity context)
        {
            var account = Service.Account.AccountCollection;
            var e = account.Find(SHSV);
            object id = e == null ? 0 : e.GetAttribute("UserId");
            this.DataEngine.And("SinhVienId=" + id);
        }

        public void Tra(string[] keys)
        {
            var nhan = new kiem_tra.DataCollection("Nhan");
            var d = DateTime.Now;
            
            foreach (var e in nhan.GetDangKy(keys))
                nhan.AddEntity(e).SetAttribute("Ngay", d);
            
            this.UpdateDataBase();
        }
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            var model = (DataCollection)this.LoadCollection(null);
            this.Model = model;
            if (command.ActionIndex == ActionIndex.Search)
            {
                model.SHSV = command.CommandValue;
                return;
            }

            if (command.ActionIndex == ActionIndex.Delete)
            {
                model.Tra(command.ItemKeys);
                Engine.Finish("../tra");
            }
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}