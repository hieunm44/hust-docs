using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.cap_giay.quy_trinh.qua_han
{
    public partial class Entity : App.DataEntity
    {

    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }

        protected override void AddEntity()
        {
            new kiem_tra.DataCollection().DonDep();
        }

        public override void ProcessDelete(PostBackCommand command)
        {
            var model = new kiem_tra.DataCollection();
            var account = Service.Account.AccountCollection;

            foreach (var e in model.GetDangKy(command.ItemKeys))
            {
                var user = account.FindFirstEntity("UserId", e.GetInt("SinhVienId"));
                user.SetAttribute("AuthorId", Author.SinhVien);

                e.Delete();
            }
            this.UpdateDataBase();
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}