using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.cap_giay.quy_trinh.xu_ly
{
    public partial class Entity : App.DataEntity
    {
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
    }
    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Update)
            {
                var model = new kiem_tra.DataCollection("Xong");
                foreach (var e in model.GetDangKy(command.ItemKeys))
                    model.AddEntity(e);

                model.DonDep();
                Engine.Finish("../xong");
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}