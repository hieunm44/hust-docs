﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace App.cap_giay.kiem_tra
{
    public partial class Entity : App.DataEntity
    {
        public override object GetAttribute(string name)
        {
            var v = base.GetAttribute(name);
            if (v is DateTime)
                return string.Format("{0:dd.MM.yyyy}", v);
            return v;
        }

        public object GetDangKyAttribute(string name)
        {
            return base.GetAttribute("XinGiay_DangKy." + name);
        }

        public void SetDangKyAttribute(string name, object value)
        {
            base.SetAttribute("XinGiay_DangKy." + name, value);
        }

        public void UpdateHanCuoi()
        {
            var d = (int)base.GetAttribute("XinGiay_PhanCap.HieuLuc");
            this.SetDangKyAttribute("HanCuoi", DateTime.Today.AddDays(d));
        }
    }
    public partial class DataCollection : App.DataCollection<Entity>
    {
        string _quyTrinh;
        public DataCollection(string name)
            : base("XinGiay_" + name)
        {
            _quyTrinh = name;
        }
        public DataCollection()
            : this("DangKy")
        {
        }

        public override void UpdateView(AppView view)
        {
            var user = new DefaultCollection("User");
            var sinhvien = new DefaultCollection("SinhVien");
            var pc = new DefaultCollection("XinGiay_PhanCap");

            var guis = VST.Schema.Template.Guis;
            var form = (Json.Table)view.JsonTemplate;
            var data = form.Data;
            foreach (var e in this)
            {
                var info = data.CreateCollection();

                var id = e.GetAttribute("SinhVienId");
                var sv = sinhvien.Find(id);
                var svTemp = info.CreateCollection("SinhVien");
                foreach (var col in guis["SinhVien"])
                {
                    if (col.Name.Contains('.'))
                        continue;

                    svTemp.Add(col.Name, col.ToString(sv.GetAttribute(col.Name)));
                }

                var us = user.Find(id);
                var usTemp = info.CreateCollection("Profile");
                foreach (var col in guis["Profile"])
                {
                    if (col.Name.Contains('.'))
                        continue;

                    usTemp.Add(col.Name, col.ToString(us.GetAttribute(col.Name)));
                }

                var doc = info.CreateCollection("doc");
                var type = e.GetString("MaPC");

                doc.Add("type", type);
                doc.Add("DangKyId", e.ID);
                doc.Add("So", e.GetInt("So"));
                doc.Add("ThoiDiem", e.GetAttribute("ThoiDiem"));

                var modelName = "XinGiay_" + type;
                var child = new App.DataCollection<Entity>(modelName).Find(e.ID);
                foreach (var col in guis[modelName])
                    if (col.Name.Contains('.') == false)
                        doc.Add(col.Name, child.GetAttribute(col.Name));
            }

            var ngay = form.CreateCollection("ngay");
            var so = form.CreateCollection("so");
            foreach (var e in pc.Select())
            {
                so.Add((string)e.ID, e.GetInt("So"));
                ngay.Add((string)e.ID, e.GetInt("HieuLuc"));
            }



            view.DataBind();

        }

        public Entity AddEntity(Entity e)
        {
            var xl = (string)e.GetDangKyAttribute("MaXL");
            var id = e.ID;

            if (xl != string.Empty)
            {
                if (_quyTrinh == xl)
                    return e;

                e.SetDangKyAttribute("MaXL", _quyTrinh);

                var old = (Entity)new DataCollection(xl).Find(id);
                if (old != null) old.Delete();
            }
            return base.Insert(id);
        }

        public DataCollection GetDangKy(string[] keys)
        {
            var model = new DataCollection();
            foreach (var key in keys)
            {
                this.Add(model.Find(key) as Entity);
            }
            return this;
        }

        public void DonDep()
        {
            var dangKy = new DataCollection();
            var xong = new DataCollection("Xong");
            var qua = new DataCollection("Qua");
            var nhan = new DataCollection("Nhan");

            var toDay = DateTime.Today;
            foreach (var e in nhan.Select())
            {
                var v = e.GetDangKyAttribute("HanCuoi");
                if (v.Equals(string.Empty) || (DateTime)v < toDay)
                    ((DataEntity)dangKy.Find(e.ID)).Delete();
            }

            foreach (var e in xong.Select())
            {
                var v = e.GetDangKyAttribute("HanCuoi");
                if (v.Equals(string.Empty))
                    continue;

                var d = (DateTime)v;
                if (d < toDay)
                {
                    var so = e.GetDangKyAttribute("MaSo");
                    qua.AddEntity(e).SetAttribute("MaSo", so);

                    qua.Add(e);
                }
            }

            if (qua.Count > 0)
            {
                var account = Service.Account.AccountCollection.CreateDataMap("UserId");
                foreach (var e in qua)
                {
                    var acc = account[e.GetDangKyAttribute("SinhVienId")];
                    acc.SetAttribute("AuthorId", Author.Spam);
                }
            }

            dangKy.UpdateDataBase();
        }
    }

    class View : App.AppView
    {
        public View()
        {
            this.JsonTemplate = new Json.Table();
        }
        public override string GetClassName()
        {
            return "KiemTra";
        }

        protected override IEnumerable GetFieldList()
        {
            return null;
        }

        public override void DataBind()
        {
            ((Json.Table)this.JsonTemplate).Add("type", this.GetClassName());
        }
    }

    public partial class Controller : App.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return new DataCollection();
        }

        public override void ProcessRequest(PostBackCommand command)
        {
            if (command.ActionIndex == ActionIndex.Update)
            {
                var model = new DataCollection();
                if (!string.IsNullOrEmpty(command.CommandValue))
                {
                    this.Model = model.GetDangKy(command.ItemKeys);
                    return;
                }

                command = command.GetFormData();

                var xl = new DataCollection("XuLy");
                var sai = new DataCollection("Sai");
                var pc = new DataCollection("PhanCap");
                foreach (var p in command)
                {
                    if (char.IsDigit(p.Key[0]))
                    {
                        var e = (Entity)model.Find(p.Key);
                        var value = p.Value.ToString();

                        if (value[0] == '#')
                        {
                            sai.AddEntity(e).SetAttribute("NoiDung", value.Substring(1));
                        }
                        else
                        {
                            e.SetAttribute("So", value);
                            xl.AddEntity(e).UpdateHanCuoi();
                        }
                    }
                    else // Cập nhật số theo loại giấy
                    {
                        pc.Find(p.Key).SetAttribute("So", p.Value);
                    }
                }
                this.UpdateDataBase();
            }
            base.ProcessRequest(command);
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }

        protected override AppView CreateView(string name)
        {
            return new View();
        }

        protected override void LoadSiteMap()
        {
        }
    }
}