﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace App.Service
{
    /// <summary>
    /// Summary description for Login
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]

    public class Account : System.Web.Services.WebService
    {
        public static DefaultCollection AccountCollection
        {
            get { return new DefaultCollection("Account"); }
        }
        public static DefaultCollection UserCollection
        {
            get { return new DefaultCollection("User"); }
        }
        public static TokenCollection TokenCollection
        {
            get { return new TokenCollection(); }
        }
        public static DefaultCollection SpamCollection
        {
            get { return new DefaultCollection("Spam"); }
        }

        string GetSecureUser(string name, string pass)
        {
            return VST.Security.Generate(name.ToLower() + pass);
        }

        //[WebMethod]
        //public object[] GetUser(string name, string pass)
        //{
        //    var v = new object[] { 0, 0 };
        //    var e = UserCollection.FindFirstEntity("password", GetSecureUser(name, pass));

        //    if (!e.IsNew)
        //    {
        //        v[0] = e.GetAttribute("AuthorId");
        //        v[1] = e.GetAttribute("Id");
        //    }

        //    return v;
        //}

        //public int GetUserAuthorId(object id, object pass)
        //{
        //    var model = UserCollection;
        //    var e = model.Find(id);

        //    if (e != null && e.GetAttribute("Password").Equals(pass))
        //        return (int)e.GetAttribute("AuthorId");
        //    return -1;
        //}

        public class Core
        {
            public static User.Entity Login(string name, string pass)
            {
                if (pass[0] == '#')
                    pass = VST.Security.Generate(name.ToLower() + pass.Substring(1));

                var e = AccountCollection.Find(name) as DataEntity;
                var user = new User.Entity();
                if (e == null)
                    return user;


                if (e.GetAttribute("Pass").Equals(pass) == false)
                {
                    user.UserName = name;
                    return user;
                }

                object id = e.GetAttribute("UserId");
                if (!id.Equals(string.Empty))
                {
                    user.Row = ((DataEntity)UserCollection.Find(id)).Row;
                    user.Description = user.GetString("FullName");
                }
                else
                {
                    user.Description = (string)e.GetAttribute("Author.Description");
                }
                user.Level = e.GetInt("AuthorId");
                user.HomeUrl = "/" + e.GetAttribute("Author.Site");
                return user;
            }
            public static object Create(string name, string pass, string fullName, string email, string tel, int authorId, string token)
            {
                var data = AccountCollection;
                name = name.ToLower();

                if (data.Find(name) != null)
                    return null;

                bool gen = false;
                if (string.IsNullOrEmpty(pass))
                {
                    pass = CreateDefaultPassword(6);
                    gen = true;
                }
                else
                {
                    if (pass[0] == '#')
                    {
                        pass = pass.Substring(1);
                        gen = true;
                    }
                }

                if (gen) pass = VST.Security.Generate(name + pass);

                var user = UserCollection.Insert(null, fullName, email, tel);
                data.Insert(name, pass, authorId, user.ID);

                return user.ID;
            }
            public static string CreateDefaultPassword(int length)
            {
                var chs = new int[] { '0', '9', 'A', 'Z', 'a', 'z' };
                var pass = new char[length];
                var rand = new Random();

                for (int i = 0; i < length; i++)
                {
                    int r = rand.Next(3) << 1;
                    int min = chs[r];
                    int max = chs[r + 1];

                    pass[i] = (char)rand.Next(min, max);
                }

                return new string(pass);
            }
        }

        [WebMethod]
        public string CreateAccount(string name, string pass, string fullName, string email, string tel, int authorId, string token)
        {
            if (pass == null)
                pass = Core.CreateDefaultPassword(6);

            object id = Core.Create(name, VST.Security.Generate(name + pass), fullName, email, tel, authorId, token);
            if (id == null)
                return NameManager.FAIL;

            AccountCollection.UpdateDataBase();
            return string.Format("<user id='{0}' name='{1}' pass='{2}' />", id, name, pass);
        }


        /// <summary>
        /// Login bằng user name và password chuẩn MD5(name + pass)
        /// </summary>
        /// <param name="name"></param>
        /// <param name="pass"></param>
        /// <returns></returns>
        [WebMethod]
        public string Login(string name, string pass)
        {
            var user = Core.Login(name, pass);

            if (user.UserName == null)
                return "<login error='Account Not Found' type='Name' />";

            if (user.Description == null)
                return "<login error='Invalid Password' type='Pass' />";


            //var token = VST.Security.Generate("{0}{1}", name.ToLower(), DateTime.Now.Ticks);
            //TokenCollection.Insert(token, id, name, DateTime.Now);
            //TokenCollection.UpdateDataBase();
            //return string.Format("<user id='{0}' name='{1}' authorid='{2}' description='{3}' token='{4}' />", id, name, e.GetAttribute("AuthorId"), e.GetAttribute("User.FullName") , token);

            return string.Format("<user id='{0}' name='{1}' authorid='{2}' description='{3}' />", user.ID, name, user.Level, user.Description);
        }

        [WebMethod]
        public string Logout(string token)
        {
            if (token != null)
            {
                var data = TokenCollection;
                var e = data.Find(token) as DataEntity;

                if (e != null) e.Delete();
                data.UpdateDataBase();
            }
            return NameManager.OK;
        }

        [WebMethod]
        public string ChangePassword(string name, string oldPass, string newPass)
        {
            var model = AccountCollection;
            var e = model.Find(name);
            if (e.GetAttribute("Pass").Equals(oldPass))
            {
                e.SetAttribute("Pass", newPass);
                model.UpdateDataBase();
                return NameManager.OK;
            }
            return NameManager.FAIL;
        }

        bool IsOneUser(IEntity a, IEntity b)
        {
            return a.GetAttribute("UserId").Equals(b.GetAttribute("UserId"));
        }

    }

    public class AccountInfo : DataEntity
    {
        public int Level { get; set; }
        public DataEntity Profile { get; set; }

        public const int LoginSuccess = 0;
        public const int UserNotFound = 1;
        public const int PasswordInvalid = 2;

        public AccountInfo(string name, string pass)
        {
            if (pass[0] == '#')
                pass = VST.Security.Generate(name.ToLower() + pass.Substring(1));

            var e = (DataEntity)Account.AccountCollection.Find(name);
            if (e == null) return;

            this.Row = e.Row;
            if (e.GetString("Pass") != pass)
                return;

            this.Level = this.GetInt("AuthorId");

            object userId = this.GetAttribute("UserId");
            if (userId.Equals(string.Empty))
                return;

            this.Profile = (DataEntity)Account.UserCollection.Find(userId);
        }
        
        public int LoginState
        {
            get
            {
                if (this.Row == null) return UserNotFound;
                if (this.Level == 0) return PasswordInvalid;

                return LoginSuccess;
            }
        }
    }

    public class TokenCollection : DataCollection<UserToken>
    {
        public TokenCollection() : base("Token") { }
        public UserToken this[string key]
        {
            get
            {
                return (UserToken)this.Find(key);
            }
        }

        public bool CanUpdate(string token, int authorId)
        {
            var user = this[token];
            return user != null && user.AuthorId > authorId;
        }
    }

    public partial class UserToken : DataEntity
    {
        public int AuthorId { get { return (int)this.GetAttribute("Author.Id"); } }
        public int UserId { get { return this.GetInt("UserId"); } }
        public string UserName { get { return this.GetString("Name"); } }
    }
}
