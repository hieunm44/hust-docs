﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace App.Service
{
    public class XmlModel : VST.Base.XmlCollection<VST.Base.XmlEntity>
    {
        public XmlModel() { }
        public XmlModel(string content)
        {
            this.Load(new System.Xml.XmlDocument { InnerXml = content });
        }
        public void Convert(IDataCollection data, IEnumerable items, params string[] fields)
        {
            var table = data.DataEngine.Table;
            string nodeName = table.TableName.ToLower();

            if (fields.Length == 0)
            {
                var fs = new List<string>();
                foreach (System.Data.DataColumn col in table.Columns)
                    fs.Add(col.ColumnName);
                fields = fs.ToArray();
            }

            var lst = new List<String>();
            foreach (var name in fields)
                lst.Add(name.ToLower());

            if (items == null)
                items = (IEnumerable)data;
            foreach (IEntity e in items)
            {
                var x = this.CreateEntity(nodeName);
                this.Root.AppendChild(x.Node);

                int i = 0;
                foreach (var col in lst)
                {
                    x.SetAttribute(col, e.GetAttribute(fields[i++]));
                }
            }
        }

        public void Convert(IDataCollection data)
        {
            this.Convert(data, null);
        }

        new public VST.Base.XmlEntity this[int index]
        {
            get
            {
                return new VST.Base. XmlEntity(this.Root.ChildNodes[index]);
            }
        }
    }
}