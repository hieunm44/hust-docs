﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.hanh_chinh.du_lieu.can_bo
{
    class Entity : DataEntity
    {
        public override void Delete()
        {
            var model = Service.Account.UserCollection;
            ((DataEntity)model.Find(this.ID)).Delete();
        }

        public override void Execute(PostBackCommand command)
        {
            if (this.IsNew)
            {
                var api = new Service.Account();
                var email = command.GetString("Email");
                var fullName = command.GetString("User.FullName");
                var name = CanBo.GetUserName(fullName);


                var xml = api.CreateAccount(name, '#' + name, fullName, email, null, Author.GiangVien, null);
                if (xml == NameManager.FAIL) return;

                var doc = new System.Xml.XmlDocument { InnerXml = xml };
                command.Remove("User.FullName");
                this.Row[0] = doc.DocumentElement.GetAttribute("id");
            }
            base.Execute(command);
        }

        protected override void EndExecute(PostBackCommand command)
        {
            base.EndExecute(command);
            if (command.OutputValue != null)
            {
                var max = (int)(new DefaultCollection("ChucDanh").Find(command["MaCD"]).GetAttribute("PhanCapGD"));
                if (max == 0)
                    return;

                var gv = App.PhanCongGiangDay.Engine.GetGiangVienLevel();
                var pccb = new DefaultCollection("PhanCapCBGD");

                int min = Math.Min(gv, max);
                pccb.Insert(this.ID, min, max);
            }
        }
    }

    class DataCollection : App.DataCollection<Entity>
    {
    }


    public class Controller : App.Controller
    {
        protected override ICollection CreateDefaultCollection()
        {
            return new DataCollection();
        }
    }

    public partial class Default : App.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}