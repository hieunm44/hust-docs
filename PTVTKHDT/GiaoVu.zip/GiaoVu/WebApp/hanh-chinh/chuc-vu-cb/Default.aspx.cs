﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace App.hanh_chinh.chuc_vu_cb
{
    public class Controller : App.DuLieu.Controller
    {
        protected override IModel LoadCollection(string name)
        {
            return base.LoadCollection(name);
        }
        public override void ProcessRequest(PostBackCommand command)
        {
            var canBoId = command["canbo"];
            if (canBoId != null)
            {
                var model = new DefaultCollection("ChucVuCB");
                var e = model.FindFirstEntity("GiangVienId", canBoId);
                if (e.HasData == false)
                {
                    e = model.NewEntity() as DataEntity;
                    e.SetAttribute("GiangVienId", canBoId);
                }
                this.Collection = model;
                this.Model = e;

                return;
            }
            base.ProcessRequest(command);
        }
        public override void ProcessDelete(PostBackCommand command)
        {
            base.ProcessDelete(command);
        }
    }

    public partial class Default : App.DuLieu.Page
    {
        public override App.Controller CreateDefaultController()
        {
            return new Controller();
        }
    }
}