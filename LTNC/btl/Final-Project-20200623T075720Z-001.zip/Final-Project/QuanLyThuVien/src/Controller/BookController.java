/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.Interface;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Blob;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.Book;

/**
 *
 * @author loiph
 */
public class BookController {
    public void saveBook(JTextField txtBname,JTextField txtBamount, JTextField txtBauthor,JTextArea txtBbrief,
                        JTextField txtBcategory, JTextField txtBprice, JTextField txtBpublishyear, JLabel txtBid,
                        String imageFile, JLabel imageB, Blob bblob){
        boolean kt=true;
        if (txtBname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Please input name");
            txtBname.requestFocus();
            return;
        }
        if (txtBcategory.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Please input category");
            txtBcategory.requestFocus();
            return;
        }
        if (txtBauthor.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Please input author");
            txtBauthor.requestFocus();
            return;
        }
        if (txtBpublishyear.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Please input publish year");
            txtBpublishyear.requestFocus();
            return;
        }
        if (txtBprice.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Please input price");
            txtBprice.requestFocus();
            return;
        }
        
        if (txtBamount.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Please input amount");
            txtBamount.requestFocus();
            return;
        }
        
        if (txtBbrief.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Please input brief");
            txtBbrief.requestFocus();
            return;
        }
        
        
        if (imageB.getIcon()==null){
            JOptionPane.showMessageDialog(null, "Please add image");
            imageB.requestFocus();
            return;
        }
        Book b= new Book();
        b.setName(txtBname.getText());
        b.setID(Integer.parseInt(txtBid.getText()));
        b.setAmount(Integer.parseInt(txtBamount.getText()));
        b.setAuthor(txtBauthor.getText());
        b.setBrief(txtBbrief.getText());
        b.setCategoryID(txtBcategory.getText());
        b.setLinkImage(imageFile);
        b.setPrice(Integer.parseInt(txtBprice.getText()));
        b.setPublisYear(Integer.parseInt(txtBpublishyear.getText()));
        b.setIcon(imageB.getIcon());
        controller.AddBookController ab= new controller.AddBookController();
        int ret = JOptionPane.showConfirmDialog(null, "Do you want to save data?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ret != JOptionPane.YES_OPTION) 
        {
            return; 
        }
        if (b.getID()>ab.getLastID()){
            if (ab.AddBookToDB(b)){
                JOptionPane.showMessageDialog(null, "Add Success");
            };
        }else{
            if(ab.updateBook(b,bblob)){
                JOptionPane.showMessageDialog(null, "Update Success");
            };
        }
    }
    public void newBook(JTextField txtBname,JTextField txtBamount, JTextField txtBauthor,JTextArea txtBbrief,
                        JTextField txtBcategory, JTextField txtBprice, JTextField txtBpublishyear, JLabel txtBid, JLabel imageB){
        controller.AddBookController ab= new controller.AddBookController();
        txtBname.setText("");
        txtBid.setText(String.valueOf(ab.getLastID()+1));
        txtBcategory.setText("");
        txtBauthor.setText("");
        txtBamount.setText("");
        txtBprice.setText("");
        txtBpublishyear.setText("");
        txtBbrief.setText("");
        imageB.setIcon(null);
    }
    public String addImage(JLabel imageB, Interface ithis){
        JFileChooser fc=new JFileChooser();
        fc.showOpenDialog(ithis);
        String imageFile = null;
        if(fc.getSelectedFile()!=null)
        {
           imageFile = fc.getSelectedFile().getAbsolutePath();
           BufferedImage img;
            try {
               img=ImageIO.read(new File(imageFile));
               Image img2 = img.getScaledInstance(imageB.getWidth(), imageB.getHeight(), Image.SCALE_SMOOTH);
               imageB.setIcon(new ImageIcon(img2));
               
                
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return imageFile;
    }
    public Blob showBook(JTextField txtBname,JTextField txtBamount, JTextField txtBauthor, JTextArea txtBbrief,
                        JTextField txtBcategory, JTextField txtBprice, JTextField txtBpublishyear, JLabel txtBid, JLabel imageB,
                        JTable tablebook){
        Blob blob= null;
        int SelectedRow= tablebook.getSelectedRow();
        String id= (String) String.valueOf(tablebook.getValueAt(SelectedRow, 0));
        ArrayList<Book> list2= new ArrayList<>();
        SearchController sc= new SearchController();
        list2= sc.searchBook(id, "id");
        Book b= list2.get(list2.size()-1);
        txtBname.setText(b.getName());
        txtBid.setText(String.valueOf(b.getID()));
        txtBauthor.setText(b.getAuthor());
        txtBamount.setText(String.valueOf(b.getAmount()));
        txtBprice.setText(String.valueOf(b.getPrice()));
        txtBpublishyear.setText(String.valueOf(b.getPublisYear()));
        txtBcategory.setText(b.getCategoryID());
        blob=b.getBlob();
        if (b.getIcon()!=null) {
            imageB.setIcon(b.getIcon());
        }else
            imageB.setIcon(null);
        txtBbrief.setText(b.getBrief());
        return blob;
    }
    public void searchBook(JTextField txtSname, JTextField txtSauthor,
                    JTextField txtScategory,  JTextField txtSpublishyear, 
                    DefaultTableModel model){
        model.setRowCount(0);
        ArrayList<Book> list= new ArrayList<>();
        ArrayList<Book> list1= new ArrayList<>();
        SearchController sc= new SearchController();
        controller.AddBookController ab= new controller.AddBookController();
        if(txtSname.getText().length()>0){
            list1 = sc.searchBook(txtSname.getText().trim(), "Name");
            list.addAll(list1);
        }
        if(txtSauthor.getText().length()>0){
            list1 = sc.searchBook(txtSauthor.getText().trim(), "Author");
            list.addAll(list1);
        }
        if(txtScategory.getText().length()>0){
            list1 = sc.searchBook(txtScategory.getText().trim(), "Category_id");
            list.addAll(list1);
        }
        if(txtSpublishyear.getText().length()>0){
            list1 = sc.searchBook(txtSpublishyear.getText().trim(), "PublishYear");
            list.addAll(list1);
        }
        if((txtSname.getText().trim().length()==0) &&((txtSauthor.getText().trim().length()==0))&&
                ((txtScategory.getText().trim().length()==0))&& ((txtSpublishyear.getText().trim().length()==0))){
            list=ab.getListBook();
        }
        for(Book b:list){
            model.addRow(new Object[]{
                b.getID(),b.getName()
            });
        }
        if (model.getRowCount()==0){
            JOptionPane.showMessageDialog(null, "Not found");
        }

    }
    public void deleteBook(JTable tablebook,DefaultTableModel model){
        int index= tablebook.getSelectedRow();
        String id= (String) String.valueOf(tablebook.getValueAt(index, 0));
        controller.AddBookController ab= new controller.AddBookController();
        int ret = JOptionPane.showConfirmDialog(null, "Do you want to delete book?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ret != JOptionPane.YES_OPTION) 
        {
            return; 
        }
        if(ab.deleteBook(id)){
            JOptionPane.showMessageDialog(null, "Delete success");
            model.removeRow(index);
        } else{
            JOptionPane.showMessageDialog(null, "Delete fail");
        }
    }
}
