# Recognize license plate 100% accurate
Using Python + OpenCV + ML(Google Vision)

# Pre-require:
- Python 3
- pip install opencv-python
- pip install google-cloud-vision
- client_key.json with role "AutoML Service Agent"

Set line 12 for debug:
DEBUG = True

## Demo: https://youtu.be/ITvA3KPnCx4

## By me a coffee https://www.paypal.me/tramvm/10
