package quanlysach_ltnc;

import view.LoginOption;

public class QuanLySach_LTNC {
    public static void main(String[] args) {
        LoginOption.getInstance().setVisible(true);
    }
}
