﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aloha
{
    public partial class Form1 : Form
    {
        int num_host, delta;
        int R = 400;
        int step = 0;
        List<Point> host_location = new List<Point>();
        Point p = new Point(535, 535);
        Bitmap host = new Bitmap("D:\\CSharp_Project\\aloha\\host.png");
        RectangleF rec;
        bool packet, collision;
        bool accept = false;
        int[] slot = new int[17];
        int count = 0;

        public Form1()
        {
            InitializeComponent();
                        
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Invalidate();
        }

        private void numUD1_ValueChanged(object sender, EventArgs e)
        {
            num_host = Convert.ToInt16(numUD1.Value);

            if (num_host == 1)
            {
                host_location.Clear();
                host_location.Add(new Point(p.X - R, p.Y));
            }
            else
            {
                host_location.Clear();
                for (int i = 0; i < num_host; i++)
                {
                    int delta_X = (int)(R * Math.Cos(Math.PI / 2 + i * Math.PI / (num_host - 1)));
                    int delta_Y = (int)(R * Math.Sin(Math.PI / 2 + i * Math.PI / (num_host - 1)));

                    host_location.Add(new Point(p.X + delta_X, p.Y + delta_Y));
                }
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (btn2.Text.Equals("Start"))
            {
                btn2.Text = "Stop";
                tmr1.Enabled = true;
                //num_packet = 0;
            }
            else
            {
                btn2.Text = "Start";
                tmr1.Enabled = false;
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if(!host_location.Count.Equals(0)) Draw_Time_Slot(step, e);

            Draw_Packet(slot, e);
            
            foreach (Point location in host_location)
            {
                if (num_host > 5 && num_host <= 10) rec = new Rectangle(location.X - 50, location.Y - 50, 100, 100);
                else if (num_host > 10) rec = new RectangleF(location.X - 35, location.Y - 35, 70, 70);
                else rec = new RectangleF(location.X - 75, location.Y - 75, 150, 150);

                e.Graphics.DrawLine(new Pen(Color.Blue, 1), p, location);

                e.Graphics.DrawRectangle(new Pen(Color.Blue, 2), new Rectangle(p.X + 96, p.Y - 25, 1300, 50));

                e.Graphics.DrawImage(new Bitmap("D:\\CSharp_Project\\aloha\\cloud.png"), new RectangleF(p.X - 96, p.Y - 65, 192, 130));

                e.Graphics.DrawImage(host, rec);
            }

            Draw_Packet(slot, e);
        }

        private void tmr1_Tick(object sender, EventArgs e)
        {
            count += 1;

            if (count == 20)
            {
                count = 0;
                Random rnd = new Random();
                packet = Convert.ToBoolean(rnd.Next(0, 2));
                collision = Convert.ToBoolean(rnd.Next(0, 2));

                if (packet & !collision) accept = true;
                else accept = false;

                for (int i = 0; i < slot.Length; i++)
                {
                    slot[i] += 1;
                }

                if (accept)
                {
                    for (int i = 1; i < slot.Length; i++)
                    {
                        slot[slot.Length - i] = slot[slot.Length - i - 1];
                    }
                    slot[0] = 0;                    
                }                
            }

            step += 4;
            if (step == 80) step = 0;
            
                       
            Invalidate(new Rectangle(p.X + 96, p.Y - 25, 1300, 50));
        }

        private void Draw_Time_Slot(int pos, PaintEventArgs e)
        {
            for (int i = 0; i < 17; i++)
            {
                e.Graphics.DrawLine(new Pen(Color.Blue, 2), p.X + 96 + pos + 80 * i, p.Y - 25, p.X + 96 + pos + 80 * i, p.Y + 25);
            }
        }

        private void Draw_Packet(int[] slot, PaintEventArgs e)
        {
            for (int i = 0; i < slot.Length; i++)
            {
                rec = new RectangleF(p.X + 96 + step + slot[i] * 80, p.Y - 25, 80, 50);
                e.Graphics.DrawImage(new Bitmap("D:\\CSharp_Project\\aloha\\yellow.png"), rec);
            }
        }
    }
}
