﻿namespace aloha
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lb1 = new System.Windows.Forms.Label();
            this.numUD1 = new System.Windows.Forms.NumericUpDown();
            this.lb2 = new System.Windows.Forms.Label();
            this.numUD2 = new System.Windows.Forms.NumericUpDown();
            this.lb3 = new System.Windows.Forms.Label();
            this.lb4 = new System.Windows.Forms.Label();
            this.numUD3 = new System.Windows.Forms.NumericUpDown();
            this.lb5 = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.tmr1 = new System.Windows.Forms.Timer(this.components);
            this.btn2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numUD1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUD2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUD3)).BeginInit();
            this.SuspendLayout();
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.Location = new System.Drawing.Point(12, 9);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(86, 13);
            this.lb1.TabIndex = 1;
            this.lb1.Text = "Number of Hosts";
            // 
            // numUD1
            // 
            this.numUD1.Location = new System.Drawing.Point(104, 7);
            this.numUD1.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.numUD1.Name = "numUD1";
            this.numUD1.Size = new System.Drawing.Size(37, 20);
            this.numUD1.TabIndex = 2;
            this.numUD1.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.numUD1.ValueChanged += new System.EventHandler(this.numUD1_ValueChanged);
            // 
            // lb2
            // 
            this.lb2.Location = new System.Drawing.Point(176, 9);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(158, 13);
            this.lb2.TabIndex = 3;
            this.lb2.Text = "Average packet generation rate ";
            this.lb2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numUD2
            // 
            this.numUD2.Location = new System.Drawing.Point(340, 7);
            this.numUD2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUD2.Name = "numUD2";
            this.numUD2.Size = new System.Drawing.Size(40, 20);
            this.numUD2.TabIndex = 4;
            this.numUD2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lb3
            // 
            this.lb3.AutoSize = true;
            this.lb3.Location = new System.Drawing.Point(386, 9);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(111, 13);
            this.lb3.TabIndex = 5;
            this.lb3.Text = "(packet/host/second)";
            // 
            // lb4
            // 
            this.lb4.AutoSize = true;
            this.lb4.Location = new System.Drawing.Point(524, 9);
            this.lb4.Name = "lb4";
            this.lb4.Size = new System.Drawing.Size(49, 13);
            this.lb4.TabIndex = 6;
            this.lb4.Text = "Time slot";
            // 
            // numUD3
            // 
            this.numUD3.Location = new System.Drawing.Point(579, 7);
            this.numUD3.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numUD3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUD3.Name = "numUD3";
            this.numUD3.Size = new System.Drawing.Size(52, 20);
            this.numUD3.TabIndex = 7;
            this.numUD3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lb5
            // 
            this.lb5.AutoSize = true;
            this.lb5.Location = new System.Drawing.Point(637, 9);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(65, 13);
            this.lb5.TabIndex = 8;
            this.lb5.Text = "(mili-second)";
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(715, 12);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(106, 39);
            this.btn1.TabIndex = 12;
            this.btn1.Text = "Create Network";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // tmr1
            // 
            this.tmr1.Interval = 50;
            this.tmr1.Tick += new System.EventHandler(this.tmr1_Tick);
            // 
            // btn2
            // 
            this.btn2.AutoSize = true;
            this.btn2.Location = new System.Drawing.Point(841, 12);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(106, 39);
            this.btn2.TabIndex = 14;
            this.btn2.Text = "Start";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(986, 589);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.lb5);
            this.Controls.Add(this.numUD3);
            this.Controls.Add(this.lb4);
            this.Controls.Add(this.lb3);
            this.Controls.Add(this.numUD2);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.numUD1);
            this.Controls.Add(this.lb1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.numUD1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUD2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUD3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.NumericUpDown numUD1;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.NumericUpDown numUD2;
        private System.Windows.Forms.Label lb3;
        private System.Windows.Forms.Label lb4;
        private System.Windows.Forms.NumericUpDown numUD3;
        private System.Windows.Forms.Label lb5;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Timer tmr1;
        private System.Windows.Forms.Button btn2;
    }
}

