Artificial Neural Network on Altera DE2
=======================================
